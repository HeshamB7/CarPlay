package com.example.ui.common

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Fmt {
    private val arabicIndic = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')

    fun digits(s: String, arabic: Boolean): String {
        if (!arabic) return s
        val sb = StringBuilder(s.length)
        for (ch in s) sb.append(if (ch in '0'..'9') arabicIndic[ch - '0'] else if (ch == ':') ':' else ch)
        return sb.toString()
    }

    private fun locale(arabicText: Boolean): Locale =
        if (arabicText) Locale.Builder().setLanguage("ar").setRegion("SA").setUnicodeLocaleKeyword("nu", "latn").build()
        else Locale.US

    fun time(ms: Long, use24: Boolean, seconds: Boolean, arabicDigits: Boolean): String {
        val pattern = (if (use24) "HH:mm" else "h:mm") + if (seconds) ":ss" else ""
        return digits(SimpleDateFormat(pattern, Locale.US).format(Date(ms)), arabicDigits)
    }

    fun ampm(ms: Long, arabicText: Boolean = false): String =
        SimpleDateFormat("a", locale(arabicText)).format(Date(ms))

    fun date(ms: Long, pattern: String, arabicText: Boolean, arabicDigits: Boolean): String =
        digits(SimpleDateFormat(pattern, locale(arabicText)).format(Date(ms)), arabicDigits)

    fun num(n: Int, arabicDigits: Boolean) = digits(n.toString(), arabicDigits)

    fun duration(totalSec: Long): String {
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
    }

    fun countdown(ms: Long): String {
        val totalMin = (ms / 60_000L).coerceAtLeast(0)
        val h = totalMin / 60
        val m = totalMin % 60
        return if (h > 0) "%dh %02dm".format(h, m) else "%d min".format(m)
    }
}
