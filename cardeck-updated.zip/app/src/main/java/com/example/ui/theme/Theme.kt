package com.example.ui.theme

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import com.example.model.CardStyle
import com.example.model.LauncherPreferences

@Immutable
data class CarTokens(
    val isNight: Boolean,
    val accent: Color,
    val label: Color,
    val secondaryLabel: Color,
    val tertiaryLabel: Color,
    val cardBase: Color,
    val cardBorder: Color,
    val separator: Color,
    val fill: Color,
    val groupedBg: Color,
    val green: Color,
    val orange: Color,
    val red: Color,
    val yellow: Color,
    val teal: Color,
    val purple: Color,
    val pink: Color,
    val indigo: Color,
    val cardStyle: CardStyle,
    val cardAlpha: Float,
    val cornerDp: Float,
    val gapDp: Float,
    val reduceMotion: Boolean
) {
    /** Card fill for a style (a widget may override the global one). */
    fun cardFill(style: CardStyle = cardStyle): Color = when (style) {
        CardStyle.GLASS -> cardBase.copy(alpha = cardAlpha)
        CardStyle.SOLID -> cardBase
        CardStyle.OUTLINE -> Color.Transparent
    }
    val secondaryLabelText: Color get() = secondaryLabel
}

val LocalCarTokens = compositionLocalOf {
    buildTokens(true, LauncherPreferences())
}

/** iOS system accent palette (dark variants first, then light). */
val AccentChoices: List<Pair<String, Int>> = listOf(
    "Blue" to 0xFF0A84FF.toInt(), "Green" to 0xFF30D158.toInt(), "Orange" to 0xFFFF9F0A.toInt(),
    "Red" to 0xFFFF453A.toInt(), "Pink" to 0xFFFF375F.toInt(), "Purple" to 0xFFBF5AF2.toInt(),
    "Indigo" to 0xFF5E5CE6.toInt(), "Teal" to 0xFF40C8E0.toInt(), "Yellow" to 0xFFFFD60A.toInt(),
    "Graphite" to 0xFF8E8E93.toInt()
)

fun buildTokens(isNight: Boolean, p: LauncherPreferences): CarTokens {
    val accent = Color(p.accent)
    return if (isNight) CarTokens(
        isNight = true, accent = accent,
        label = Color.White, secondaryLabel = Color(0x99EBEBF5), tertiaryLabel = Color(0x4DEBEBF5),
        cardBase = Color(0xFF1C1C1E), cardBorder = Color(0x1FFFFFFF), separator = Color(0x99545458),
        fill = Color(0x5C787880), groupedBg = Color(0xFF000000),
        green = Color(0xFF30D158), orange = Color(0xFFFF9F0A), red = Color(0xFFFF453A), yellow = Color(0xFFFFD60A),
        teal = Color(0xFF40C8E0), purple = Color(0xFFBF5AF2), pink = Color(0xFFFF375F), indigo = Color(0xFF5E5CE6),
        cardStyle = p.cardStyle, cardAlpha = p.cardAlpha, cornerDp = p.cornerRadiusDp, gapDp = p.cardGapDp, reduceMotion = p.reduceMotion
    ) else CarTokens(
        isNight = false, accent = accent,
        label = Color.Black, secondaryLabel = Color(0x993C3C43), tertiaryLabel = Color(0x4D3C3C43),
        cardBase = Color(0xFFFFFFFF), cardBorder = Color(0x14000000), separator = Color(0x4A3C3C43),
        fill = Color(0x33787880), groupedBg = Color(0xFFF2F2F7),
        green = Color(0xFF34C759), orange = Color(0xFFFF9500), red = Color(0xFFFF3B30), yellow = Color(0xFFFFCC00),
        teal = Color(0xFF30B0C7), purple = Color(0xFFAF52DE), pink = Color(0xFFFF2D55), indigo = Color(0xFF5856D6),
        cardStyle = p.cardStyle, cardAlpha = p.cardAlpha, cornerDp = p.cornerRadiusDp, gapDp = p.cardGapDp, reduceMotion = p.reduceMotion
    )
}

@Composable
fun CarDeckTheme(isNight: Boolean, prefs: LauncherPreferences, content: @Composable () -> Unit) {
    val tokens = remember(isNight, prefs.accent, prefs.cardStyle, prefs.cardAlpha, prefs.cornerRadiusDp, prefs.cardGapDp, prefs.reduceMotion) {
        buildTokens(isNight, prefs)
    }
    val typography = remember(prefs.boldText) { buildCarTypography(prefs.boldText) }
    val scheme = if (isNight) darkColorScheme(
        primary = tokens.accent, onPrimary = Color.White, background = Color.Black, onBackground = Color.White,
        surface = tokens.cardBase, onSurface = Color.White, surfaceVariant = Color(0xFF2C2C2E), onSurfaceVariant = tokens.secondaryLabel,
        error = tokens.red, outline = tokens.cardBorder
    ) else lightColorScheme(
        primary = tokens.accent, onPrimary = Color.White, background = tokens.groupedBg, onBackground = Color.Black,
        surface = Color.White, onSurface = Color.Black, surfaceVariant = Color(0xFFE5E5EA), onSurfaceVariant = tokens.secondaryLabel,
        error = tokens.red, outline = tokens.cardBorder
    )
    CompositionLocalProvider(LocalCarTokens provides tokens) {
        MaterialTheme(colorScheme = scheme, typography = typography, content = content)
    }
}

/**
 * Makes the whole UI scale to any screen: dp and sp are rescaled so a layout designed for a
 * 960x540 dp canvas looks the same on a small phone, a 1280x720 head unit or a large tablet.
 */
@Composable
fun AdaptiveDensity(autoFit: Boolean, userScale: Float, fontScale: Float, content: @Composable (screenW: Float, screenH: Float) -> Unit) {
    val base = LocalDensity.current
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wDp = constraints.maxWidth / base.density
        val hDp = constraints.maxHeight / base.density
        val fit = if (autoFit) minOf(wDp / REF_W, hDp / REF_H).coerceIn(0.55f, 2.6f) else 1f
        val k = fit * userScale
        val density = remember(base.density, k, fontScale) { Density(base.density * k, fontScale) }
        CompositionLocalProvider(LocalDensity provides density) {
            content(wDp / k, hDp / k)
        }
    }
}

private const val REF_W = 960f
private const val REF_H = 540f
