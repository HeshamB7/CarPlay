package com.example

import com.example.data.WidgetLayout
import com.example.engine.SolarCalc
import com.example.model.PrayerMethod
import com.example.model.WidgetType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.TimeZone

class CarDeckLogicTest {

    private val riyadh = TimeZone.getTimeZone("Asia/Riyadh")

    @Test
    fun `jeddah sun times in November are plausible`() {
        // 2026-11-13 12:00 Riyadh time
        val noon = 1_794_564_000_000L
        val sun = SolarCalc.sun(noon, 21.4858, 39.1925)
        assertNotNull(sun)
        val riseH = ((sun!!.sunrise + riyadh.rawOffset) / 3_600_000L) % 24
        val setH = ((sun.sunset + riyadh.rawOffset) / 3_600_000L) % 24
        assertEquals(6L, riseH)
        assertEquals(17L, setH)
    }

    @Test
    fun `prayer order is increasing`() {
        val day = SolarCalc.localEpochDay(1_794_564_000_000L, riyadh)
        val p = SolarCalc.prayers(day, 21.4858, 39.1925, PrayerMethod.UMM_AL_QURA, false, false, 0)
        assertNotNull(p)
        val l = p!!.asList()
        for (i in 1 until l.size) assertTrue(l[i] > l[i - 1])
    }

    @Test
    fun `default layout is valid and fits the grid`() {
        val pages = WidgetLayout.sanitize(WidgetLayout.defaultPages(), 4, 2)
        assertEquals(2, pages.size)
        pages.forEach { pg ->
            pg.widgets.forEach { w ->
                assertTrue(w.col + w.w <= 4 && w.row + w.h <= 2)
            }
        }
    }

    @Test
    fun `shrinking the grid never loses widgets`() {
        val before = WidgetLayout.defaultPages().sumOf { it.widgets.size }
        val after = WidgetLayout.sanitize(WidgetLayout.defaultPages(), 2, 1).sumOf { it.widgets.size }
        assertEquals(before, after)
    }

    @Test
    fun `move onto a free cell and reject out of bounds overlap`() {
        val pages = WidgetLayout.defaultPages()
        val clock = pages[0].widgets.first { it.type == WidgetType.CLOCK }
        assertNull(WidgetLayout.moveWidget(pages[0].widgets, clock.id, clock.col, clock.row, 4, 2))
        val speed = pages[0].widgets.first { it.type == WidgetType.SPEED }
        val swapped = WidgetLayout.moveWidget(pages[0].widgets, speed.id, clock.col, clock.row, 4, 2)
        assertNotNull(swapped)
    }
}
