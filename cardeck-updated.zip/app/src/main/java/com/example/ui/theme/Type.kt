package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.example.R
import kotlin.math.exp

/**
 * Apple-style type scale. SF Pro itself is licensed only for Apple platforms, so this uses Inter,
 * the open typeface designed for the same job, with the iOS text-style sizes, line heights and weights.
 */
val CarFont = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold)
)

/** Inter's recommended optical tracking for a given size (in sp). */
private fun tracking(size: Float): TextUnit = ((-0.0223f + 0.185f * exp(-0.1745f * size)) * size).sp

private fun bump(w: FontWeight, bold: Boolean): FontWeight = if (!bold) w else when {
    w.weight < 500 -> FontWeight.Medium
    w.weight < 600 -> FontWeight.SemiBold
    else -> FontWeight.Bold
}

private fun st(size: Float, line: Float, w: FontWeight, bold: Boolean) = TextStyle(
    fontFamily = CarFont,
    fontWeight = bump(w, bold),
    fontSize = size.sp,
    lineHeight = line.sp,
    letterSpacing = tracking(size)
)

fun buildCarTypography(bold: Boolean): Typography {
    val r = FontWeight.Normal; val m = FontWeight.Medium; val s = FontWeight.SemiBold; val b = FontWeight.Bold
    return Typography(
        displayLarge = st(52f, 56f, b, bold).copy(fontFeatureSettings = "tnum"),
        displayMedium = st(40f, 44f, b, bold).copy(fontFeatureSettings = "tnum"),
        displaySmall = st(34f, 41f, b, bold).copy(fontFeatureSettings = "tnum"),
        headlineLarge = st(28f, 34f, b, bold),
        headlineMedium = st(22f, 28f, s, bold),
        headlineSmall = st(20f, 25f, s, bold),
        titleLarge = st(20f, 25f, s, bold),
        titleMedium = st(17f, 22f, s, bold),
        titleSmall = st(15f, 20f, s, bold),
        bodyLarge = st(17f, 22f, r, bold),
        bodyMedium = st(15f, 20f, r, bold),
        bodySmall = st(13f, 18f, r, bold),
        labelLarge = st(16f, 21f, m, bold),
        labelMedium = st(13f, 18f, m, bold),
        labelSmall = st(11f, 13f, m, bold)
    )
}
