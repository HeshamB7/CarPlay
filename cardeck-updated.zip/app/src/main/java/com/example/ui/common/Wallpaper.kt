package com.example.ui.common

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import coil.compose.AsyncImage
import com.example.R
import com.example.model.LauncherPreferences
import com.example.model.WallpaperPreset

object Wallpapers {
    val gradients: List<Pair<String, List<Color>>> = listOf(
        "Aurora" to listOf(Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364)),
        "Sunset" to listOf(Color(0xFF42275A), Color(0xFFB24A76), Color(0xFFFF9966)),
        "Midnight" to listOf(Color(0xFF000000), Color(0xFF0B1026), Color(0xFF1B2A5E)),
        "Graphite" to listOf(Color(0xFF111114), Color(0xFF26262B), Color(0xFF3A3A40)),
        "Ocean" to listOf(Color(0xFF021B79), Color(0xFF0575E6), Color(0xFF3FD6E8)),
        "Forest" to listOf(Color(0xFF0B1F14), Color(0xFF14532D), Color(0xFF3F8F5B)),
        "Rose" to listOf(Color(0xFF3B0A2A), Color(0xFFA11D5B), Color(0xFFFF7EB3)),
        "Desert" to listOf(Color(0xFF2B1A0E), Color(0xFF8A5A2B), Color(0xFFE9B872))
    )
    val solids: List<Int> = listOf(
        0xFF000000.toInt(), 0xFF1C1C1E.toInt(), 0xFF0A2540.toInt(), 0xFF1B3A2D.toInt(),
        0xFF3A1D1D.toInt(), 0xFF2B1B45.toInt(), 0xFFF2F2F7.toInt(), 0xFFDCE6F2.toInt()
    )
}

@Composable
fun WallpaperBackground(prefs: LauncherPreferences, isNight: Boolean, modifier: Modifier = Modifier.fillMaxSize()) {
    Box(modifier) {
        when (prefs.wallpaperPreset) {
            WallpaperPreset.IOS_18_DYNAMIC -> Image(
                painterResource(if (isNight) R.drawable.img_wallpaper_ios18_night else R.drawable.img_wallpaper_ios18_day),
                null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop
            )
            WallpaperPreset.IOS_17_DYNAMIC -> Image(
                painterResource(if (isNight) R.drawable.img_wallpaper_ios17_night else R.drawable.img_wallpaper_ios17_day),
                null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop
            )
            WallpaperPreset.GRADIENT -> {
                val g = Wallpapers.gradients[prefs.wallpaperGradient.coerceIn(0, Wallpapers.gradients.lastIndex)].second
                Box(Modifier.fillMaxSize().background(Brush.linearGradient(g)))
            }
            WallpaperPreset.SOLID -> Box(Modifier.fillMaxSize().background(Color(prefs.wallpaperSolid)))
            WallpaperPreset.BLACK -> Box(Modifier.fillMaxSize().background(Color.Black))
            WallpaperPreset.CUSTOM_IMAGE -> {
                if (prefs.customWallpaperUri != null) AsyncImage(prefs.customWallpaperUri, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Box(Modifier.fillMaxSize().background(Color.Black))
            }
        }
        val dim = prefs.wallpaperDim + if (isNight) 0.12f else 0f
        if (dim > 0.01f) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim.coerceAtMost(0.85f))))
    }
}
