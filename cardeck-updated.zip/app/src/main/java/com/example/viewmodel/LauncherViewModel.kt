package com.example.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.LauncherPreferencesRepository
import com.example.data.WidgetLayout
import com.example.engine.*
import com.example.model.*
import com.example.service.CarMediaNotificationListenerService
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

sealed interface ValetAction {
    object OpenSettings : ValetAction
    data class EditApp(val app: AppEntry) : ValetAction
}

/** What the app picker is currently choosing apps for. */
sealed interface PickerTarget {
    object Dock : PickerTarget
    data class Shortcuts(val widgetId: String) : PickerTarget
}

@OptIn(FlowPreview::class)
class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = LauncherPreferencesRepository(application)
    val iconProcessor = IconProcessor(application)
    val timeGuard = TimeGuard(application)
    val telemetryManager = TelemetryManager(application) { timeGuard.now() }

    // ------------------------------------------------------------------ data flows
    private val _prefs = MutableStateFlow(LauncherPreferences())
    val preferences: StateFlow<LauncherPreferences> = _prefs.asStateFlow()
    private var prefsLoaded = false

    private val _rawApps = MutableStateFlow<List<AppEntry>>(emptyList())
    private val _iconPacks = MutableStateFlow<List<IconPackInfo>>(emptyList())
    private val _icons = MutableStateFlow<Map<String, ImageBitmap>>(emptyMap())
    val processedIcons: StateFlow<Map<String, ImageBitmap>> = _icons.asStateFlow()
    val iconPacks: StateFlow<List<IconPackInfo>> = _iconPacks.asStateFlow()

    val allApps: StateFlow<List<AppEntry>> = combine(_rawApps, _prefs) { raw, p -> applyUserPrefs(raw, p) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val visibleApps: StateFlow<List<AppEntry>> = allApps.map { l -> l.filter { !it.isHidden } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val dockApps: StateFlow<List<AppEntry>> = combine(allApps, _prefs) { apps, p ->
        val map = apps.associateBy { it.packageName }
        val pinned = p.dockApps.mapNotNull { map[it] }
        val recents = if (p.dockRecents > 0) p.recentPackages.mapNotNull { map[it] }
            .filter { r -> pinned.none { it.packageName == r.packageName } }.take(p.dockRecents) else emptyList()
        pinned + recents
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val mediaState: StateFlow<MediaPlaybackState> = CarMediaNotificationListenerService.mediaState
    val telemetryState: StateFlow<TelemetryState> = telemetryManager.telemetry
    private val baseStatus = telemetryManager.systemStatus
    val systemStatus: StateFlow<SystemStatusState> = baseStatus

    /** Corrected wall-clock, ticking every second (only runs while something observes it). */
    val now: StateFlow<Long> = flow {
        while (true) {
            val t = timeGuard.now()
            emit(t)
            delay(1000L - (t % 1000L))
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(3000), timeGuard.now())

    /** Slow ticker for anything that only needs minute resolution (sun, prayers). */
    private val minuteTick: Flow<Long> = flow {
        while (true) { emit(timeGuard.now()); delay(20_000L) }
    }

    /** true = night, false = day, null = follow the system uiMode. */
    val nightOverride: StateFlow<Boolean?> = combine(_prefs, minuteTick, telemetryManager.telemetry.map { it.hasGpsFix }) { p, t, _ ->
        when (p.dayNightMode) {
            DayNightMode.FORCE_DAY -> false
            DayNightMode.FORCE_NIGHT -> true
            DayNightMode.AUTO_SYSTEM -> null
            DayNightMode.AUTO_SUN -> {
                val (lat, lon) = effectiveLatLon(p)
                SolarCalc.isNight(t, lat, lon)
            }
            DayNightMode.SCHEDULE -> {
                val cal = java.util.Calendar.getInstance().apply { timeInMillis = t }
                val m = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE)
                if (p.nightStartMin <= p.nightEndMin) m in p.nightStartMin until p.nightEndMin
                else m >= p.nightStartMin || m < p.nightEndMin
            }
        }
    }.distinctUntilChanged().stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val _weather = MutableStateFlow(WeatherState())
    val weather: StateFlow<WeatherState> = _weather.asStateFlow()

    private var lastBoostMb = -1
    val health: StateFlow<HealthState> = flow {
        while (true) {
            emit(SystemTools.readHealth(getApplication(), lastBoostMb))
            delay(4000L)
        }
    }.flowOn(Dispatchers.IO).stateIn(viewModelScope, SharingStarted.WhileSubscribed(3000), HealthState())

    var onRequestLocation: () -> Unit = {}
    var onRequestCalendar: () -> Unit = {}

    // ------------------------------------------------------------------ UI state
    var currentScreen by mutableStateOf(LauncherScreen.DASHBOARD)
        private set
    var isOledDimmerActive by mutableStateOf(false)
        private set
    var showSplitAppDialog by mutableStateOf(false)
        private set
    var splitPreselectedPrimary by mutableStateOf<String?>(null)
        private set
    var pendingValetAction by mutableStateOf<ValetAction?>(null)
        private set
    var appBeingEdited by mutableStateOf<AppEntry?>(null)
        private set
    var toastMessage by mutableStateOf<String?>(null)
        private set
    var editMode by mutableStateOf(false)
        private set
    var dashboardPage by mutableStateOf(0)
    var optionsWidgetId by mutableStateOf<String?>(null)
        private set
    var showAddWidget by mutableStateOf(false)
        private set
    var pickerTarget by mutableStateOf<PickerTarget?>(null)
        private set
    var showDockEditor by mutableStateOf(false)
        private set

    // ------------------------------------------------------------------ init
    init {
        viewModelScope.launch {
            val loaded = repo.load()
            val pages = WidgetLayout.sanitize(
                loaded.pages.ifEmpty { WidgetLayout.defaultPages() }, loaded.gridCols, loaded.gridRows
            )
            _prefs.value = loaded.copy(pages = pages)
            prefsLoaded = true
            timeGuard.enabled = loaded.timeGuard
            _prefs.drop(1).debounce(400).collect { repo.save(it) }
        }
        viewModelScope.launch { _prefs.map { it.timeGuard }.distinctUntilChanged().collect { timeGuard.enabled = it } }

        telemetryManager.onFix = { lat, lon ->
            val p = _prefs.value
            if (prefsLoaded && !p.manualLocation && (kotlin.math.abs(p.lastLat - lat) > 0.01 || kotlin.math.abs(p.lastLon - lon) > 0.01)) {
                update { it.copy(lastLat = lat, lastLon = lon) }
            }
        }
        timeGuard.start()
        telemetryManager.start()
        CarMediaNotificationListenerService.refreshPermissionStatus(getApplication())

        viewModelScope.launch { timeGuard.clockWrong.collect { telemetryManager.setClockWrong(it) } }
        viewModelScope.launch { _iconPacks.value = iconProcessor.discoverIconPacks() }
        viewModelScope.launch { _rawApps.value = iconProcessor.loadInstalledApps() }
        viewModelScope.launch {
            iconProcessor.observePackageChanges().collect {
                _iconPacks.value = iconProcessor.discoverIconPacks()
                _rawApps.value = iconProcessor.loadInstalledApps()
            }
        }
        // icons: rebuild when apps or the icon style change
        viewModelScope.launch {
            combine(_rawApps, _prefs.map { styleOf(it) }.distinctUntilChanged()) { apps, style -> apps to style }
                .debounce(150)
                .collectLatest { (apps, style) ->
                    val dock = _prefs.value.dockApps.toSet()
                    val ordered = apps.sortedBy { if (it.packageName in dock) 0 else 1 }
                    val acc = HashMap(_icons.value)
                    var n = 0
                    for (app in ordered) {
                        acc[app.packageName] = iconProcessor.getProcessedIcon(app, style, 160)
                        if (++n % 12 == 0) _icons.value = HashMap(acc)
                    }
                    _icons.value = HashMap(acc)
                }
        }
        // speed chime
        viewModelScope.launch {
            combine(telemetryState.map { it.speedKmh }, _prefs.map { Triple(it.speedGuardEnabled && it.speedChime, it.speedLimitKmh, 0) }.distinctUntilChanged()) { s, g -> s to g }
                .collect { (speed, g) -> telemetryManager.playSpeedWarningChimeIfNeeded(g.first, speed, g.second) }
        }
        // weather refresh (only if a weather widget exists)
        viewModelScope.launch {
            while (true) {
                val p = _prefs.value
                if (prefsLoaded && p.pages.any { pg -> pg.widgets.any { it.type == WidgetType.WEATHER } }) {
                    val (lat, lon) = effectiveLatLon(p)
                    WeatherRepository.fetch(lat, lon)?.let { _weather.value = it }
                }
                delay(if (_weather.value.ok) 20 * 60_000L else 60_000L)
            }
        }
    }

    private fun styleOf(p: LauncherPreferences) = IconStyle(p.iconShape, p.iconBackdrop, p.useAppleGlyphs, p.iconZoom, p.iconBorder, p.activeIconPackPackage)

    private fun applyUserPrefs(raw: List<AppEntry>, p: LauncherPreferences): List<AppEntry> {
        val order = p.appOrder.withIndex().associate { it.value to it.index }
        return raw.withIndex().map { (i, a) ->
            a.copy(
                customLabel = p.customLabels[a.packageName],
                isHidden = a.packageName in p.hiddenPackages,
                sortOrder = order[a.packageName] ?: (1000 + i)
            )
        }.sortedBy { it.sortOrder }
    }

    fun effectiveLatLon(p: LauncherPreferences = _prefs.value): Pair<Double, Double> {
        if (p.manualLocation) {
            val c = Cities.list[p.manualCityIdx.coerceIn(0, Cities.list.lastIndex)]
            return c.second to c.third
        }
        val t = telemetryState.value
        if (t.hasGpsFix && t.latitude != 0.0) return t.latitude to t.longitude
        return p.lastLat to p.lastLon
    }

    // ------------------------------------------------------------------ preferences
    fun update(block: (LauncherPreferences) -> LauncherPreferences) {
        _prefs.update(block)
    }

    fun toast(msg: String) { toastMessage = msg }
    fun consumeToast() { toastMessage = null }

    fun onPermissionsUpdated() {
        telemetryManager.refreshPermissionsAndStatus()
        CarMediaNotificationListenerService.refreshPermissionStatus(getApplication())
    }

    // ------------------------------------------------------------------ navigation
    fun toggleDashboardAndGrid() {
        editMode = false
        currentScreen = if (currentScreen == LauncherScreen.APP_GRID) LauncherScreen.DASHBOARD else LauncherScreen.APP_GRID
    }

    fun navigateTo(screen: LauncherScreen) {
        if (screen == LauncherScreen.SETTINGS && _prefs.value.valetModeEnabled) {
            pendingValetAction = ValetAction.OpenSettings
        } else {
            editMode = false
            currentScreen = screen
        }
    }

    fun navigateBackToDashboard() { currentScreen = LauncherScreen.DASHBOARD; showDockEditor = false }

    fun requestAppEdit(app: AppEntry) {
        if (_prefs.value.valetModeEnabled) pendingValetAction = ValetAction.EditApp(app) else appBeingEdited = app
    }

    fun dismissAppEdit() { appBeingEdited = null }

    fun verifyValetPin(pin: String): Boolean {
        val ok = pin == _prefs.value.valetPin
        if (ok) {
            val a = pendingValetAction
            pendingValetAction = null
            when (a) {
                ValetAction.OpenSettings -> currentScreen = LauncherScreen.SETTINGS
                is ValetAction.EditApp -> appBeingEdited = a.app
                null -> Unit
            }
        }
        return ok
    }

    fun dismissValetPrompt() { pendingValetAction = null }
    fun setOledDimmer(active: Boolean) { isOledDimmerActive = active }

    fun openSplitAppDialog(pkg: String? = null) { splitPreselectedPrimary = pkg; showSplitAppDialog = true }
    fun dismissSplitAppDialog() { showSplitAppDialog = false; splitPreselectedPrimary = null }

    fun launchSplitScreen(a: String, b: String) {
        dismissSplitAppDialog()
        AppLauncherHelper.launchSplitScreenPair(getApplication(), a, b)
        recordRecentApp(a); recordRecentApp(b)
    }

    fun launchApp(app: AppEntry) {
        val ok = AppLauncherHelper.launchEntry(
            getApplication(), app, _prefs.value.navProvider,
            onOpenSettings = { navigateTo(LauncherScreen.SETTINGS) },
            onOpenDashboard = { navigateBackToDashboard() }
        )
        if (ok && app.virtualAction != AppLauncherHelper.VIRTUAL_SETTINGS) recordRecentApp(app.packageName)
    }

    fun launchPackage(pkg: String) {
        val app = allApps.value.firstOrNull { it.packageName == pkg }
        if (app != null) launchApp(app) else AppLauncherHelper.launchSpec(getApplication(), pkg)
    }

    private fun recordRecentApp(pkg: String) {
        update { p -> p.copy(recentPackages = (listOf(pkg) + p.recentPackages.filter { it != pkg }).take(8)) }
    }

    // ------------------------------------------------------------------ apps
    fun renameApp(pkg: String, name: String) = update { p ->
        val m = p.customLabels.toMutableMap()
        if (name.isBlank()) m.remove(pkg) else m[pkg] = name.trim()
        p.copy(customLabels = m)
    }

    fun setAppHidden(pkg: String, hidden: Boolean) = update { p ->
        p.copy(hiddenPackages = if (hidden) p.hiddenPackages + pkg else p.hiddenPackages - pkg,
            dockApps = if (hidden) p.dockApps - pkg else p.dockApps)
    }

    fun moveAppInOrder(pkg: String, delta: Int) {
        val vis = visibleApps.value.map { it.packageName }.toMutableList()
        val idx = vis.indexOf(pkg)
        if (idx < 0) return
        val t = (idx + delta).coerceIn(0, vis.lastIndex)
        if (t == idx) return
        vis.removeAt(idx); vis.add(t, pkg)
        val hidden = allApps.value.filter { it.isHidden }.map { it.packageName }
        update { it.copy(appOrder = vis + hidden) }
    }

    // ------------------------------------------------------------------ sidebar
    fun isInDock(pkg: String) = _prefs.value.dockApps.contains(pkg)

    fun toggleDock(pkg: String) = update { p ->
        p.copy(dockApps = if (pkg in p.dockApps) p.dockApps - pkg else p.dockApps + pkg)
    }

    fun moveDock(pkg: String, delta: Int) = update { p ->
        val l = p.dockApps.toMutableList()
        val i = l.indexOf(pkg)
        if (i < 0) return@update p
        val t = (i + delta).coerceIn(0, l.lastIndex)
        l.removeAt(i); l.add(t, pkg)
        p.copy(dockApps = l)
    }

    fun openPicker(t: PickerTarget?) { pickerTarget = t }
    fun openDockEditor(v: Boolean) { showDockEditor = v }

    fun setShortcutApps(widgetId: String, apps: List<String>) = mutateWidget(widgetId) {
        it.copy(options = it.options + ("apps" to apps.joinToString("|")))
    }

    // ------------------------------------------------------------------ widgets
    fun enterEditMode() { editMode = true; currentScreen = LauncherScreen.DASHBOARD }
    fun exitEditMode() { editMode = false; optionsWidgetId = null; showAddWidget = false }
    fun openWidgetOptions(id: String?) { optionsWidgetId = id }
    fun openAddWidget(v: Boolean) { showAddWidget = v }

    private fun mutateWidget(id: String, f: (WidgetInstance) -> WidgetInstance) = update { p ->
        p.copy(pages = p.pages.map { pg -> pg.copy(widgets = pg.widgets.map { if (it.id == id) f(it) else it }) })
    }

    fun setWidgetOption(id: String, key: String, value: String) = mutateWidget(id) { it.copy(options = it.options + (key to value)) }

    fun addWidget(type: WidgetType) {
        val p = _prefs.value
        val (pages, idx) = WidgetLayout.addWidget(p.pages, type, p.gridCols, p.gridRows, dashboardPage)
        update { it.copy(pages = pages) }
        dashboardPage = idx
        toast(if (idx == p.pages.size) "Added on a new page" else "${type.title} added")
    }

    fun removeWidget(id: String) {
        if (optionsWidgetId == id) optionsWidgetId = null
        update { p -> p.copy(pages = p.pages.map { pg -> pg.copy(widgets = pg.widgets.filter { it.id != id }) }) }
    }

    fun moveWidget(id: String, col: Int, row: Int) {
        val p = _prefs.value
        val pi = p.pages.indexOfFirst { pg -> pg.widgets.any { it.id == id } }
        if (pi < 0) return
        val res = WidgetLayout.moveWidget(p.pages[pi].widgets, id, col, row, p.gridCols, p.gridRows) ?: return
        update { it.copy(pages = it.pages.mapIndexed { i, pg -> if (i == pi) pg.copy(widgets = res) else pg }) }
    }

    fun resizeWidget(id: String, w: Int, h: Int) {
        val p = _prefs.value
        val pi = p.pages.indexOfFirst { pg -> pg.widgets.any { it.id == id } }
        if (pi < 0) return
        val res = WidgetLayout.resizeWidget(p.pages[pi].widgets, id, w, h, p.gridCols, p.gridRows)
        if (res == null) { toast("No room to resize here"); return }
        update { it.copy(pages = it.pages.mapIndexed { i, pg -> if (i == pi) pg.copy(widgets = res) else pg }) }
    }

    fun moveWidgetToPage(id: String, target: Int) {
        val p = _prefs.value
        val from = p.pages.indexOfFirst { pg -> pg.widgets.any { it.id == id } }
        if (from < 0 || target !in p.pages.indices || target == from) return
        val w = p.pages[from].widgets.first { it.id == id }
        val spot = WidgetLayout.findSpot(p.pages[target].widgets, p.gridCols, p.gridRows, w.w, w.h)
        if (spot == null) { toast("That page is full"); return }
        update { cur ->
            cur.copy(pages = cur.pages.mapIndexed { i, pg ->
                when (i) {
                    from -> pg.copy(widgets = pg.widgets.filter { it.id != id })
                    target -> pg.copy(widgets = pg.widgets + w.copy(col = spot.first, row = spot.second))
                    else -> pg
                }
            })
        }
        dashboardPage = target
    }

    fun addPage() {
        update { it.copy(pages = it.pages + WidgetPage(WidgetLayout.newId("p"), emptyList())) }
        dashboardPage = _prefs.value.pages.lastIndex
    }

    fun removePage(index: Int) {
        val p = _prefs.value
        if (p.pages.size <= 1) { toast("At least one page is required"); return }
        update { it.copy(pages = it.pages.filterIndexed { i, _ -> i != index }) }
        dashboardPage = dashboardPage.coerceAtMost(_prefs.value.pages.lastIndex)
    }

    fun movePage(index: Int, delta: Int) {
        val p = _prefs.value
        val t = index + delta
        if (t !in p.pages.indices) return
        val l = p.pages.toMutableList()
        val pg = l.removeAt(index); l.add(t, pg)
        update { it.copy(pages = l) }
        dashboardPage = t
    }

    fun setGrid(cols: Int, rows: Int) = update { p ->
        p.copy(gridCols = cols, gridRows = rows, pages = WidgetLayout.sanitize(p.pages, cols, rows))
    }

    fun resetLayout() = update { p -> p.copy(pages = WidgetLayout.sanitize(WidgetLayout.defaultPages(), p.gridCols, p.gridRows)) }

    // ------------------------------------------------------------------ tools
    fun resetTrip() { telemetryManager.resetTrip(); toast("Trip reset") }

    fun saveParking() {
        val t = telemetryState.value
        val (lat, lon) = if (t.hasGpsFix) t.latitude to t.longitude else effectiveLatLon()
        update { it.copy(hasParking = true, parkLat = lat, parkLon = lon, parkTimeMs = timeGuard.now()) }
        toast("Parking spot saved")
    }

    fun clearParking() = update { it.copy(hasParking = false) }

    fun navigateToParking() {
        val p = _prefs.value
        if (p.hasParking) AppLauncherHelper.openMapsAt(getApplication(), p.parkLat, p.parkLon, p.navProvider, true)
    }

    fun boostMemory() {
        viewModelScope.launch {
            toast("Cleaning memory…")
            val keep = buildSet {
                mediaState.value.sourcePackage?.let { add(it) }
                add(_prefs.value.navProvider.packageName)
                addAll(_prefs.value.dockApps)
            }
            val freed = SystemTools.boost(getApplication(), keep)
            lastBoostMb = freed
            toast(if (freed > 0) "Freed about $freed MB" else "Memory already clean")
        }
    }

    fun refreshWeatherNow() {
        viewModelScope.launch {
            val (lat, lon) = effectiveLatLon()
            WeatherRepository.fetch(lat, lon)?.let { _weather.value = it }
        }
    }

    // ------------------------------------------------------------------ backup
    fun setCustomWallpaperUri(uri: Uri) {
        runCatching {
            getApplication<Application>().contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        update { it.copy(wallpaperPreset = WallpaperPreset.CUSTOM_IMAGE, customWallpaperUri = uri.toString()) }
    }

    fun exportBackup(uri: Uri) {
        viewModelScope.launch { toast(if (repo.exportToUri(uri, _prefs.value)) "Settings exported" else "Export failed") }
    }

    fun importBackup(uri: Uri) {
        viewModelScope.launch {
            val p = repo.importFromUri(uri)
            if (p != null) {
                val pages = WidgetLayout.sanitize(p.pages.ifEmpty { WidgetLayout.defaultPages() }, p.gridCols, p.gridRows)
                _prefs.value = p.copy(pages = pages)
                iconProcessor.clearCache()
                toast("Settings restored")
            } else toast("Could not read backup file")
        }
    }

    override fun onCleared() {
        super.onCleared()
        telemetryManager.stop()
        timeGuard.stop()
    }
}
