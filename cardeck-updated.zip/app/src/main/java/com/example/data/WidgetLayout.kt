package com.example.data

import com.example.model.*

/** Pure grid logic for the customizable widget pages (no Android dependencies). */
object WidgetLayout {

    private var counter = 0L
    fun newId(prefix: String): String {
        counter++
        return prefix + java.lang.Long.toString(System.nanoTime() + counter, 36)
    }

    private fun occupancy(widgets: List<WidgetInstance>, cols: Int, rows: Int, ignoreId: String? = null): BooleanArray {
        val occ = BooleanArray(cols * rows)
        for (w in widgets) {
            if (w.id == ignoreId) continue
            for (r in w.row until (w.row + w.h)) for (c in w.col until (w.col + w.w)) {
                if (r in 0 until rows && c in 0 until cols) occ[r * cols + c] = true
            }
        }
        return occ
    }

    fun fits(widgets: List<WidgetInstance>, cols: Int, rows: Int, col: Int, row: Int, w: Int, h: Int, ignoreId: String? = null): Boolean {
        if (col < 0 || row < 0 || w < 1 || h < 1 || col + w > cols || row + h > rows) return false
        val occ = occupancy(widgets, cols, rows, ignoreId)
        for (r in row until row + h) for (c in col until col + w) if (occ[r * cols + c]) return false
        return true
    }

    fun findSpot(widgets: List<WidgetInstance>, cols: Int, rows: Int, w: Int, h: Int, ignoreId: String? = null): Pair<Int, Int>? {
        if (w > cols || h > rows) return null
        val occ = occupancy(widgets, cols, rows, ignoreId)
        for (r in 0..(rows - h)) for (c in 0..(cols - w)) {
            var free = true
            loop@ for (rr in r until r + h) for (cc in c until c + w) if (occ[rr * cols + cc]) { free = false; break@loop }
            if (free) return c to r
        }
        return null
    }

    fun widgetAt(widgets: List<WidgetInstance>, col: Int, row: Int, ignoreId: String? = null): WidgetInstance? =
        widgets.firstOrNull { it.id != ignoreId && col >= it.col && col < it.col + it.w && row >= it.row && row < it.row + it.h }

    /** Adds [type] to the first page with room. Returns the new pages and the index of the page used. */
    fun addWidget(pages: List<WidgetPage>, type: WidgetType, cols: Int, rows: Int, preferPage: Int): Pair<List<WidgetPage>, Int> {
        val order = buildList {
            if (preferPage in pages.indices) add(preferPage)
            pages.indices.forEach { if (it != preferPage) add(it) }
        }
        val sizes = listOf(type.defW to type.defH, type.minW to type.minH).distinct()
            .map { (a, b) -> a.coerceAtMost(cols) to b.coerceAtMost(rows) }
        for (pi in order) {
            for ((w, h) in sizes) {
                val spot = findSpot(pages[pi].widgets, cols, rows, w, h)
                if (spot != null) {
                    val inst = WidgetInstance(newId("w"), type, spot.first, spot.second, w, h)
                    val out = pages.toMutableList()
                    out[pi] = pages[pi].copy(widgets = pages[pi].widgets + inst)
                    return out to pi
                }
            }
        }
        val (w, h) = sizes.first()
        val inst = WidgetInstance(newId("w"), type, 0, 0, w, h)
        return (pages + WidgetPage(newId("p"), listOf(inst))) to pages.size
    }

    /** Move a widget to a target cell. Swaps with a same-sized widget when dropped on it. */
    fun moveWidget(widgets: List<WidgetInstance>, id: String, col: Int, row: Int, cols: Int, rows: Int): List<WidgetInstance>? {
        val me = widgets.firstOrNull { it.id == id } ?: return null
        val c = col.coerceIn(0, cols - me.w)
        val r = row.coerceIn(0, rows - me.h)
        if (c == me.col && r == me.row) return null
        if (fits(widgets, cols, rows, c, r, me.w, me.h, ignoreId = id)) {
            return widgets.map { if (it.id == id) it.copy(col = c, row = r) else it }
        }
        // swap when dropped over exactly one widget that can take our place
        val under = widgets.filter { o ->
            o.id != id && o.col < c + me.w && o.col + o.w > c && o.row < r + me.h && o.row + o.h > r
        }
        if (under.size == 1) {
            val o = under[0]
            val others = widgets.filter { it.id != id && it.id != o.id }
            if (fits(others, cols, rows, c, r, me.w, me.h) && fits(others + me.copy(col = c, row = r), cols, rows, me.col, me.row, o.w, o.h)) {
                return widgets.map {
                    when (it.id) {
                        id -> it.copy(col = c, row = r)
                        o.id -> it.copy(col = me.col, row = me.row)
                        else -> it
                    }
                }
            }
        }
        return null
    }

    fun resizeWidget(widgets: List<WidgetInstance>, id: String, nw: Int, nh: Int, cols: Int, rows: Int): List<WidgetInstance>? {
        val me = widgets.firstOrNull { it.id == id } ?: return null
        val w = nw.coerceIn(me.type.minW.coerceAtMost(cols), cols)
        val h = nh.coerceIn(me.type.minH.coerceAtMost(rows), rows)
        if (w == me.w && h == me.h) return null
        if (fits(widgets, cols, rows, me.col, me.row, w, h, ignoreId = id)) {
            return widgets.map { if (it.id == id) it.copy(w = w, h = h) else it }
        }
        val spot = findSpot(widgets, cols, rows, w, h, ignoreId = id) ?: return null
        return widgets.map { if (it.id == id) it.copy(w = w, h = h, col = spot.first, row = spot.second) else it }
    }

    /** Make every page valid for the given grid; widgets that cannot fit are moved to extra pages. */
    fun sanitize(pages: List<WidgetPage>, cols: Int, rows: Int): List<WidgetPage> {
        val out = ArrayList<WidgetPage>()
        val overflow = ArrayList<WidgetInstance>()
        for (page in pages) {
            val placed = ArrayList<WidgetInstance>()
            val sorted = page.widgets.sortedWith(compareBy({ it.row }, { it.col }))
            for (w0 in sorted) {
                val w = w0.w.coerceIn(1, cols)
                val h = w0.h.coerceIn(1, rows)
                if (fits(placed, cols, rows, w0.col, w0.row, w, h)) {
                    placed.add(w0.copy(w = w, h = h))
                } else {
                    val spot = findSpot(placed, cols, rows, w, h)
                    if (spot != null) placed.add(w0.copy(w = w, h = h, col = spot.first, row = spot.second)) else overflow.add(w0.copy(w = w, h = h))
                }
            }
            out.add(page.copy(widgets = placed))
        }
        if (overflow.isNotEmpty()) {
            var cur = ArrayList<WidgetInstance>()
            for (w in overflow) {
                var spot = findSpot(cur, cols, rows, w.w, w.h)
                if (spot == null) {
                    out.add(WidgetPage(newId("p"), cur)); cur = ArrayList()
                    spot = findSpot(cur, cols, rows, w.w, w.h) ?: (0 to 0)
                }
                cur.add(w.copy(col = spot.first, row = spot.second))
            }
            if (cur.isNotEmpty()) out.add(WidgetPage(newId("p"), cur))
        }
        return if (out.isEmpty()) listOf(WidgetPage(newId("p"), emptyList())) else out
    }

    private fun w(type: WidgetType, c: Int, r: Int, w: Int, h: Int, opts: Map<String, String> = emptyMap()) =
        WidgetInstance(newId("w"), type, c, r, w, h, opts)

    fun defaultPages(): List<WidgetPage> = listOf(
        WidgetPage(
            newId("p"), listOf(
                w(WidgetType.MAP, 0, 0, 2, 2),
                w(WidgetType.NOW_PLAYING, 2, 0, 2, 1),
                w(WidgetType.SPEED, 2, 1, 1, 1),
                w(WidgetType.CLOCK, 3, 1, 1, 1)
            )
        ),
        WidgetPage(
            newId("p"), listOf(
                w(WidgetType.QUICK_CONTROLS, 0, 0, 2, 1),
                w(WidgetType.PRAYER, 2, 0, 2, 1),
                w(WidgetType.TRIP, 0, 1, 2, 1),
                w(WidgetType.WEATHER, 2, 1, 1, 1),
                w(WidgetType.SYSTEM, 3, 1, 1, 1)
            )
        )
    )
}
