package com.example.engine

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Environment
import android.os.StatFs
import com.example.model.HealthState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Memory / temperature / storage readout and a safe "memory boost" for low-RAM head units. */
object SystemTools {

    fun readHealth(context: Context, lastBoostMb: Int = -1): HealthState {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val total = (mi.totalMem / 1048576L).toInt()
        val free = (mi.availMem / 1048576L).toInt()
        val stat = runCatching { StatFs(Environment.getDataDirectory().path) }.getOrNull()
        val totalGb = stat?.let { it.blockCountLong * it.blockSizeLong / 1073741824f } ?: 0f
        val freeGb = stat?.let { it.availableBlocksLong * it.blockSizeLong / 1073741824f } ?: 0f
        return HealthState(total, free, readCpuTemp(), totalGb, freeGb, lastBoostMb)
    }

    private fun readCpuTemp(): Float {
        var best = -1f
        runCatching {
            val zones = File("/sys/class/thermal").listFiles { f -> f.name.startsWith("thermal_zone") }?.sortedBy { it.name }.orEmpty()
            for (z in zones) {
                val type = runCatching { File(z, "type").readText().trim().lowercase() }.getOrDefault("")
                val raw = runCatching { File(z, "temp").readText().trim().toFloat() }.getOrNull() ?: continue
                val c = if (raw > 1000f) raw / 1000f else raw
                if (c < 5f || c > 130f) continue
                if (type.contains("cpu") || type.contains("soc") || type.contains("big") || type.contains("little")) return c
                if (best < 0f) best = c
            }
        }
        return best
    }

    /**
     * Asks Android to drop cached background processes of ordinary apps. Never touches the launcher,
     * the app that is currently playing media, the navigation app, system apps or head-unit services.
     * Returns the approximate MB freed.
     */
    suspend fun boost(context: Context, protectedPackages: Set<String>): Int = withContext(Dispatchers.Default) {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val before = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
        val pm = context.packageManager
        val skipPrefixes = listOf("com.nwd.", "com.android.", "android", "com.google.android.gms", "com.google.android.inputmethod",
            "com.zlink", "com.zjinnova", "com.sprd", "com.allwinner", "com.softwinner")
        runCatching {
            val launchIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val pkgs = pm.queryIntentActivities(launchIntent, 0).map { it.activityInfo.packageName }.distinct()
            for (p in pkgs) {
                if (p == context.packageName || p in protectedPackages) continue
                if (skipPrefixes.any { p.startsWith(it) }) continue
                val sys = runCatching {
                    (pm.getApplicationInfo(p, 0).flags and ApplicationInfo.FLAG_SYSTEM) != 0
                }.getOrDefault(true)
                if (sys) continue
                runCatching { am.killBackgroundProcesses(p) }
            }
        }
        kotlinx.coroutines.delay(900L)
        val after = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
        ((after - before) / 1048576L).toInt().coerceAtLeast(0)
    }

    @Suppress("unused")
    fun hasPermission(context: Context, p: String) =
        context.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
}
