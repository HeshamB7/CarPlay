package com.example

import android.Manifest
import android.content.res.Configuration
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.engine.AppLauncherHelper
import com.example.model.DockSide
import com.example.model.LauncherPreferences
import com.example.model.LauncherScreen
import com.example.ui.common.*
import com.example.ui.screens.AppGridScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.SettingsActions
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.CarDeckTheme
import com.example.ui.theme.AdaptiveDensity
import com.example.viewmodel.LauncherViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: LauncherViewModel by viewModels()

    private val locationLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        viewModel.onPermissionsUpdated()
    }
    private val calendarLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        viewModel.onPermissionsUpdated()
    }
    private val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) viewModel.exportBackup(uri)
    }
    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.importBackup(uri)
    }
    private val wallpaperLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.setCustomWallpaperUri(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        viewModel.onRequestLocation = {
            locationLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }
        viewModel.onRequestCalendar = { calendarLauncher.launch(Manifest.permission.READ_CALENDAR) }

        val actions = SettingsActions(
            onExport = { exportLauncher.launch("cardeck-settings.json") },
            onImport = { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) },
            onPickWallpaper = { wallpaperLauncher.launch(arrayOf("image/*")) },
            onDefaultLauncher = { AppLauncherHelper.openDefaultHomeSettings(this) },
            onNotificationAccess = { AppLauncherHelper.openNotificationListenerSettings(this) },
            onLocationPermission = { viewModel.onRequestLocation() },
            onCalendarPermission = { viewModel.onRequestCalendar() }
        )

        setContent {
            val prefs by viewModel.preferences.collectAsStateWithLifecycle()
            val nightOverride by viewModel.nightOverride.collectAsStateWithLifecycle()
            val systemNight = (LocalConfiguration.current.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
            val isNight = nightOverride ?: systemNight
            CarDeckTheme(isNight = isNight, prefs = prefs) {
                AdaptiveDensity(prefs.autoFit, prefs.uiScale, prefs.fontScale) { _, _ ->
                    CarDeckRoot(viewModel, prefs, isNight, actions)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.onPermissionsUpdated()
    }
}

@Composable
private fun CarDeckRoot(vm: LauncherViewModel, prefs: LauncherPreferences, isNight: Boolean, actions: SettingsActions) {
    val context = LocalContext.current
    val apps by vm.visibleApps.collectAsStateWithLifecycle()
    val dockApps by vm.dockApps.collectAsStateWithLifecycle()
    val icons by vm.processedIcons.collectAsStateWithLifecycle()
    val media by vm.mediaState.collectAsStateWithLifecycle()
    val tel by vm.telemetryState.collectAsStateWithLifecycle()

    LaunchedEffect(vm.toastMessage) {
        vm.toastMessage?.let { Toast.makeText(context, it, Toast.LENGTH_SHORT).show(); vm.consumeToast() }
    }

    BackHandler(enabled = true) {
        when {
            vm.pickerTarget != null -> vm.openPicker(null)
            vm.optionsWidgetId != null -> vm.openWidgetOptions(null)
            vm.showAddWidget -> vm.openAddWidget(false)
            vm.appBeingEdited != null -> vm.dismissAppEdit()
            vm.showSplitAppDialog -> vm.dismissSplitAppDialog()
            vm.isOledDimmerActive -> vm.setOledDimmer(false)
            vm.editMode -> vm.exitEditMode()
            vm.currentScreen != LauncherScreen.DASHBOARD -> vm.navigateBackToDashboard()
        }
    }

    Box(Modifier.fillMaxSize()) {
        WallpaperBackground(prefs, isNight)

        val dock: @Composable () -> Unit = {
            CarDock(vm, prefs, dockApps, icons, vm.currentScreen) { AppLauncherHelper.triggerVoiceAssistant(context) }
        }
        Row(Modifier.fillMaxSize().safeDrawingPadding()) {
            if (prefs.dockSide == DockSide.LEFT) dock()
            Box(Modifier.weight(1f).fillMaxHeight()) {
                val reduce = prefs.reduceMotion
                AnimatedContent(
                    targetState = vm.currentScreen,
                    transitionSpec = {
                        if (reduce) EnterTransition.None togetherWith ExitTransition.None
                        else (fadeIn(tween(240)) + scaleIn(tween(240), initialScale = 0.97f)) togetherWith fadeOut(tween(140))
                    },
                    label = "screen"
                ) { screen ->
                    when (screen) {
                        LauncherScreen.DASHBOARD -> DashboardScreen(vm, prefs)
                        LauncherScreen.APP_GRID -> AppGridScreen(vm, prefs, apps, icons)
                        LauncherScreen.SETTINGS -> SettingsScreen(vm, prefs, actions)
                    }
                }
            }
            if (prefs.dockSide == DockSide.RIGHT) dock()
        }

        if (vm.showAddWidget) AddWidgetSheet(vm)
        vm.optionsWidgetId?.let { WidgetOptionsSheet(vm, prefs, it) }
        vm.pickerTarget?.let { AppPickerSheet(vm, it, prefs, apps, icons) }
        vm.appBeingEdited?.let { app -> AppActionsSheet(vm, app, icons[app.packageName], prefs) }
        if (vm.showSplitAppDialog) SplitPickerSheet(vm, apps, icons, vm.splitPreselectedPrimary)
        if (vm.pendingValetAction != null) ValetPinSheet(onVerify = { vm.verifyValetPin(it) }, onDismiss = { vm.dismissValetPrompt() })
        if (!prefs.onboardingCompleted) {
            OnboardingSheet(
                hasLocation = tel.hasLocationPermission, hasMedia = media.hasNotificationPermission,
                onLocation = { vm.onRequestLocation() },
                onMedia = { AppLauncherHelper.openNotificationListenerSettings(context) },
                onHome = { AppLauncherHelper.openDefaultHomeSettings(context) },
                onFinish = { vm.update { it.copy(onboardingCompleted = true) } }
            )
        }
        if (vm.isOledDimmerActive) DimmerOverlay(vm, prefs)
    }
}
