# CarDeck (Apple CarPlay-style launcher for Android head units)

## What's new in this version
- **Real Apple icon shape** (iOS continuous-corner squircle), flat artwork, no fake gloss. Hand-built Apple-style icons for
  system apps (Phone, Messages, Music, Maps, Settings, Camera, Calculator, Clock, Calendar, Files, Photos, Weather, Radio,
  Bluetooth, vehicle, rear camera...). Other apps keep their own artwork inside the same squircle.
- **Customisable sidebar**: pick any apps, reorder, optional recents, side/width/style/icon size.
- **Widget pages**: unlimited pages, drag/resize/restyle widgets, 13 widget types with per-widget options.
- **Fits any screen**: the whole UI is scaled from a 960x540 dp design to the real display (plus your own UI size).
- **iOS type scale** with Inter (SF Pro cannot be bundled: Apple's licence only allows it on Apple platforms).
- Many more settings (accent, wallpapers, card styles, grid, icon options, motion, backup/restore...).

## Regenerating the glyph icons
`tools/icons.py` is the single source for the Apple-style icons. Edit it, run `python3 tools/gen_glyphs.py`
and copy the generated `AppleGlyphs.kt` into `app/src/main/java/com/example/engine/`.
