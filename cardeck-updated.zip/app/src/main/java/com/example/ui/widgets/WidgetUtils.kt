package com.example.ui.widgets

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ui.common.pressable
import com.example.ui.theme.LocalCarTokens

/** Header line used by most widgets: tinted icon + title. */
@Composable
fun WidgetTitle(icon: ImageVector, title: String, tint: Color, modifier: Modifier = Modifier, trailing: String? = null) {
    val t = LocalCarTokens.current
    Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp))
        Text(title, style = MaterialTheme.typography.labelMedium, color = t.secondaryLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (trailing != null) {
            Spacer(Modifier.weight(1f))
            Text(trailing, style = MaterialTheme.typography.labelMedium, color = tint, maxLines = 1)
        }
    }
}

@Composable
fun RoundIconButton(icon: ImageVector, desc: String, size: Int = 48, tint: Color? = null, bg: Color? = null, onClick: () -> Unit) {
    val t = LocalCarTokens.current
    Box(
        Modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(bg ?: Color.Transparent)
            .pressable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, desc, tint = tint ?: t.label, modifier = Modifier.size((size * 0.55f).dp))
    }
}

@Composable
fun ActionTile(icon: ImageVector, label: String, active: Boolean, activeColor: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val t = LocalCarTokens.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (active) activeColor.copy(alpha = 0.9f) else t.fill)
            .pressable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, label, tint = if (active) Color.White else t.label, modifier = Modifier.size(26.dp))
        Spacer(Modifier.height(4.dp))
        Text(
            label, style = MaterialTheme.typography.labelSmall,
            color = if (active) Color.White else t.secondaryLabel, maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

fun cardinal(deg: Float): String {
    val names = listOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
    return names[(((deg % 360f) + 360f) % 360f / 45f + 0.5f).toInt() % 8]
}
