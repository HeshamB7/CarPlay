import math
def squircle_points(S, radius_ratio=0.2237, smoothing=0.6):
    """Return list of path commands ('M'|'L'|'C', pts) using figma-squircle algorithm."""
    r = S*radius_ratio
    cs = smoothing
    p = (1+cs)*r
    p = min(p, S/2)
    arc_measure = 90*(1-cs)
    arc_len = math.sin(math.radians(arc_measure/2))*r*math.sqrt(2)
    alpha = (90-arc_measure)/2
    p3p4 = r*math.tan(math.radians(alpha/2))
    beta = 45*cs
    c = p3p4*math.cos(math.radians(beta))
    d = c*math.tan(math.radians(beta))
    b = (p - arc_len - c - d)/3
    a = 2*b
    th = math.radians(arc_measure)
    be = math.radians(beta)
    k = 4/3*math.tan(th/4)*r
    # canonical corner (top-right) relative vectors starting at (W-p,0)
    segs = [
        ((a,0),(a+b,0),(a+b+c,d)),
    ]
    # arc cubic: from heading be to be+th
    t0 = (math.cos(be), math.sin(be)); t1=(math.cos(be+th), math.sin(be+th))
    e1 = (a+b+c, d)
    e2 = (e1[0]+arc_len, e1[1]+arc_len)
    segs.append(((e1[0]+k*t0[0], e1[1]+k*t0[1]), (e2[0]-k*t1[0], e2[1]-k*t1[1]), e2))
    segs.append(((e2[0]+d, e2[1]+c),(e2[0]+d, e2[1]+b+c),(e2[0]+d, e2[1]+a+b+c)))
    return p, segs

def rot(v,k):
    x,y=v
    for _ in range(k): x,y=-y,x
    return (x,y)

def squircle_svg_path(S, **kw):
    p, segs = squircle_points(S, **kw)
    cmds=[]
    # start at top-right corner start
    cur=(S-p,0.0)
    cmds.append(f"M{cur[0]:.3f} {cur[1]:.3f}")
    corners_start=[(S-p,0.0),(S,S-p),(p,S),(0.0,p)]
    for k in range(4):
        st=corners_start[k]
        if k>0:
            cmds.append(f"L{st[0]:.3f} {st[1]:.3f}")
        # relative segments in canonical frame; rotate by k
        base=st
        for (c1,c2,e) in segs:
            pts=[]
            for v in (c1,c2,e):
                rv=rot(v,k)
                pts.append((st[0]+rv[0], st[1]+rv[1]))
            cmds.append("C"+" ".join(f"{x:.3f} {y:.3f}" for x,y in pts))
    cmds.append("Z")
    return " ".join(cmds)

if __name__=="__main__":
    d=squircle_svg_path(100)
    print(d[:200])
    svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 100 100"><rect width="100" height="100" fill="#ddd"/><path d="{d}" fill="#0a84ff"/></svg>'
    import cairosvg; cairosvg.svg2png(bytestring=svg.encode(), write_to='/tmp/sq.png')
