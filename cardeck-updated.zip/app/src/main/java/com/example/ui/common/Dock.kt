package com.example.ui.common

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.engine.AppLauncherHelper
import com.example.model.*
import com.example.ui.theme.LocalCarTokens
import com.example.viewmodel.LauncherViewModel
import com.example.viewmodel.PickerTarget

@Composable
fun CarDock(
    vm: LauncherViewModel,
    prefs: LauncherPreferences,
    apps: List<AppEntry>,
    icons: Map<String, ImageBitmap>,
    screen: LauncherScreen,
    onVoice: () -> Unit
) {
    val t = LocalCarTokens.current
    val width = when (prefs.dockWidthLevel) { 0 -> 76.dp; 2 -> 112.dp; else -> 92.dp }
    val shape = RoundedCornerShape(if (prefs.dockStyle == DockStyle.FLUSH) 0.dp else 28.dp)
    val bg = when (prefs.dockStyle) {
        DockStyle.TRANSPARENT -> Color.Transparent
        else -> t.cardBase.copy(alpha = (prefs.cardAlpha + 0.1f).coerceIn(0.5f, 0.96f))
    }
    val outer = if (prefs.dockStyle == DockStyle.FLOATING) Modifier.padding(8.dp) else Modifier
    Column(
        modifier = Modifier
            .width(width)
            .fillMaxHeight()
            .then(outer)
            .clip(shape)
            .background(bg)
            .then(if (prefs.dockStyle == DockStyle.TRANSPARENT) Modifier else Modifier.border(0.75.dp, t.cardBorder, shape))
            .padding(vertical = 12.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (prefs.dockShowClock || prefs.dockShowStatus) DockStatus(vm, prefs)
        Spacer(Modifier.height(6.dp))
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (apps.isEmpty()) {
                item {
                    Box(Modifier.size(prefs.dockIconSizeDp.dp).clip(RoundedCornerShape(14.dp)).background(t.fill).pressable { vm.openPicker(PickerTarget.Dock) }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Add, "Add apps", tint = t.secondaryLabel)
                    }
                }
            }
            items(apps, key = { it.packageName }) { app ->
                DockItem(app, icons[app.packageName], prefs, onClick = { vm.launchApp(app) }, onLong = { vm.requestAppEdit(app) })
            }
        }
        Spacer(Modifier.height(6.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (prefs.dockShowDimmer) SmallRound(Icons.Rounded.Bedtime, "Dim screen", false) { vm.setOledDimmer(true) }
                if (prefs.dockShowSettings) SmallRound(Icons.Rounded.Settings, "Settings", screen == LauncherScreen.SETTINGS) { vm.navigateTo(LauncherScreen.SETTINGS) }
            }
            if (prefs.dockShowVoice) VoiceOrb(onVoice)
            HomeSwitch(isDashboard = screen != LauncherScreen.APP_GRID) { vm.toggleDashboardAndGrid() }
        }
    }
}

@Composable
private fun DockStatus(vm: LauncherViewModel, prefs: LauncherPreferences) {
    val t = LocalCarTokens.current
    val ctx = LocalContext.current
    val status by vm.systemStatus.collectAsStateWithLifecycle()
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (prefs.dockShowClock) DockClock(vm, prefs)
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
            if (status.clockWrong && prefs.timeGuard) {
                Icon(Icons.Rounded.WarningAmber, "System clock is wrong", tint = t.orange, modifier = Modifier.size(16.dp).pressable { AppLauncherHelper.openDateSettings(ctx) })
            }
            if (prefs.dockShowStatus) {
                SignalBars(status.isCellularConnected || status.isWifiConnected, t.label, t.tertiaryLabel)
                if (status.isWifiConnected) Icon(Icons.Rounded.Wifi, "Wi-Fi", tint = t.label, modifier = Modifier.size(14.dp))
                if (status.isBluetoothEnabled) Icon(Icons.Rounded.Bluetooth, "Bluetooth", tint = t.label, modifier = Modifier.size(13.dp))
            }
        }
    }
}

@Composable
private fun DockClock(vm: LauncherViewModel, prefs: LauncherPreferences) {
    val t = LocalCarTokens.current
    val now by vm.now.collectAsStateWithLifecycle()
    Text(Fmt.time(now, prefs.use24h, false, prefs.arabicDigits), style = MaterialTheme.typography.titleLarge, color = t.label, maxLines = 1, textAlign = TextAlign.Center)
}

@Composable
private fun DockItem(app: AppEntry, icon: ImageBitmap?, prefs: LauncherPreferences, onClick: () -> Unit, onLong: () -> Unit) {
    val t = LocalCarTokens.current
    Column(
        Modifier.pressable(onLongClick = onLong, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val sz = prefs.dockIconSizeDp.dp
        if (icon != null) Image(icon, app.displayName, Modifier.size(sz))
        else Box(Modifier.size(sz).clip(RoundedCornerShape(sz * 0.22f)).background(t.fill))
        if (prefs.dockShowLabels) Text(app.displayName, style = MaterialTheme.typography.labelSmall, color = t.label, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 3.dp).widthIn(max = 84.dp))
    }
}

@Composable
private fun SmallRound(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, active: Boolean, onClick: () -> Unit) {
    val t = LocalCarTokens.current
    Box(
        Modifier.size(38.dp).clip(CircleShape).background(if (active) t.accent.copy(alpha = 0.25f) else t.fill).pressable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, desc, tint = if (active) t.accent else t.secondaryLabel, modifier = Modifier.size(18.dp)) }
}

@Composable
private fun VoiceOrb(onClick: () -> Unit) {
    Box(Modifier.size(44.dp).clip(CircleShape).pressable(onClick = onClick), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(32.dp)) {
            drawCircle(Brush.sweepGradient(listOf(Color(0xFF00C2FF), Color(0xFF7B61FF), Color(0xFFFF375F), Color(0xFF30D158), Color(0xFF00C2FF))), style = Stroke(3.4.dp.toPx()))
            drawCircle(Brush.radialGradient(listOf(Color(0x665E5CE6), Color(0x220A84FF), Color.Transparent)), radius = size.minDimension * 0.42f)
        }
    }
}

@Composable
private fun HomeSwitch(isDashboard: Boolean, onClick: () -> Unit) {
    val t = LocalCarTokens.current
    Box(Modifier.size(50.dp).clip(CircleShape).pressable(onClick = onClick), contentAlignment = Alignment.Center) {
        val fg = t.label
        Canvas(Modifier.size(24.dp)) {
            if (isDashboard) {
                val cell = size.width * 0.26f
                val gap = (size.width - cell * 3) / 2f
                val r = CornerRadius(2.5.dp.toPx())
                for (row in 0 until 3) for (col in 0 until 3) drawRoundRect(fg, Offset(col * (cell + gap), row * (cell + gap)), Size(cell, cell), r)
            } else {
                val r = CornerRadius(3.dp.toPx())
                val lw = size.width * 0.52f; val rw = size.width * 0.36f; val gap = size.width * 0.12f
                val hh = (size.height - gap) / 2f
                drawRoundRect(fg, Offset.Zero, Size(lw, size.height), r)
                drawRoundRect(fg, Offset(lw + gap, 0f), Size(rw, hh), r)
                drawRoundRect(fg, Offset(lw + gap, hh + gap), Size(rw, hh), r)
            }
        }
    }
}

@Composable
private fun SignalBars(connected: Boolean, active: Color, inactive: Color) {
    Canvas(Modifier.size(width = 16.dp, height = 11.dp)) {
        val bw = size.width / 6.2f
        val gap = bw * 0.6f
        listOf(0.35f, 0.55f, 0.78f, 1f).forEachIndexed { i, f ->
            val h = size.height * f
            drawRoundRect(if (connected) active else inactive, Offset(i * (bw + gap), size.height - h), Size(bw, h), CornerRadius(bw / 2f))
        }
    }
}
