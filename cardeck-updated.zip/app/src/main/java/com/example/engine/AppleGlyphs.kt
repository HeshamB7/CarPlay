package com.example.engine

// GENERATED from tools/icons.py - Apple-style glyph icon specs (100x100 grid).

internal class GS(val fill: Int = 0, val stroke: Int = 0, val sw: Float = 0f, val op: Float = 1f, val round: Boolean = false,
                  val rd: Float = 0f, val rx: Float = 50f, val ry: Float = 50f, val ts: Float = 1f, val tx: Float = 0f, val ty: Float = 0f)
internal sealed class GL(val s: GS)
internal class GCircle(val cx: Float, val cy: Float, val r: Float, s: GS) : GL(s)
internal class GRect(val x: Float, val y: Float, val w: Float, val h: Float, val rr: Float, s: GS) : GL(s)
internal class GPath(val d: String, s: GS) : GL(s)
internal class GlyphSpec(val top: Int, val bottom: Int, val layers: List<GL>)

internal object AppleGlyphs {
    val all: Map<String, GlyphSpec> by lazy { build() }

    private fun build(): Map<String, GlyphSpec> = mapOf(
        "phone" to GlyphSpec(0xFF6BEE7B.toInt(), 0xFF1CC03A.toInt(), listOf(
            GPath("M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z", GS(fill=0xFFFFFFFF.toInt(), ts=2.9f,tx=15.2f,ty=15.4f))
        )),
        "messages" to GlyphSpec(0xFF6BEE7B.toInt(), 0xFF1CC03A.toInt(), listOf(
            GPath("M50 20 C32 20 18 31.6 18 46 C18 54.2 22.6 61.4 29.8 66.2 C29 71.4 26.4 76.2 22 80 C30.6 79.4 37.4 76.2 41.8 72.4 C44.4 72.8 47.2 73 50 73 C68 73 82 61.4 82 46 C82 31.6 68 20 50 20 Z", GS(fill=0xFFFFFFFF.toInt()))
        )),
        "music" to GlyphSpec(0xFFFF6A86.toInt(), 0xFFF92140.toInt(), listOf(
            GPath("M42 30 L80 22 L80 66 L72 66 L72 36 L50 41 L50 72 L42 72 Z", GS(fill=0xFFFFFFFF.toInt())),
            GCircle(38f, 73f, 10.5f, GS(fill=0xFFFFFFFF.toInt())),
            GCircle(68f, 67f, 10.5f, GS(fill=0xFFFFFFFF.toInt()))
        )),
        "nowplaying" to GlyphSpec(0xFF4A4A4D.toInt(), 0xFF17171A.toInt(), listOf(
            GRect(22f, 44f, 9f, 24f, 4.5f, GS(fill=0xFFFF375F.toInt())),
            GRect(35f, 30f, 9f, 52f, 4.5f, GS(fill=0xFFFF375F.toInt())),
            GRect(48f, 22f, 9f, 64f, 4.5f, GS(fill=0xFFFF375F.toInt())),
            GRect(61f, 34f, 9f, 44f, 4.5f, GS(fill=0xFFFF375F.toInt())),
            GRect(74f, 46f, 9f, 20f, 4.5f, GS(fill=0xFFFF375F.toInt()))
        )),
        "podcasts" to GlyphSpec(0xFFC468F5.toInt(), 0xFF7B2AD6.toInt(), listOf(
            GPath("M30 58 A24 24 0 1 1 70 58", GS(stroke=0xFFFFFFFF.toInt(), sw=6f, round=true)),
            GPath("M38.5 53 A14 14 0 1 1 61.5 53", GS(stroke=0xFFFFFFFF.toInt(), sw=6f, round=true)),
            GCircle(50f, 46f, 6.5f, GS(fill=0xFFFFFFFF.toInt())),
            GRect(44f, 56f, 12f, 26f, 6f, GS(fill=0xFFFFFFFF.toInt()))
        )),
        "books" to GlyphSpec(0xFFFFB04F.toInt(), 0xFFFF7A00.toInt(), listOf(
            GPath("M48 33 C40 27 28 26 18 29 L18 72 C28 69 40 70 48 76 Z", GS(fill=0xFFFFFFFF.toInt())),
            GPath("M52 33 C60 27 72 26 82 29 L82 72 C72 69 60 70 52 76 Z", GS(fill=0xFFFFFFFF.toInt()))
        )),
        "settings" to GlyphSpec(0xFFA7A7AE.toInt(), 0xFF6A6A72.toInt(), listOf(
            GRect(45.5f, 5f, 9f, 16f, 2.5f, GS(fill=0xFFE4E4E9.toInt(), rd=0f,rx=50f,ry=50f)),
            GRect(45.5f, 5f, 9f, 16f, 2.5f, GS(fill=0xFFE4E4E9.toInt(), rd=30f,rx=50f,ry=50f)),
            GRect(45.5f, 5f, 9f, 16f, 2.5f, GS(fill=0xFFE4E4E9.toInt(), rd=60f,rx=50f,ry=50f)),
            GRect(45.5f, 5f, 9f, 16f, 2.5f, GS(fill=0xFFE4E4E9.toInt(), rd=90f,rx=50f,ry=50f)),
            GRect(45.5f, 5f, 9f, 16f, 2.5f, GS(fill=0xFFE4E4E9.toInt(), rd=120f,rx=50f,ry=50f)),
            GRect(45.5f, 5f, 9f, 16f, 2.5f, GS(fill=0xFFE4E4E9.toInt(), rd=150f,rx=50f,ry=50f)),
            GRect(45.5f, 5f, 9f, 16f, 2.5f, GS(fill=0xFFE4E4E9.toInt(), rd=180f,rx=50f,ry=50f)),
            GRect(45.5f, 5f, 9f, 16f, 2.5f, GS(fill=0xFFE4E4E9.toInt(), rd=210f,rx=50f,ry=50f)),
            GRect(45.5f, 5f, 9f, 16f, 2.5f, GS(fill=0xFFE4E4E9.toInt(), rd=240f,rx=50f,ry=50f)),
            GRect(45.5f, 5f, 9f, 16f, 2.5f, GS(fill=0xFFE4E4E9.toInt(), rd=270f,rx=50f,ry=50f)),
            GRect(45.5f, 5f, 9f, 16f, 2.5f, GS(fill=0xFFE4E4E9.toInt(), rd=300f,rx=50f,ry=50f)),
            GRect(45.5f, 5f, 9f, 16f, 2.5f, GS(fill=0xFFE4E4E9.toInt(), rd=330f,rx=50f,ry=50f)),
            GCircle(50f, 50f, 30f, GS(fill=0xFFE4E4E9.toInt())),
            GCircle(50f, 50f, 17f, GS(fill=0xFF5E5E66.toInt())),
            GCircle(50f, 50f, 9f, GS(fill=0xFFC9C9CF.toInt()))
        )),
        "camera" to GlyphSpec(0xFFDADADF.toInt(), 0xFF98989F.toInt(), listOf(
            GRect(32f, 24f, 22f, 12f, 5f, GS(fill=0xFF2B2B2E.toInt())),
            GRect(14f, 30f, 72f, 50f, 11f, GS(fill=0xFF2B2B2E.toInt())),
            GCircle(50f, 56f, 19f, GS(fill=0xFF555559.toInt())),
            GCircle(50f, 56f, 14f, GS(fill=0xFF161618.toInt())),
            GCircle(50f, 56f, 6f, GS(fill=0xFF2E3A63.toInt())),
            GRect(71f, 37f, 9f, 6f, 3f, GS(fill=0xFFE8E8EC.toInt()))
        )),
        "calculator" to GlyphSpec(0xFF4B4B50.toInt(), 0xFF1B1B1E.toInt(), listOf(
            GRect(16f, 16f, 68f, 20f, 6f, GS(fill=0xFF2A2A2D.toInt())),
            GRect(16f, 42f, 14f, 14f, 5f, GS(fill=0xFFA5A5AA.toInt())),
            GRect(34f, 42f, 14f, 14f, 5f, GS(fill=0xFFA5A5AA.toInt())),
            GRect(52f, 42f, 14f, 14f, 5f, GS(fill=0xFFA5A5AA.toInt())),
            GRect(70f, 42f, 14f, 14f, 5f, GS(fill=0xFFFF9F0A.toInt())),
            GRect(16f, 60f, 14f, 14f, 5f, GS(fill=0xFF5E5E63.toInt())),
            GRect(34f, 60f, 14f, 14f, 5f, GS(fill=0xFF5E5E63.toInt())),
            GRect(52f, 60f, 14f, 14f, 5f, GS(fill=0xFF5E5E63.toInt())),
            GRect(70f, 60f, 14f, 14f, 5f, GS(fill=0xFFFF9F0A.toInt())),
            GRect(16f, 78f, 14f, 10f, 4f, GS(fill=0xFF5E5E63.toInt())),
            GRect(34f, 78f, 14f, 10f, 4f, GS(fill=0xFF5E5E63.toInt())),
            GRect(52f, 78f, 14f, 10f, 4f, GS(fill=0xFF5E5E63.toInt())),
            GRect(70f, 78f, 14f, 10f, 4f, GS(fill=0xFFFF9F0A.toInt()))
        )),
        "files" to GlyphSpec(0xFFFFFFFF.toInt(), 0xFFE9ECF4.toInt(), listOf(
            GPath("M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z", GS(fill=0xFF2D8CFF.toInt(), ts=3.2f,tx=11.6f,ty=13.5f))
        )),
        "weather" to GlyphSpec(0xFF59B4FF.toInt(), 0xFF2273E6.toInt(), listOf(
            GCircle(38f, 40f, 15f, GS(fill=0xFFFFD60A.toInt())),
            GCircle(42f, 66f, 14f, GS(fill=0xFFFFFFFF.toInt())),
            GCircle(58f, 60f, 18f, GS(fill=0xFFFFFFFF.toInt())),
            GCircle(72f, 69f, 12f, GS(fill=0xFFFFFFFF.toInt())),
            GRect(32f, 66f, 48f, 15f, 7.5f, GS(fill=0xFFFFFFFF.toInt()))
        )),
        "photos" to GlyphSpec(0xFFFFFFFF.toInt(), 0xFFF2F2F7.toInt(), listOf(
            GPath("M50 50 C40 38 40 20 50 14 C60 20 60 38 50 50 Z", GS(fill=0xFFFF9F0A.toInt(), op=0.9f, rd=0f,rx=50f,ry=50f)),
            GPath("M50 50 C40 38 40 20 50 14 C60 20 60 38 50 50 Z", GS(fill=0xFFFFD60A.toInt(), op=0.9f, rd=45f,rx=50f,ry=50f)),
            GPath("M50 50 C40 38 40 20 50 14 C60 20 60 38 50 50 Z", GS(fill=0xFFA3E635.toInt(), op=0.9f, rd=90f,rx=50f,ry=50f)),
            GPath("M50 50 C40 38 40 20 50 14 C60 20 60 38 50 50 Z", GS(fill=0xFF30D158.toInt(), op=0.9f, rd=135f,rx=50f,ry=50f)),
            GPath("M50 50 C40 38 40 20 50 14 C60 20 60 38 50 50 Z", GS(fill=0xFF32ADE6.toInt(), op=0.9f, rd=180f,rx=50f,ry=50f)),
            GPath("M50 50 C40 38 40 20 50 14 C60 20 60 38 50 50 Z", GS(fill=0xFF5E5CE6.toInt(), op=0.9f, rd=225f,rx=50f,ry=50f)),
            GPath("M50 50 C40 38 40 20 50 14 C60 20 60 38 50 50 Z", GS(fill=0xFFBF5AF2.toInt(), op=0.9f, rd=270f,rx=50f,ry=50f)),
            GPath("M50 50 C40 38 40 20 50 14 C60 20 60 38 50 50 Z", GS(fill=0xFFFF375F.toInt(), op=0.9f, rd=315f,rx=50f,ry=50f))
        )),
        "radio" to GlyphSpec(0xFFFF6B6B.toInt(), 0xFFE02447.toInt(), listOf(
            GRect(16f, 38f, 68f, 44f, 9f, GS(fill=0xFFFFFFFF.toInt())),
            GPath("M64 38 L80 18", GS(stroke=0xFFFFFFFF.toInt(), sw=4.5f, round=true)),
            GCircle(36f, 60f, 12f, GS(fill=0xFFE02447.toInt())),
            GCircle(36f, 60f, 5f, GS(fill=0xFFFFFFFF.toInt())),
            GRect(56f, 48f, 18f, 4.5f, 2.2f, GS(fill=0xFFE02447.toInt())),
            GRect(56f, 58f, 18f, 4.5f, 2.2f, GS(fill=0xFFE02447.toInt())),
            GRect(56f, 68f, 12f, 4.5f, 2.2f, GS(fill=0xFFE02447.toInt()))
        )),
        "bluetooth" to GlyphSpec(0xFF46A8FF.toInt(), 0xFF0A5FE0.toInt(), listOf(
            GPath("M34 36 L66 64 L50 78 L50 22 L66 36 L34 64", GS(stroke=0xFFFFFFFF.toInt(), sw=7f, round=true))
        )),
        "btmusic" to GlyphSpec(0xFF46A8FF.toInt(), 0xFF0A5FE0.toInt(), listOf(
            GPath("M42 30 L74 22 L74 62 L67 62 L67 36 L49 40 L49 68 L42 68 Z", GS(fill=0xFFFFFFFF.toInt())),
            GCircle(38f, 69f, 9.5f, GS(fill=0xFFFFFFFF.toInt())),
            GCircle(62f, 63f, 9.5f, GS(fill=0xFFFFFFFF.toInt()))
        )),
        "vehicle" to GlyphSpec(0xFF5C6676.toInt(), 0xFF242A36.toInt(), listOf(
            GPath("M9 62 L9 53 C9 48 12 45 17 44 L29 42 L39 30 C41 27 44 26 47 26 L66 26 C70 26 73 28 75 31 L80 41 L86 43 C90 44 92 47 92 51 L92 62 Z", GS(fill=0xFFFFFFFF.toInt())),
            GPath("M41 41 L47 32 L58 32 L58 41 Z", GS(fill=0xFF4A5466.toInt())),
            GPath("M62 41 L62 32 L67 32 L73 41 Z", GS(fill=0xFF4A5466.toInt())),
            GCircle(31f, 66f, 10f, GS(fill=0xFF242A36.toInt())),
            GCircle(31f, 66f, 6f, GS(fill=0xFFFFFFFF.toInt())),
            GCircle(71f, 66f, 10f, GS(fill=0xFF242A36.toInt())),
            GCircle(71f, 66f, 6f, GS(fill=0xFFFFFFFF.toInt()))
        )),
        "backcam" to GlyphSpec(0xFF3A3A3E.toInt(), 0xFF0B0B0D.toInt(), listOf(
            GPath("M30 84 L41 28", GS(stroke=0xFF32D74B.toInt(), sw=5f, round=true)),
            GPath("M70 84 L59 28", GS(stroke=0xFF32D74B.toInt(), sw=5f, round=true)),
            GPath("M33 68 L67 68", GS(stroke=0xFFFFD60A.toInt(), sw=5f, round=true)),
            GPath("M36 52 L64 52", GS(stroke=0xFFFF9F0A.toInt(), sw=5f, round=true)),
            GPath("M39 38 L61 38", GS(stroke=0xFFFF453A.toInt(), sw=5f, round=true))
        )),
        "contacts" to GlyphSpec(0xFFC3C3C9.toInt(), 0xFF8A8A92.toInt(), listOf(
            GPath("M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z", GS(fill=0xFFFFFFFF.toInt(), ts=3.4f,tx=9.2f,ty=10.5f))
        )),
        "video" to GlyphSpec(0xFF3A3A3E.toInt(), 0xFF0B0B0D.toInt(), listOf(
            GCircle(50f, 50f, 30f, GS(stroke=0xFFFFFFFF.toInt(), sw=5f)),
            GPath("M43 36 L66 50 L43 64 Z", GS(fill=0xFFFFFFFF.toInt()))
        )),
        "navigation" to GlyphSpec(0xFF3FA2FF.toInt(), 0xFF0A60E0.toInt(), listOf(
            GPath("M12 2L4.5 20.29l.71.71L12 18l6.79 3 .71-.71z", GS(fill=0xFFFFFFFF.toInt(), ts=3.6f,tx=6.8f,ty=8.5f))
        )),
        "browser" to GlyphSpec(0xFFFFFFFF.toInt(), 0xFFE9ECF4.toInt(), listOf(
            GCircle(50f, 50f, 34f, GS(fill=0xFF1C8CFF.toInt())),
            GCircle(50f, 50f, 28f, GS(fill=0xFFFFFFFF.toInt())),
            GPath("M50 24 L58 50 L50 76 L42 50 Z", GS(fill=0xFFFF3B30.toInt(), rd=40f,rx=50f,ry=50f)),
            GPath("M50 24 L58 50 L42 50 Z", GS(fill=0xFF1C8CFF.toInt(), rd=40f,rx=50f,ry=50f))
        )),
        "maps" to GlyphSpec(0xFFF4F1E9.toInt(), 0xFFF4F1E9.toInt(), listOf(
            GPath("M0 0 L44 0 L36 40 L0 46 Z", GS(fill=0xFFA6DB9B.toInt())),
            GPath("M62 100 L100 56 L100 100 Z", GS(fill=0xFF9ED0F7.toInt())),
            GPath("M-10 72 L110 38", GS(stroke=0xFFFFFFFF.toInt(), sw=17f)),
            GPath("M-10 72 L110 38", GS(stroke=0xFFFFD34E.toInt(), sw=11f)),
            GPath("M44 112 L58 -12", GS(stroke=0xFFFFFFFF.toInt(), sw=20f)),
            GPath("M44 112 L58 -12", GS(stroke=0xFF3B8DFF.toInt(), sw=13f)),
            GCircle(50f, 60f, 17f, GS(fill=0xFFFFFFFF.toInt())),
            GCircle(50f, 60f, 13.5f, GS(fill=0xFF0A84FF.toInt())),
            GPath("M12 2L4.5 20.29l.71.71L12 18l6.79 3 .71-.71z", GS(fill=0xFFFFFFFF.toInt(), ts=1.05f,tx=37.4f,ty=47.9f)),
            GRect(66f, 12f, 22f, 16f, 4f, GS(fill=0xFFFFFFFF.toInt())),
            GRect(68f, 14f, 18f, 5f, 2f, GS(fill=0xFFFF3B30.toInt())),
            GRect(68f, 20f, 18f, 6f, 2f, GS(fill=0xFF0A84FF.toInt()))
        )),
        "clock" to GlyphSpec(0xFF2A2A2D.toInt(), 0xFF000000.toInt(), listOf(
            GCircle(50f, 50f, 38f, GS(fill=0xFFFFFFFF.toInt())),
            GRect(48.8f, 15.5f, 2.4f, 8f, 1.2f, GS(fill=0xFF1C1C1E.toInt(), rd=0f,rx=50f,ry=50f)),
            GRect(48.8f, 15.5f, 2.4f, 4.5f, 1.2f, GS(fill=0xFF1C1C1E.toInt(), rd=30f,rx=50f,ry=50f)),
            GRect(48.8f, 15.5f, 2.4f, 4.5f, 1.2f, GS(fill=0xFF1C1C1E.toInt(), rd=60f,rx=50f,ry=50f)),
            GRect(48.8f, 15.5f, 2.4f, 8f, 1.2f, GS(fill=0xFF1C1C1E.toInt(), rd=90f,rx=50f,ry=50f)),
            GRect(48.8f, 15.5f, 2.4f, 4.5f, 1.2f, GS(fill=0xFF1C1C1E.toInt(), rd=120f,rx=50f,ry=50f)),
            GRect(48.8f, 15.5f, 2.4f, 4.5f, 1.2f, GS(fill=0xFF1C1C1E.toInt(), rd=150f,rx=50f,ry=50f)),
            GRect(48.8f, 15.5f, 2.4f, 8f, 1.2f, GS(fill=0xFF1C1C1E.toInt(), rd=180f,rx=50f,ry=50f)),
            GRect(48.8f, 15.5f, 2.4f, 4.5f, 1.2f, GS(fill=0xFF1C1C1E.toInt(), rd=210f,rx=50f,ry=50f)),
            GRect(48.8f, 15.5f, 2.4f, 4.5f, 1.2f, GS(fill=0xFF1C1C1E.toInt(), rd=240f,rx=50f,ry=50f)),
            GRect(48.8f, 15.5f, 2.4f, 8f, 1.2f, GS(fill=0xFF1C1C1E.toInt(), rd=270f,rx=50f,ry=50f)),
            GRect(48.8f, 15.5f, 2.4f, 4.5f, 1.2f, GS(fill=0xFF1C1C1E.toInt(), rd=300f,rx=50f,ry=50f)),
            GRect(48.8f, 15.5f, 2.4f, 4.5f, 1.2f, GS(fill=0xFF1C1C1E.toInt(), rd=330f,rx=50f,ry=50f)),
            GRect(48.2f, 28f, 3.6f, 24f, 1.8f, GS(fill=0xFF1C1C1E.toInt(), rd=305f,rx=50f,ry=50f)),
            GRect(48.6f, 22f, 2.8f, 32f, 1.4f, GS(fill=0xFF1C1C1E.toInt(), rd=54f,rx=50f,ry=50f)),
            GRect(49.4f, 20f, 1.2f, 36f, 0.6f, GS(fill=0xFFFF9F0A.toInt(), rd=180f,rx=50f,ry=50f)),
            GCircle(50f, 50f, 2.8f, GS(fill=0xFFFF9F0A.toInt()))
        )),
        "calendar" to GlyphSpec(0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), listOf(
            GRect(0f, 0f, 100f, 28f, 0f, GS(fill=0xFFFF3B30.toInt()))
        ))
    )
}
