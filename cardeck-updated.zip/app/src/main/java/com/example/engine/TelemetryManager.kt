package com.example.engine

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Looper
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import com.example.model.SystemStatusState
import com.example.model.TelemetryState
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** GPS speed, trip computer, connectivity and calendar. Uses the plain LocationManager (no Google services needed). */
class TelemetryManager(private val context: Context, private val clock: () -> Long) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val tripPrefs = context.getSharedPreferences("trip_stats", Context.MODE_PRIVATE)

    private val _systemStatus = MutableStateFlow(SystemStatusState())
    val systemStatus: StateFlow<SystemStatusState> = _systemStatus.asStateFlow()

    private val _telemetry = MutableStateFlow(
        TelemetryState(
            tripDistanceM = tripPrefs.getFloat("dist", 0f).toDouble(),
            tripMovingSec = tripPrefs.getLong("moving", 0L),
            tripMaxKmh = tripPrefs.getFloat("max", 0f),
            tripStartMs = tripPrefs.getLong("start", System.currentTimeMillis())
        )
    )
    val telemetry: StateFlow<TelemetryState> = _telemetry.asStateFlow()

    /** Reports a (lat, lon) fix roughly every few seconds so the app can remember the last position. */
    var onFix: ((Double, Double) -> Unit)? = null

    private var pollJob: Job? = null
    private var listening = false
    private var lastAlertToneMs = 0L
    private var prevLoc: Location? = null
    private var lastSaveMs = 0L
    private var lastFixReport = 0L

    private val listener = object : LocationListener {
        override fun onLocationChanged(loc: Location) = handleLocation(loc)
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    fun start() {
        refreshPermissionsAndStatus()
        pollJob?.cancel()
        pollJob = scope.launch {
            while (isActive) {
                updateSystemIndicators()
                delay(5000L)
            }
        }
        refreshNextCalendarEvent()
    }

    fun stop() {
        pollJob?.cancel()
        if (listening) {
            runCatching { lm.removeUpdates(listener) }
            listening = false
        }
        saveTrip(force = true)
    }

    fun resetTrip() {
        prevLoc = null
        _telemetry.value = _telemetry.value.copy(
            tripDistanceM = 0.0, tripMovingSec = 0L, tripMaxKmh = 0f, tripStartMs = clock()
        )
        saveTrip(force = true)
    }

    fun refreshPermissionsAndStatus() {
        val hasLocation = granted(Manifest.permission.ACCESS_FINE_LOCATION) || granted(Manifest.permission.ACCESS_COARSE_LOCATION)
        val hasCalendar = granted(Manifest.permission.READ_CALENDAR)
        _telemetry.value = _telemetry.value.copy(hasLocationPermission = hasLocation, hasCalendarPermission = hasCalendar)
        if (hasLocation && !listening) startLocationUpdates()
        if (hasCalendar) refreshNextCalendarEvent()
        updateSystemIndicators()
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(context, p) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun startLocationUpdates() {
        runCatching {
            val providers = lm.getProviders(true)
            if (LocationManager.GPS_PROVIDER in providers) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener, Looper.getMainLooper())
                listening = true
            }
            if (LocationManager.NETWORK_PROVIDER in providers) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 15000L, 50f, listener, Looper.getMainLooper())
                listening = true
            }
            val last = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            if (last != null) {
                _telemetry.value = _telemetry.value.copy(latitude = last.latitude, longitude = last.longitude)
                onFix?.invoke(last.latitude, last.longitude)
            }
        }
    }

    private fun handleLocation(loc: Location) {
        val isGps = loc.provider == LocationManager.GPS_PROVIDER
        val cur = _telemetry.value
        var speedKmh = cur.speedKmh
        var dist = cur.tripDistanceM
        var moving = cur.tripMovingSec
        var max = cur.tripMaxKmh

        if (isGps) {
            val raw = if (loc.hasSpeed()) loc.speed * 3.6f else 0f
            speedKmh = if (raw < 1.5f) 0f else raw
            val prev = prevLoc
            if (prev != null && (!loc.hasAccuracy() || loc.accuracy < 40f)) {
                val dtMs = loc.time - prev.time
                if (dtMs in 200..15_000) {
                    if (speedKmh > 3f) {
                        dist += prev.distanceTo(loc).toDouble().coerceAtMost(speedKmh / 3.6 * dtMs / 1000.0 * 2.0 + 5.0)
                        moving += Math.round(dtMs / 1000.0)
                        if (speedKmh > max && speedKmh < 330f) max = speedKmh
                    }
                }
            }
            prevLoc = loc
        }
        _telemetry.value = cur.copy(
            speedKmh = speedKmh,
            bearingDegrees = if (isGps && loc.hasBearing() && speedKmh > 3f) loc.bearing else cur.bearingDegrees,
            altitudeM = if (loc.hasAltitude()) loc.altitude else cur.altitudeM,
            latitude = loc.latitude,
            longitude = loc.longitude,
            hasGpsFix = cur.hasGpsFix || isGps,
            hasLocationPermission = true,
            tripDistanceM = dist,
            tripMovingSec = moving,
            tripMaxKmh = max
        )
        val now = System.currentTimeMillis()
        if (now - lastFixReport > 20_000L) {
            lastFixReport = now
            onFix?.invoke(loc.latitude, loc.longitude)
        }
        saveTrip(force = false)
    }

    private fun saveTrip(force: Boolean) {
        val now = System.currentTimeMillis()
        if (!force && now - lastSaveMs < 30_000L) return
        lastSaveMs = now
        val t = _telemetry.value
        tripPrefs.edit()
            .putFloat("dist", t.tripDistanceM.toFloat())
            .putLong("moving", t.tripMovingSec)
            .putFloat("max", t.tripMaxKmh)
            .putLong("start", t.tripStartMs)
            .apply()
    }

    fun playSpeedWarningChimeIfNeeded(enabled: Boolean, currentSpeedKmh: Float, limitKmh: Int) {
        if (!enabled || currentSpeedKmh <= limitKmh) return
        val now = System.currentTimeMillis()
        if (now - lastAlertToneMs < 8000L) return
        lastAlertToneMs = now
        scope.launch(Dispatchers.IO) {
            runCatching {
                val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 45)
                tone.startTone(ToneGenerator.TONE_PROP_BEEP, 180)
                delay(240L)
                tone.release()
            }
        }
    }

    private fun updateSystemIndicators() {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        var wifi = false
        var cellular = false
        runCatching {
            val caps = cm?.getNetworkCapabilities(cm.activeNetwork)
            if (caps != null) {
                wifi = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                cellular = caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
            }
        }
        val bt = runCatching {
            (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter?.isEnabled == true
        }.getOrDefault(false)
        val gps = runCatching { lm.isProviderEnabled(LocationManager.GPS_PROVIDER) }.getOrDefault(false) &&
            _telemetry.value.hasLocationPermission
        val cur = _systemStatus.value
        if (cur.isWifiConnected != wifi || cur.isCellularConnected != cellular || cur.isBluetoothEnabled != bt || cur.isGpsActive != gps) {
            _systemStatus.value = cur.copy(isWifiConnected = wifi, isCellularConnected = cellular, isBluetoothEnabled = bt, isGpsActive = gps)
        }
    }

    fun setClockWrong(wrong: Boolean) {
        if (_systemStatus.value.clockWrong != wrong) _systemStatus.value = _systemStatus.value.copy(clockWrong = wrong)
    }

    @SuppressLint("MissingPermission")
    fun refreshNextCalendarEvent() {
        if (!granted(Manifest.permission.READ_CALENDAR)) return
        scope.launch(Dispatchers.IO) {
            runCatching {
                val now = clock()
                val end = now + 24 * 60 * 60 * 1000L
                val projection = arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN)
                val ub = CalendarContract.Instances.CONTENT_URI.buildUpon()
                android.content.ContentUris.appendId(ub, now)
                android.content.ContentUris.appendId(ub, end)
                context.contentResolver.query(ub.build(), projection, null, null, "${CalendarContract.Instances.BEGIN} ASC")?.use { c ->
                    val t = if (c.moveToFirst()) c.getString(0) to c.getLong(1) else null
                    _telemetry.value = _telemetry.value.copy(nextEventTitle = t?.first, nextEventTimeMs = t?.second ?: 0L)
                }
            }
        }
    }
}
