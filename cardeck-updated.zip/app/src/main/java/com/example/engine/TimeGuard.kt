package com.example.engine

import android.content.Context
import android.net.ConnectivityManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import kotlin.math.abs

/**
 * Keeps a network-corrected clock. Head units often boot with a wrong date until a network time
 * sync happens; this lets every widget (clock, prayer, sunset, calendar) show the right time anyway.
 */
class TimeGuard(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    @Volatile
    private var offsetMs: Long = 0L
    private val _clockWrong = MutableStateFlow(false)
    val clockWrong: StateFlow<Boolean> = _clockWrong.asStateFlow()

    @Volatile
    var enabled: Boolean = true

    fun now(): Long = System.currentTimeMillis() + if (enabled) offsetMs else 0L

    fun start() {
        if (job?.isActive == true) return
        job = scope.launch {
            while (isActive) {
                val ok = if (hasNetwork()) sync() else false
                if (!ok) {
                    // offline: flag obviously wrong dates (older than this app's release)
                    _clockWrong.value = System.currentTimeMillis() < MIN_PLAUSIBLE_MS && offsetMs == 0L
                }
                delay(if (ok) 30 * 60_000L else 45_000L)
            }
        }
    }

    fun stop() {
        job?.cancel()
    }

    @Suppress("DEPRECATION")
    private fun hasNetwork(): Boolean = runCatching {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        cm.activeNetworkInfo?.isConnected == true
    }.getOrDefault(false)

    private fun sync(): Boolean {
        for (host in HOSTS) {
            val off = runCatching { queryOffset(host) }.getOrNull() ?: continue
            offsetMs = off
            _clockWrong.value = abs(off) > 2 * 60_000L
            return true
        }
        return false
    }

    /** Minimal SNTP client. Returns server time minus local time in ms. */
    private fun queryOffset(host: String): Long {
        DatagramSocket().use { socket ->
            socket.soTimeout = 4000
            val buf = ByteArray(48)
            buf[0] = 0x1B
            val addr = InetAddress.getByName(host)
            val t0 = System.currentTimeMillis()
            socket.send(DatagramPacket(buf, buf.size, addr, 123))
            val resp = DatagramPacket(ByteArray(48), 48)
            socket.receive(resp)
            val t3 = System.currentTimeMillis()
            val d = resp.data
            val t1 = readTs(d, 32)
            val t2 = readTs(d, 40)
            return ((t1 - t0) + (t2 - t3)) / 2
        }
    }

    private fun readTs(b: ByteArray, off: Int): Long {
        var sec = 0L
        var frac = 0L
        for (i in 0 until 4) sec = (sec shl 8) or (b[off + i].toLong() and 0xFF)
        for (i in 4 until 8) frac = (frac shl 8) or (b[off + i].toLong() and 0xFF)
        return (sec - 2_208_988_800L) * 1000L + frac * 1000L / 0x100000000L
    }

    companion object {
        private val HOSTS = listOf("time.google.com", "pool.ntp.org", "time.cloudflare.com", "ntp.aliyun.com")
        private const val MIN_PLAUSIBLE_MS = 1_767_225_600_000L // 2026-01-01
    }
}
