package com.example.ui.widgets

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.SpeedUnit
import com.example.model.WidgetInstance
import com.example.ui.common.Fmt
import com.example.ui.common.pressable
import com.example.ui.theme.LocalCarTokens
import com.example.viewmodel.LauncherViewModel
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun SpeedWidget(w: WidgetInstance, vm: LauncherViewModel) {
    val t = LocalCarTokens.current
    val prefs by vm.preferences.collectAsStateWithLifecycle()
    val tel by vm.telemetryState.collectAsStateWithLifecycle()
    val unit = when (w.str("unit")) { "kmh" -> SpeedUnit.KMH; "mph" -> SpeedUnit.MPH; else -> prefs.speedUnit }
    val f = if (unit == SpeedUnit.MPH) 0.621371f else 1f
    val speed = (tel.speedKmh * f).roundToInt()
    val limit = (prefs.speedLimitKmh * f).roundToInt()
    val over = prefs.speedGuardEnabled && tel.speedKmh > prefs.speedLimitKmh
    val near = prefs.speedGuardEnabled && !over && tel.speedKmh > prefs.speedLimitKmh * 0.9f
    val color by animateColorAsState(if (over) t.red else if (near) t.orange else t.label, tween(250), label = "spd")
    val unitLabel = if (unit == SpeedUnit.MPH) "mph" else "km/h"
    val maxSpeed = if (unit == SpeedUnit.MPH) 150f else 240f
    val frac by animateFloatAsState((speed / maxSpeed).coerceIn(0f, 1f), tween(400), label = "ring")

    BoxWithConstraints(Modifier.fillMaxSize().padding(12.dp)) {
        val small = maxHeight < 110.dp
        if (!tel.hasLocationPermission) {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Speed needs GPS", style = MaterialTheme.typography.labelMedium, color = t.secondaryLabel, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Text("Allow", style = MaterialTheme.typography.labelLarge, color = Color.White,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(t.accent)
                        .pressable { vm.onRequestLocation() }
                        .padding(horizontal = 14.dp, vertical = 8.dp))
            }
            return@BoxWithConstraints
        }
        if (w.str("style") == "ring" && !small) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxHeight().aspectRatio(1f)) {
                    val sw = 9.dp.toPx()
                    val inset = sw / 2f
                    val arcSize = androidx.compose.ui.geometry.Size(size.width - sw, size.height - sw)
                    drawArc(t.fill, 135f, 270f, false, Offset(inset, inset), arcSize, style = Stroke(sw, cap = StrokeCap.Round))
                    if (frac > 0.005f) drawArc(color, 135f, 270f * frac, false, Offset(inset, inset), arcSize, style = Stroke(sw, cap = StrokeCap.Round))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(speed.toString(), style = MaterialTheme.typography.displayMedium, color = color)
                    Text(unitLabel, style = MaterialTheme.typography.labelMedium, color = t.secondaryLabel)
                    if (w.on("limit")) Text("Limit $limit", style = MaterialTheme.typography.labelSmall, color = if (over) t.red else t.tertiaryLabel)
                }
            }
        } else {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                if (!small) WidgetTitle(Icons.Rounded.Speed, "Speed", t.accent, trailing = if (w.on("heading")) cardinal(tel.bearingDegrees) else null)
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(speed.toString(), style = (if (small) MaterialTheme.typography.displaySmall else MaterialTheme.typography.displayLarge), color = color, maxLines = 1)
                    Text(unitLabel, style = MaterialTheme.typography.labelMedium, color = t.secondaryLabel, modifier = Modifier.padding(bottom = 8.dp))
                }
                if (w.on("limit") && !small) {
                    Text(if (over) "Over limit ($limit)" else "Limit $limit", style = MaterialTheme.typography.labelMedium, color = if (over) t.red else t.secondaryLabel)
                }
            }
        }
    }
}

@Composable
fun ClockWidget(w: WidgetInstance, vm: LauncherViewModel) {
    val t = LocalCarTokens.current
    val prefs by vm.preferences.collectAsStateWithLifecycle()
    val seconds = w.on("seconds")
    val now by (if (seconds) vm.now else vm.now).collectAsStateWithLifecycle()
    val use24 = when (w.str("format")) { "12" -> false; "24" -> true; else -> prefs.use24h }
    val style = w.str("style")
    val digital = Fmt.time(now, use24, seconds, prefs.arabicDigits)
    val dateText = Fmt.date(now, "EEE, d MMM", prefs.arabicDigits, prefs.arabicDigits)

    BoxWithConstraints(Modifier.fillMaxSize().padding(12.dp)) {
        val wide = maxWidth > maxHeight * 1.5f
        val small = maxHeight < 100.dp
        @Composable fun digitalPart(modifier: Modifier, align: Alignment.Horizontal) {
            Column(modifier, horizontalAlignment = align, verticalArrangement = Arrangement.Center) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(digital, style = if (small) MaterialTheme.typography.headlineLarge else MaterialTheme.typography.displaySmall.copy(fontSize = 40.sp), color = t.label, maxLines = 1)
                    if (!use24) Text(" " + Fmt.ampm(now), style = MaterialTheme.typography.labelMedium, color = t.secondaryLabel, modifier = Modifier.padding(bottom = 6.dp))
                }
                if (w.on("date")) Text(dateText, style = MaterialTheme.typography.labelMedium, color = t.red, maxLines = 1)
            }
        }
        when (style) {
            "analog" -> AnalogClock(now, seconds, Modifier.fillMaxSize())
            "both" -> if (wide) Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AnalogClock(now, seconds, Modifier.fillMaxHeight().aspectRatio(1f))
                digitalPart(Modifier.weight(1f), Alignment.Start)
            } else Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                AnalogClock(now, seconds, Modifier.weight(1f).aspectRatio(1f))
                Text(digital, style = MaterialTheme.typography.titleMedium, color = t.label)
            }
            else -> digitalPart(Modifier.fillMaxSize(), if (wide) Alignment.Start else Alignment.CenterHorizontally)
        }
    }
}

@Composable
fun AnalogClock(nowMs: Long, showSeconds: Boolean, modifier: Modifier) {
    val t = LocalCarTokens.current
    val cal = remember(nowMs / 1000) { java.util.Calendar.getInstance().apply { timeInMillis = nowMs } }
    val h = cal.get(java.util.Calendar.HOUR) + cal.get(java.util.Calendar.MINUTE) / 60f
    val m = cal.get(java.util.Calendar.MINUTE) + cal.get(java.util.Calendar.SECOND) / 60f
    val s = cal.get(java.util.Calendar.SECOND).toFloat()
    Canvas(modifier) {
        val r = minOf(size.width, size.height) / 2f
        val c = center
        drawCircle(if (t.isNight) Color(0xFF2C2C2E) else Color.White, r)
        drawCircle(t.separator, r, style = Stroke(1.dp.toPx()))
        for (i in 0 until 60) {
            val big = i % 5 == 0
            val a = Math.toRadians(i * 6.0 - 90.0)
            val r1 = r * 0.94f
            val r2 = r * (if (big) 0.82f else 0.89f)
            drawLine(if (big) t.label else t.tertiaryLabel, Offset(c.x + cos(a).toFloat() * r1, c.y + sin(a).toFloat() * r1), Offset(c.x + cos(a).toFloat() * r2, c.y + sin(a).toFloat() * r2), if (big) 2.dp.toPx() else 1.dp.toPx(), StrokeCap.Round)
        }
        rotate(h * 30f, c) { drawLine(t.label, c, Offset(c.x, c.y - r * 0.5f), 4.5.dp.toPx(), StrokeCap.Round) }
        rotate(m * 6f, c) { drawLine(t.label, c, Offset(c.x, c.y - r * 0.76f), 3.dp.toPx(), StrokeCap.Round) }
        if (showSeconds) rotate(s * 6f, c) { drawLine(t.orange, Offset(c.x, c.y + r * 0.15f), Offset(c.x, c.y - r * 0.82f), 1.5.dp.toPx(), StrokeCap.Round) }
        drawCircle(if (showSeconds) t.orange else t.label, 4.dp.toPx(), c)
    }
}

@Composable
fun TripWidget(w: WidgetInstance, vm: LauncherViewModel) {
    val t = LocalCarTokens.current
    val prefs by vm.preferences.collectAsStateWithLifecycle()
    val tel by vm.telemetryState.collectAsStateWithLifecycle()
    val mph = prefs.speedUnit == SpeedUnit.MPH
    val dist = tel.tripDistanceM / 1000.0 * (if (mph) 0.621371 else 1.0)
    val avg = if (tel.tripMovingSec > 20) (tel.tripDistanceM / tel.tripMovingSec * 3.6 * (if (mph) 0.621371 else 1.0)) else 0.0
    val max = tel.tripMaxKmh * (if (mph) 0.621371f else 1f)
    val du = if (mph) "mi" else "km"
    val su = if (mph) "mph" else "km/h"
    val stats = buildList {
        if (w.on("distance")) add("Distance" to "%.1f %s".format(dist, du))
        if (w.on("time")) add("Driving" to Fmt.duration(tel.tripMovingSec))
        if (w.on("avg")) add("Average" to "%.0f %s".format(avg, su))
        if (w.on("max")) add("Top speed" to "%.0f %s".format(max, su))
    }
    BoxWithConstraints(Modifier.fillMaxSize().padding(14.dp)) {
        val small = maxHeight < 120.dp
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                WidgetTitle(Icons.Rounded.Timeline, "Trip", t.green, Modifier.weight(1f))
                Text("Reset", style = MaterialTheme.typography.labelMedium, color = t.accent,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).pressable { vm.resetTrip() }.padding(6.dp))
            }
            val cols = if (maxWidth > 260.dp) 4 else 2
            stats.chunked(cols).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { (k, v) ->
                        Column(Modifier.weight(1f)) {
                            Text(v, style = if (small) MaterialTheme.typography.titleSmall else MaterialTheme.typography.titleMedium.copy(fontFeatureSettings = "tnum"), color = t.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(k, style = MaterialTheme.typography.labelSmall, color = t.secondaryLabel, maxLines = 1)
                        }
                    }
                    repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
fun CompassWidget(w: WidgetInstance, vm: LauncherViewModel) {
    val t = LocalCarTokens.current
    val tel by vm.telemetryState.collectAsStateWithLifecycle()
    val bearing by animateFloatAsState(tel.bearingDegrees, tween(500), label = "bearing")
    Column(Modifier.fillMaxSize().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
        Box(Modifier.weight(1f).aspectRatio(1f), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val r = size.minDimension / 2f
                rotate(-bearing, center) {
                    drawCircle(t.fill, r, style = Stroke(2.dp.toPx()))
                    for (i in 0 until 36) {
                        val a = Math.toRadians(i * 10.0 - 90.0)
                        val len = if (i % 9 == 0) 0.2f else if (i % 3 == 0) 0.12f else 0.07f
                        drawLine(if (i == 0) t.red else t.tertiaryLabel, Offset(center.x + cos(a).toFloat() * r, center.y + sin(a).toFloat() * r),
                            Offset(center.x + cos(a).toFloat() * r * (1 - len), center.y + sin(a).toFloat() * r * (1 - len)), 1.6.dp.toPx())
                    }
                    val n = Path().apply { moveTo(center.x, center.y - r * 0.62f); lineTo(center.x + r * 0.1f, center.y); lineTo(center.x - r * 0.1f, center.y); close() }
                    drawPath(n, t.red)
                }
                drawLine(t.label, Offset(center.x, 0f), Offset(center.x, 7.dp.toPx()), 3.dp.toPx(), StrokeCap.Round)
            }
            Text(cardinal(bearing), style = MaterialTheme.typography.titleLarge, color = t.label)
        }
        Text("${bearing.roundToInt()}°" + if (w.on("altitude")) "  ·  ${tel.altitudeM.roundToInt()} m" else "", style = MaterialTheme.typography.labelMedium, color = t.secondaryLabel, maxLines = 1)
    }
}

@Composable
fun ParkingWidget(w: WidgetInstance, vm: LauncherViewModel) {
    val t = LocalCarTokens.current
    val prefs by vm.preferences.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    BoxWithConstraints(Modifier.fillMaxSize().padding(12.dp)) {
        val small = maxHeight < 110.dp
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            WidgetTitle(Icons.Rounded.LocalParking, "Parked car", t.accent)
            if (!prefs.hasParking) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.clip(RoundedCornerShape(14.dp)).background(t.accent).pressable { vm.saveParking() }.padding(horizontal = 16.dp, vertical = 10.dp)
                    ) { Text(if (small) "Save" else "Save spot", style = MaterialTheme.typography.labelLarge, color = Color.White, maxLines = 1) }
                }
            } else {
                Column {
                    if (w.on("time") && !small) {
                        val mins = ((now - prefs.parkTimeMs) / 60_000L).coerceAtLeast(0)
                        Text(if (mins < 60) "$mins min ago" else "${mins / 60} h ${mins % 60} min ago", style = MaterialTheme.typography.titleSmall, color = t.label, maxLines = 1)
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(t.accent).pressable { vm.navigateToParking() }.padding(vertical = 9.dp), contentAlignment = Alignment.Center) {
                            Text("Navigate", style = MaterialTheme.typography.labelMedium, color = Color.White, maxLines = 1)
                        }
                        Box(Modifier.clip(RoundedCornerShape(12.dp)).background(t.fill).pressable { vm.clearParking() }.padding(horizontal = 10.dp, vertical = 9.dp), contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.Close, "Clear", tint = t.label, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SystemWidget(w: WidgetInstance, vm: LauncherViewModel) {
    val t = LocalCarTokens.current
    val h by vm.health.collectAsStateWithLifecycle()
    val usedFrac = if (h.ramTotalMb > 0) 1f - h.ramFreeMb.toFloat() / h.ramTotalMb else 0f
    val ramColor = if (usedFrac > 0.88f) t.red else if (usedFrac > 0.75f) t.orange else t.green
    val tempColor = if (h.cpuTempC > 80f) t.red else if (h.cpuTempC > 70f) t.orange else t.green
    BoxWithConstraints(Modifier.fillMaxSize().padding(12.dp)) {
        val small = maxHeight < 120.dp
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            WidgetTitle(Icons.Rounded.Memory, "Unit health", t.accent)
            if (w.on("ram")) {
                Column {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("RAM", style = MaterialTheme.typography.labelSmall, color = t.secondaryLabel)
                        Text("${h.ramFreeMb} MB free", style = MaterialTheme.typography.labelSmall, color = t.label, maxLines = 1)
                    }
                    Spacer(Modifier.height(3.dp))
                    Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(t.fill)) {
                        Box(Modifier.fillMaxWidth(usedFrac.coerceIn(0.02f, 1f)).fillMaxHeight().background(ramColor))
                    }
                }
            }
            if (w.on("temp") && h.cpuTempC > 0f && !small) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("CPU", style = MaterialTheme.typography.labelSmall, color = t.secondaryLabel)
                    Text("%.0f °C".format(h.cpuTempC), style = MaterialTheme.typography.labelMedium, color = tempColor)
                }
            }
            if (w.on("storage") && !small) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Storage", style = MaterialTheme.typography.labelSmall, color = t.secondaryLabel)
                    Text("%.0f GB free".format(h.storageFreeGb), style = MaterialTheme.typography.labelMedium, color = t.label)
                }
            }
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(11.dp)).background(t.accent.copy(alpha = 0.18f)).pressable { vm.boostMemory() }.padding(vertical = 7.dp),
                contentAlignment = Alignment.Center
            ) { Text(if (h.lastBoostMb >= 0) "Boost  (+${h.lastBoostMb} MB)" else "Boost memory", style = MaterialTheme.typography.labelMedium, color = t.accent, maxLines = 1) }
        }
    }
}
