package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.example.model.*
import com.example.ui.common.GlassCard
import com.example.ui.common.PillButton
import com.example.ui.common.pressable
import com.example.ui.theme.LocalCarTokens
import com.example.ui.widgets.WidgetContent
import com.example.viewmodel.LauncherViewModel
import kotlin.math.roundToInt

@Composable
fun DashboardScreen(vm: LauncherViewModel, prefs: LauncherPreferences, modifier: Modifier = Modifier) {
    val t = LocalCarTokens.current
    val pages = prefs.pages
    val pagerState = rememberPagerState(initialPage = vm.dashboardPage.coerceIn(0, (pages.size - 1).coerceAtLeast(0))) { pages.size.coerceAtLeast(1) }

    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { vm.dashboardPage = it }
    }
    LaunchedEffect(vm.dashboardPage, pages.size) {
        val target = vm.dashboardPage.coerceIn(0, (pages.size - 1).coerceAtLeast(0))
        if (pagerState.currentPage != target) {
            if (t.reduceMotion) pagerState.scrollToPage(target) else pagerState.animateScrollToPage(target)
        }
    }

    Column(modifier.fillMaxSize()) {
        HorizontalPager(
            state = pagerState,
            userScrollEnabled = !vm.editMode,
            modifier = Modifier.weight(1f).fillMaxWidth()
        ) { index ->
            val page = pages.getOrNull(index)
            if (page != null) {
                WidgetPageGrid(vm, page, prefs, vm.editMode)
            }
        }
        BottomBar(vm, prefs, pagerState.currentPage, pages.size)
    }
}

@Composable
private fun WidgetPageGrid(vm: LauncherViewModel, page: WidgetPage, prefs: LauncherPreferences, edit: Boolean) {
    val t = LocalCarTokens.current
    val gap = prefs.cardGapDp.dp
    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .padding(start = gap, end = gap, top = gap, bottom = 0.dp)
            .pointerInput(edit) { if (!edit) detectTapGestures(onLongPress = { vm.enterEditMode() }) }
    ) {
        val cols = prefs.gridCols
        val rows = prefs.gridRows
        val cellW = (maxWidth - gap * (cols - 1)) / cols
        val cellH = (maxHeight - gap * (rows - 1)) / rows
        val density = LocalDensity.current
        val stepX = with(density) { (cellW + gap).toPx() }
        val stepY = with(density) { (cellH + gap).toPx() }

        if (edit) {
            // faint grid cells to show where widgets can go
            for (r in 0 until rows) for (c in 0 until cols) {
                Box(
                    Modifier.offset((cellW + gap) * c, (cellH + gap) * r).size(cellW, cellH)
                        .clip(RoundedCornerShape(t.cornerDp.dp))
                        .background(t.fill.copy(alpha = 0.14f))
                )
            }
        }
        page.widgets.forEach { w ->
            key(w.id) {
                WidgetHost(
                    vm = vm, w = w, edit = edit, stepX = stepX, stepY = stepY,
                    modifier = Modifier
                        .offset((cellW + gap) * w.col, (cellH + gap) * w.row)
                        .size(cellW * w.w + gap * (w.w - 1), cellH * w.h + gap * (w.h - 1))
                )
            }
        }
    }
}

@Composable
private fun WidgetHost(vm: LauncherViewModel, w: WidgetInstance, edit: Boolean, stepX: Float, stepY: Float, modifier: Modifier) {
    val t = LocalCarTokens.current
    var drag by remember { mutableStateOf(Offset.Zero) }
    var dragging by remember { mutableStateOf(false) }
    val cardStyle = when (w.str("card")) {
        "glass" -> CardStyle.GLASS
        "solid" -> CardStyle.SOLID
        "outline" -> CardStyle.OUTLINE
        else -> null
    }
    val bare = w.str("card") == "none"

    Box(
        modifier
            .zIndex(if (dragging) 10f else 0f)
            .graphicsLayer {
                translationX = drag.x; translationY = drag.y
                val s = if (dragging) 1.04f else 1f
                scaleX = s; scaleY = s
                alpha = if (dragging) 0.92f else 1f
            }
    ) {
        if (bare) {
            Box(Modifier.fillMaxSize()) { WidgetContent(w, vm) }
        } else {
            GlassCard(Modifier.fillMaxSize(), style = cardStyle, tint = w.tint) { WidgetContent(w, vm) }
        }
        if (edit) {
            Box(
                Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(t.cornerDp.dp))
                    .background(Color.Black.copy(alpha = 0.10f))
                    .border(2.dp, t.accent, RoundedCornerShape(t.cornerDp.dp))
                    .pointerInput(w.id) { detectTapGestures { vm.openWidgetOptions(w.id) } }
                    .pointerInput(w.id, w.col, w.row, w.w, w.h, stepX, stepY) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = { dragging = true },
                            onDrag = { change, amount -> change.consume(); drag += amount },
                            onDragEnd = {
                                val dc = (drag.x / stepX).roundToInt()
                                val dr = (drag.y / stepY).roundToInt()
                                drag = Offset.Zero; dragging = false
                                if (dc != 0 || dr != 0) vm.moveWidget(w.id, w.col + dc, w.row + dr)
                            },
                            onDragCancel = { drag = Offset.Zero; dragging = false }
                        )
                    }
            ) {
                Box(
                    Modifier.align(Alignment.TopStart).padding(8.dp).size(30.dp).clip(CircleShape).background(t.red).pressable { vm.removeWidget(w.id) },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Remove, "Remove", tint = Color.White, modifier = Modifier.size(18.dp)) }
                Box(
                    Modifier.align(Alignment.TopEnd).padding(8.dp).size(30.dp).clip(CircleShape).background(t.accent).pressable { vm.openWidgetOptions(w.id) },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Tune, "Options", tint = Color.White, modifier = Modifier.size(17.dp)) }
                Text(
                    "${w.type.title}  ·  ${w.w}×${w.h}", style = MaterialTheme.typography.labelSmall, color = Color.White,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.5f)).padding(horizontal = 10.dp, vertical = 3.dp)
                )
            }
        }
    }
}

@Composable
private fun BottomBar(vm: LauncherViewModel, prefs: LauncherPreferences, current: Int, count: Int) {
    val t = LocalCarTokens.current
    Box(Modifier.fillMaxWidth().height(50.dp).padding(horizontal = 12.dp), contentAlignment = Alignment.Center) {
        if (vm.editMode) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
                PillButton("+ Widget", filled = false) { vm.openAddWidget(true) }
                PillButton("+ Page", filled = false) { vm.addPage() }
                PillButton("Delete page", filled = false, color = t.red) { vm.removePage(current) }
                Icon(Icons.Rounded.ChevronLeft, "Previous page", tint = t.label, modifier = Modifier.size(34.dp).clip(CircleShape).pressable { if (current > 0) vm.dashboardPage = current - 1 })
                Text("${current + 1} / $count", style = MaterialTheme.typography.labelLarge, color = t.label)
                Icon(Icons.Rounded.ChevronRight, "Next page", tint = t.label, modifier = Modifier.size(34.dp).clip(CircleShape).pressable { if (current < count - 1) vm.dashboardPage = current + 1 })
                PillButton("Done") { vm.exitEditMode() }
            }
        } else {
            if (prefs.showPageDots && count > 1) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    repeat(count) { i ->
                        val sel = i == current
                        val size by animateDpAsState(if (sel) 9.dp else 7.dp, label = "dot")
                        val c by animateColorAsState(if (sel) t.label else t.label.copy(alpha = 0.3f), label = "dotc")
                        Box(Modifier.size(size).clip(CircleShape).background(c).pressable { vm.dashboardPage = i })
                    }
                }
            }
            Box(
                Modifier.align(Alignment.CenterEnd).clip(CircleShape).background(t.fill).pressable { vm.enterEditMode() }.padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Rounded.Edit, null, tint = t.secondaryLabel, modifier = Modifier.size(14.dp))
                    Text("Edit", style = MaterialTheme.typography.labelMedium, color = t.secondaryLabel)
                }
            }
        }
    }
}
