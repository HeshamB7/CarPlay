package com.example.engine

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Resources
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.PathParser
import com.example.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class IconStyle(
    val shape: IconShape = IconShape.IOS,
    val backdrop: IconBackdrop = IconBackdrop.AUTO,
    val useGlyphs: Boolean = true,
    val zoom: Float = 1f,
    val border: Boolean = true,
    val iconPack: String? = null
) {
    val key: String get() = "${shape.ordinal}${backdrop.ordinal}${if (useGlyphs) 1 else 0}${"%.2f".format(Locale.US, zoom)}${if (border) 1 else 0}${iconPack ?: "-"}"
}

/**
 * Apple-style icon engine: every icon is drawn on a real iOS continuous-corner squircle with no
 * gloss or fake effects. System apps get hand-built Apple-style glyph icons; other apps keep their own artwork.
 */
class IconProcessor(private val context: Context) {

    private val pm: PackageManager = context.packageManager
    private val iconCache = object : LruCache<String, ImageBitmap>(14 * 1024 * 1024) {
        override fun sizeOf(key: String, value: ImageBitmap): Int = value.width * value.height * 4
    }
    private val iconPackMapCache = mutableMapOf<String, Map<String, String>>()
    private val pathCache = HashMap<String, Path>()

    fun clearCache() = iconCache.evictAll()

    fun observePackageChanges(): Flow<Unit> = callbackFlow {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                clearCache(); trySend(Unit)
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        context.registerReceiver(receiver, filter)
        awaitClose { runCatching { context.unregisterReceiver(receiver) } }
    }

    private fun canResolve(intent: Intent): Boolean =
        runCatching { pm.queryIntentActivities(intent, 0).isNotEmpty() }.getOrDefault(false)

    /** Loads every launchable app (unsorted by user prefs; the ViewModel orders and filters). */
    suspend fun loadInstalledApps(): List<AppEntry> = withContext(Dispatchers.IO) {
        val main = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val infos = pm.queryIntentActivities(main, 0)
        val own = context.packageName
        val installed = infos.asSequence()
            .filter { it.activityInfo?.packageName != null && it.activityInfo.packageName != own }
            .distinctBy { it.activityInfo.packageName }
            .map {
                val pkg = it.activityInfo.packageName
                AppEntry(pkg, it.activityInfo.name, it.loadLabel(pm)?.toString()?.trim().orEmpty().ifBlank { pkg })
            }
            .sortedBy { it.label.lowercase(Locale.US) }
            .toList()

        val virtuals = buildList {
            fun v(id: String, label: String) = add(AppEntry(id, label, label, virtualAction = id))
            if (canResolve(Intent(Intent.ACTION_DIAL))) v(AppLauncherHelper.VIRTUAL_PHONE, "Phone")
            if (canResolve(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MUSIC))) v(AppLauncherHelper.VIRTUAL_MUSIC, "Music")
            v(AppLauncherHelper.VIRTUAL_MAPS, "Maps")
            if (canResolve(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING))) v(AppLauncherHelper.VIRTUAL_MESSAGES, "Messages")
            v(AppLauncherHelper.VIRTUAL_NOW_PLAYING, "Now Playing")
            if (canResolve(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR))) v(AppLauncherHelper.VIRTUAL_CALENDAR, "Calendar")
            v(AppLauncherHelper.VIRTUAL_SETTINGS, "Settings")
        }
        virtuals + installed
    }

    suspend fun discoverIconPacks(): List<IconPackInfo> = withContext(Dispatchers.IO) {
        val actions = listOf("com.novalauncher.THEME", "org.adw.launcher.THEMES", "com.gau.go.launcherex.theme", "com.anddoes.launcher.THEME")
        val packs = linkedMapOf<String, IconPackInfo>()
        for (action in actions) {
            @Suppress("DEPRECATION")
            val resolved = runCatching { pm.queryIntentActivities(Intent(action), 0) }.getOrDefault(emptyList())
            for (ri in resolved) {
                val pkg = ri.activityInfo?.packageName ?: continue
                if (!packs.containsKey(pkg)) packs[pkg] = IconPackInfo(pkg, ri.loadLabel(pm)?.toString().orEmpty().ifBlank { pkg })
            }
        }
        packs.values.sortedBy { it.label.lowercase(Locale.US) }
    }

    suspend fun getProcessedIcon(app: AppEntry, style: IconStyle, sizePx: Int = 160): ImageBitmap =
        withContext(Dispatchers.IO) {
            val dayKey = if (glyphKey(app, true) == "calendar") SimpleDateFormat("yyyyMMdd", Locale.US).format(Date()) else ""
            val cacheKey = "${app.packageName}|${style.key}|$sizePx|$dayKey"
            iconCache.get(cacheKey)?.let { return@withContext it }

            val packDrawable = if (app.virtualAction == null && style.iconPack != null) loadFromIconPack(style.iconPack, app) else null
            val glyph = if (packDrawable == null) glyphKey(app, style.useGlyphs) else null
            val content: Bitmap = if (glyph != null) {
                renderGlyph(glyph, sizePx)
            } else {
                val d = packDrawable ?: runCatching { pm.getApplicationIcon(app.packageName) }.getOrNull() ?: pm.defaultActivityIcon
                renderArtwork(d, sizePx, style)
            }
            val out = maskToShape(content, sizePx, style)
            val img = out.asImageBitmap()
            iconCache.put(cacheKey, img)
            img
        }

    // ---------------------------------------------------------------- glyph icons

    private val brandPrefixes = listOf(
        "com.google.android.apps.maps", "com.waze", "com.netflix", "com.spotify", "com.google.android.youtube",
        "com.amazon", "com.whatsapp", "com.instagram", "com.facebook", "com.zhiliaoapp", "com.snapchat", "com.shahid", "net.mbc"
    )

    private fun glyphKey(app: AppEntry, enabled: Boolean): String? {
        when (app.virtualAction) {
            AppLauncherHelper.VIRTUAL_PHONE -> return "phone"
            AppLauncherHelper.VIRTUAL_MUSIC -> return "music"
            AppLauncherHelper.VIRTUAL_MAPS -> return "maps"
            AppLauncherHelper.VIRTUAL_MESSAGES -> return "messages"
            AppLauncherHelper.VIRTUAL_NOW_PLAYING -> return "nowplaying"
            AppLauncherHelper.VIRTUAL_CALENDAR -> return "calendar"
            AppLauncherHelper.VIRTUAL_SETTINGS -> return "settings"
        }
        if (!enabled) return null
        val pkg = app.packageName.lowercase(Locale.US)
        val lbl = app.label.lowercase(Locale.US)
        if (brandPrefixes.any { pkg.startsWith(it) }) return null
        return when {
            pkg == "com.android.settings" || lbl == "settings" -> "settings"
            pkg.contains("backcar") || pkg.contains("avm") || pkg.contains("usb2cvbs") || lbl.contains("rear") || lbl.contains("reverse") || lbl.contains("360") -> "backcam"
            pkg.contains("camera") || lbl == "camera" -> "camera"
            pkg.contains("calculator") || lbl == "calculator" -> "calculator"
            pkg.contains("deskclock") || lbl == "clock" -> "clock"
            pkg.contains("calendar") -> "calendar"
            pkg.contains("documentsui") || pkg.contains("filemanager") || pkg.contains("explorer") || lbl == "files" || lbl == "file manager" -> "files"
            pkg.contains("gallery") || lbl == "gallery" -> "photos"
            pkg.contains("weather") -> "weather"
            pkg.contains("contacts") || lbl == "contacts" -> "contacts"
            pkg.contains("bt.music") || pkg.contains("btmusic") || lbl.contains("bt music") || lbl.contains("bluetooth music") -> "btmusic"
            lbl == "bluetooth" || pkg.contains("bluetooth") -> "bluetooth"
            pkg.contains("radio") || lbl.contains("radio") || lbl == "fm" -> "radio"
            pkg.contains("dialer") || pkg.contains("telecom") || lbl == "phone" || lbl.contains("bt phone") -> "phone"
            pkg.contains("messaging") || pkg.contains(".mms") || lbl == "messages" -> "messages"
            pkg.contains("mycar") || pkg.contains("can.help") || pkg.contains("can.setting") || pkg.contains("carinfo") || lbl.contains("vehicle") || lbl.contains("car info") -> "vehicle"
            pkg.contains("videoplayer") || pkg.contains("movieplayer") || lbl == "video" || lbl == "videos" -> "video"
            pkg.contains("android.music") || lbl == "music" || lbl == "music player" -> "music"
            pkg.contains("android.browser") || lbl == "browser" -> "browser"
            lbl.contains("navi") && !lbl.contains("maps") -> "navigation"
            else -> null
        }
    }

    private fun parsed(d: String): Path = pathCache.getOrPut(d) { PathParser.createPathFromPathData(d) ?: Path() }

    private fun renderGlyph(name: String, sizePx: Int): Bitmap {
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val spec = AppleGlyphs.all[name] ?: AppleGlyphs.all.getValue("settings")
        val s = sizePx / 100f
        c.save(); c.scale(s, s)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, 0f, 0f, 100f, spec.top, spec.bottom, Shader.TileMode.CLAMP)
        }
        c.drawRect(0f, 0f, 100f, 100f, bg)
        for (l in spec.layers) drawLayer(c, l)
        if (name == "calendar") drawCalendarText(c)
        c.restore()
        return bmp
    }

    private fun drawLayer(c: Canvas, l: GL) {
        val st = l.s
        c.save()
        if (st.rd != 0f) c.rotate(st.rd, st.rx, st.ry)
        if (st.ts != 1f || st.tx != 0f || st.ty != 0f) { c.translate(st.tx, st.ty); c.scale(st.ts, st.ts) }
        fun apply(p: Paint, fill: Boolean) {
            p.isAntiAlias = true
            if (fill) { p.style = Paint.Style.FILL; p.color = st.fill } else {
                p.style = Paint.Style.STROKE; p.color = st.stroke; p.strokeWidth = st.sw
                p.strokeCap = if (st.round) Paint.Cap.ROUND else Paint.Cap.BUTT; p.strokeJoin = Paint.Join.ROUND
            }
            p.alpha = (p.alpha * st.op).toInt()
        }
        val paint = Paint()
        when (l) {
            is GCircle -> {
                if (st.fill != 0) { apply(paint, true); c.drawCircle(l.cx, l.cy, l.r, paint) }
                if (st.stroke != 0) { apply(paint, false); c.drawCircle(l.cx, l.cy, l.r, paint) }
            }
            is GRect -> {
                val rf = RectF(l.x, l.y, l.x + l.w, l.y + l.h)
                if (st.fill != 0) { apply(paint, true); c.drawRoundRect(rf, l.rr, l.rr, paint) }
                if (st.stroke != 0) { apply(paint, false); c.drawRoundRect(rf, l.rr, l.rr, paint) }
            }
            is GPath -> {
                val p = parsed(l.d)
                if (st.fill != 0) { apply(paint, true); c.drawPath(p, paint) }
                if (st.stroke != 0) { apply(paint, false); c.drawPath(p, paint) }
            }
        }
        c.restore()
    }

    private fun drawCalendarText(c: Canvas) {
        val now = Date()
        val day = SimpleDateFormat("EEE", Locale.US).format(now).uppercase(Locale.US)
        val num = SimpleDateFormat("d", Locale.US).format(now)
        val hp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        c.drawText(day, 50f, 21f, hp)
        val np = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(28, 28, 30); textAlign = Paint.Align.CENTER; textSize = 56f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        c.drawText(num, 50f, 82f, np)
    }

    // ---------------------------------------------------------------- real app artwork

    private fun renderArtwork(drawable: Drawable, sizePx: Int, style: IconStyle): Bitmap {
        val out = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && drawable is AdaptiveIconDrawable) {
            val scale = 1.40f * style.zoom
            val big = sizePx * scale
            val off = -(big - sizePx) / 2f
            val bounds = Rect(off.toInt(), off.toInt(), (off + big).toInt(), (off + big).toInt())
            val bg = drawable.background
            if (bg != null) { bg.bounds = bounds; bg.draw(canvas) } else drawBackdrop(canvas, sizePx, Color.WHITE, false, style.backdrop)
            drawable.foreground?.let { it.bounds = bounds; it.draw(canvas) }
            return out
        }
        val probe = drawableToBitmap(drawable, 96)
        val stats = analyze(probe)
        if (stats.transparentRatio > 0.14f) {
            drawBackdrop(canvas, sizePx, stats.avgColor, stats.lightGlyph, style.backdrop)
            val inset = (sizePx * 0.15f / style.zoom).toInt().coerceIn(0, sizePx / 3)
            val glyph = drawableToBitmap(drawable, sizePx)
            canvas.drawBitmap(glyph, null, Rect(inset, inset, sizePx - inset, sizePx - inset), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        } else {
            canvas.drawBitmap(drawableToBitmap(drawable, sizePx), 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        }
        return out
    }

    private class Stats(val transparentRatio: Float, val avgColor: Int, val lightGlyph: Boolean)

    private fun analyze(b: Bitmap): Stats {
        var transparent = 0; var total = 0
        var r = 0L; var g = 0L; var bl = 0L; var n = 0L
        val step = (b.width / 24).coerceAtLeast(1)
        for (y in 0 until b.height step step) for (x in 0 until b.width step step) {
            total++
            val p = b.getPixel(x, y)
            if (Color.alpha(p) < 40) transparent++ else if (Color.alpha(p) > 150) {
                r += Color.red(p); g += Color.green(p); bl += Color.blue(p); n++
            }
        }
        if (n == 0L) return Stats(1f, Color.WHITE, false)
        val ar = (r / n).toInt(); val ag = (g / n).toInt(); val ab = (bl / n).toInt()
        val lum = (0.299 * ar + 0.587 * ag + 0.114 * ab) / 255.0
        return Stats(transparent.toFloat() / total, Color.rgb(ar, ag, ab), lum > 0.80)
    }

    private fun drawBackdrop(c: Canvas, s: Int, avg: Int, lightGlyph: Boolean, mode: IconBackdrop) {
        val dark = when (mode) { IconBackdrop.DARK -> true; IconBackdrop.WHITE -> false; IconBackdrop.AUTO -> lightGlyph }
        val top = if (dark) Color.rgb(78, 78, 82) else Color.WHITE
        val bottom = if (dark) Color.rgb(28, 28, 30) else Color.rgb(233, 236, 244)
        val p = Paint().apply { shader = LinearGradient(0f, 0f, 0f, s.toFloat(), top, bottom, Shader.TileMode.CLAMP) }
        c.drawRect(0f, 0f, s.toFloat(), s.toFloat(), p)
    }

    private fun drawableToBitmap(d: Drawable, s: Int): Bitmap {
        if (d is BitmapDrawable && d.bitmap != null) {
            val b = d.bitmap
            return if (b.width == s && b.height == s) b else Bitmap.createScaledBitmap(b, s, s, true)
        }
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        d.setBounds(0, 0, s, s); d.draw(cv)
        return bmp
    }

    private fun maskToShape(content: Bitmap, s: Int, style: IconStyle): Bitmap {
        val out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val sf = s.toFloat()
        val shape: Path = when (style.shape) {
            IconShape.IOS -> Squircle.path(sf)
            IconShape.CIRCLE -> Path().apply { addOval(RectF(0f, 0f, sf, sf), Path.Direction.CW) }
            IconShape.ROUNDED -> Path().apply { addRoundRect(RectF(0f, 0f, sf, sf), sf * 0.24f, sf * 0.24f, Path.Direction.CW) }
            IconShape.SQUARE -> Path().apply { addRoundRect(RectF(0f, 0f, sf, sf), sf * 0.05f, sf * 0.05f, Path.Direction.CW) }
        }
        val mask = Paint(Paint.ANTI_ALIAS_FLAG)
        canvas.drawPath(shape, mask)
        mask.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(content, 0f, 0f, mask)
        if (style.border) {
            val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.style = Paint.Style.STROKE; strokeWidth = (sf * 0.012f).coerceAtLeast(1f); color = Color.argb(34, 0, 0, 0)
            }
            canvas.save(); canvas.clipPath(shape)
            canvas.drawPath(shape, edge)
            canvas.restore()
        }
        content.recycle()
        return out
    }

    // ---------------------------------------------------------------- icon packs

    private fun loadFromIconPack(pack: String, app: AppEntry): Drawable? = runCatching {
        val res = pm.getResourcesForApplication(pack)
        val map = iconPackMapCache.getOrPut(pack) { parseAppFilter(res, pack) }
        val comp = "ComponentInfo{${app.packageName}/${app.activityName}}"
        val name = map[comp] ?: map[app.packageName] ?: return@runCatching null
        val id = res.getIdentifier(name, "drawable", pack)
        if (id != 0) ResourcesCompat.getDrawable(res, id, null) else null
    }.getOrNull()

    private fun parseAppFilter(res: Resources, pack: String): Map<String, String> {
        val mapping = mutableMapOf<String, String>()
        val xmlId = res.getIdentifier("appfilter", "xml", pack)
        if (xmlId != 0) {
            runCatching { readFilter(res.getXml(xmlId), mapping) }
        } else {
            runCatching {
                res.assets.open("appfilter.xml").use { st ->
                    val p = XmlPullParserFactory.newInstance().newPullParser()
                    p.setInput(st, "UTF-8"); readFilter(p, mapping)
                }
            }
        }
        return mapping
    }

    private fun readFilter(parser: XmlPullParser, mapping: MutableMap<String, String>) {
        var ev = parser.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG && parser.name == "item") {
                val comp = parser.getAttributeValue(null, "component")
                val dr = parser.getAttributeValue(null, "drawable")
                if (!comp.isNullOrBlank() && !dr.isNullOrBlank()) {
                    mapping[comp] = dr
                    val pkg = comp.removePrefix("ComponentInfo{").removeSuffix("}").substringBefore('/')
                    if (pkg.isNotBlank() && !mapping.containsKey(pkg)) mapping[pkg] = dr
                }
            }
            ev = parser.next()
        }
    }
}
