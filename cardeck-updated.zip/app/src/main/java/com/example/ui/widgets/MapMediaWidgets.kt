package com.example.ui.widgets

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.engine.AppLauncherHelper
import com.example.model.NavigationProvider
import com.example.model.WidgetInstance
import com.example.service.CarMediaNotificationListenerService
import com.example.ui.common.Fmt
import com.example.ui.common.pressable
import com.example.ui.theme.LocalCarTokens
import com.example.viewmodel.LauncherViewModel

@Composable
fun MapWidget(w: WidgetInstance, vm: LauncherViewModel) {
    val t = LocalCarTokens.current
    val ctx = LocalContext.current
    val prefs by vm.preferences.collectAsStateWithLifecycle()
    val tel by vm.telemetryState.collectAsStateWithLifecycle()
    val provider = when (w.str("provider")) {
        "gmaps" -> NavigationProvider.GOOGLE_MAPS
        "waze" -> NavigationProvider.WAZE
        else -> prefs.navProvider
    }
    var query by remember { mutableStateOf("") }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val compact = maxHeight < 130.dp || maxWidth < 170.dp
        if (w.on("artwork")) {
            Canvas(Modifier.fillMaxSize().pressable(pressedScale = 0.98f) { AppLauncherHelper.openMapApp(ctx, provider) }) {
                val night = t.isNight
                val ww = size.width; val hh = size.height
                drawRect(Brush.verticalGradient(listOf(if (night) Color(0xFF1A1D24) else Color(0xFFF6F4ED), if (night) Color(0xFF212630) else Color(0xFFEEECE2))))
                drawRect(if (night) Color(0xFF152840) else Color(0xFFA7D7F9), Offset(ww * 0.8f, 0f), androidx.compose.ui.geometry.Size(ww * 0.2f, hh))
                drawRect(if (night) Color(0xFF182C22) else Color(0xFFD2EAD0), Offset(ww * 0.05f, hh * 0.15f), androidx.compose.ui.geometry.Size(ww * 0.24f, hh * 0.25f))
                val road = if (night) Color(0xFF2D3340) else Color.White
                for (i in 1..4) drawLine(road, Offset(0f, hh * i / 5f), Offset(ww, hh * i / 5f), 3.5.dp.toPx())
                for (j in 1..4) drawLine(road, Offset(ww * j / 5f, 0f), Offset(ww * j / 5f, hh), 3.5.dp.toPx())
                val hw = Path().apply { moveTo(ww * 0.08f, hh); cubicTo(ww * 0.34f, hh * 0.64f, ww * 0.45f, hh * 0.46f, ww * 0.78f, 0f) }
                drawPath(hw, if (night) Color(0xFF3E4758) else Color(0xFFF9D876), style = Stroke(12.dp.toPx(), cap = StrokeCap.Round))
                val route = Path().apply { moveTo(ww * 0.5f, hh * 0.8f); lineTo(ww * 0.5f, hh * 0.5f); quadraticBezierTo(ww * 0.5f, hh * 0.34f, ww * 0.66f, hh * 0.28f); lineTo(ww * 0.8f, hh * 0.18f) }
                drawPath(route, Color(0xFF0051B3), style = Stroke(9.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawPath(route, t.accent, style = Stroke(5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                val c = Offset(ww * 0.5f, hh * 0.58f)
                drawCircle(t.accent.copy(alpha = 0.22f), 26.dp.toPx(), c)
                drawCircle(Color.White, 14.dp.toPx(), c)
                drawCircle(t.accent, 11.dp.toPx(), c)
                rotate(tel.bearingDegrees, c) {
                    val a = Path().apply { moveTo(c.x, c.y - 7.dp.toPx()); lineTo(c.x + 5.dp.toPx(), c.y + 5.dp.toPx()); lineTo(c.x, c.y + 2.dp.toPx()); lineTo(c.x - 5.dp.toPx(), c.y + 5.dp.toPx()); close() }
                    drawPath(a, Color.White)
                }
            }
        }
        if (compact) {
            Row(
                Modifier.align(Alignment.BottomStart).padding(10.dp)
                    .clip(CircleShape).background(t.cardBase.copy(alpha = 0.9f)).padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Rounded.NearMe, null, tint = t.accent, modifier = Modifier.size(18.dp))
                Text(provider.label, style = MaterialTheme.typography.labelLarge, color = t.label, maxLines = 1)
            }
        } else {
            Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
                if (w.on("search")) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Row(
                            Modifier.weight(1f).height(46.dp).clip(RoundedCornerShape(14.dp)).background(t.cardBase.copy(alpha = 0.92f)).padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.Search, null, tint = t.secondaryLabel, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Box(Modifier.weight(1f)) {
                                if (query.isEmpty()) Text("Search Maps", style = MaterialTheme.typography.bodyMedium, color = t.secondaryLabel, maxLines = 1)
                                BasicTextField(
                                    value = query, onValueChange = { query = it }, singleLine = true,
                                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = t.label),
                                    cursorBrush = SolidColor(t.accent),
                                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                    keyboardActions = KeyboardActions(onSearch = { if (query.isNotBlank()) AppLauncherHelper.launchNavigation(ctx, query.trim(), provider) }),
                                    modifier = Modifier.fillMaxWidth().testTag("nav_search_input")
                                )
                            }
                            if (query.isNotBlank()) {
                                Text(
                                    "Go", style = MaterialTheme.typography.labelLarge, color = Color.White,
                                    modifier = Modifier.clip(RoundedCornerShape(9.dp)).background(t.accent)
                                        .pressable { AppLauncherHelper.launchNavigation(ctx, query.trim(), provider) }
                                        .padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }
                        }
                        Row(
                            Modifier.height(46.dp).clip(RoundedCornerShape(14.dp)).background(t.cardBase.copy(alpha = 0.92f))
                                .pressable { AppLauncherHelper.openMapApp(ctx, provider) }.padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(Icons.Rounded.NearMe, null, tint = t.accent, modifier = Modifier.size(16.dp))
                            Text(provider.label, style = MaterialTheme.typography.labelLarge, color = t.label, maxLines = 1)
                        }
                    }
                } else Spacer(Modifier)
                if (w.on("shortcuts")) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NavChip(Icons.Rounded.Home, "Home", t.accent, Modifier.weight(1f)) { AppLauncherHelper.launchNavigation(ctx, prefs.homeAddress.ifBlank { "Home" }, provider) }
                        NavChip(Icons.Rounded.Work, "Work", t.orange, Modifier.weight(1f)) { AppLauncherHelper.launchNavigation(ctx, prefs.workAddress.ifBlank { "Work" }, provider) }
                        NavChip(Icons.Rounded.LocalGasStation, "Gas", t.green, Modifier.weight(1f)) { AppLauncherHelper.launchNavigation(ctx, "gas station", provider) }
                    }
                }
            }
        }
    }
}

@Composable
private fun NavChip(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, tint: Color, modifier: Modifier, onClick: () -> Unit) {
    val t = LocalCarTokens.current
    Row(
        modifier.height(46.dp).clip(RoundedCornerShape(14.dp)).background(t.cardBase.copy(alpha = 0.92f)).pressable(onClick = onClick).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
    ) {
        Icon(icon, label, tint = tint, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(5.dp))
        Text(label, style = MaterialTheme.typography.labelLarge, color = t.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun NowPlayingWidget(w: WidgetInstance, vm: LauncherViewModel) {
    val t = LocalCarTokens.current
    val ctx = LocalContext.current
    val m by vm.mediaState.collectAsStateWithLifecycle()
    val art = remember(m.albumArt) { m.albumArt?.asImageBitmap() }

    BoxWithConstraints(Modifier.fillMaxSize().pressable(enabled = m.hasActiveSession, pressedScale = 0.985f) { CarMediaNotificationListenerService.openActiveMediaApp(ctx) }) {
        val wide = maxWidth >= 300.dp
        val tall = maxHeight >= 190.dp
        if (art != null && w.on("art")) {
            Image(art, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().alpha(if (t.isNight) 0.28f else 0.18f))
        }
        if (!m.hasNotificationPermission) {
            Row(Modifier.fillMaxSize().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("Not Playing", style = MaterialTheme.typography.titleMedium, color = t.label)
                    Text("Allow notification access to show what's playing", style = MaterialTheme.typography.bodySmall, color = t.secondaryLabel, maxLines = 2)
                }
                Text(
                    "Allow", style = MaterialTheme.typography.labelLarge, color = Color.White,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(t.accent).pressable { AppLauncherHelper.openNotificationListenerSettings(ctx) }.padding(horizontal = 14.dp, vertical = 9.dp)
                )
            }
        } else {
            Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    val artSize = if (tall) 72.dp else 52.dp
                    Box(
                        Modifier.size(artSize).clip(RoundedCornerShape(12.dp)).background(Brush.verticalGradient(listOf(Color(0xFFFF6A86), Color(0xFFF92140)))),
                        contentAlignment = Alignment.Center
                    ) {
                        if (art != null) Image(art, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        else Icon(Icons.Rounded.MusicNote, null, tint = Color.White, modifier = Modifier.size(artSize * 0.5f))
                    }
                    Column(Modifier.weight(1f)) {
                        Text(m.title.ifBlank { "Not Playing" }, style = MaterialTheme.typography.titleMedium, color = t.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(m.artist.ifBlank { "Play music or video in any app" }, style = MaterialTheme.typography.bodyMedium, color = t.secondaryLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (w.on("source") && m.sourceAppName.isNotBlank()) {
                            Text(m.sourceAppName, style = MaterialTheme.typography.labelSmall, color = t.red, maxLines = 1)
                        }
                    }
                    if (!wide) {
                        RoundIconButton(if (m.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play/Pause", 52, onClick = { CarMediaNotificationListenerService.togglePlayPause() })
                    }
                }
                if (w.on("progress") && tall) {
                    val p = if (m.durationMs > 0) (m.positionMs.toFloat() / m.durationMs).coerceIn(0f, 1f) else 0f
                    Column {
                        Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(t.secondaryLabel.copy(alpha = 0.25f))) {
                            Box(Modifier.fillMaxWidth(p).fillMaxHeight().background(t.label))
                        }
                        if (m.durationMs > 0) Row(Modifier.fillMaxWidth().padding(top = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(Fmt.duration(m.positionMs / 1000), style = MaterialTheme.typography.labelSmall, color = t.secondaryLabel)
                            Text(Fmt.duration(m.durationMs / 1000), style = MaterialTheme.typography.labelSmall, color = t.secondaryLabel)
                        }
                    }
                }
                if (wide || tall) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        RoundIconButton(Icons.Rounded.FastRewind, "Previous", 52, onClick = { CarMediaNotificationListenerService.skipPrevious() })
                        RoundIconButton(if (m.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play/Pause", 58, bg = t.fill, onClick = { CarMediaNotificationListenerService.togglePlayPause() })
                        RoundIconButton(Icons.Rounded.FastForward, "Next", 52, onClick = { CarMediaNotificationListenerService.skipNext() })
                    }
                }
            }
        }
    }
}
