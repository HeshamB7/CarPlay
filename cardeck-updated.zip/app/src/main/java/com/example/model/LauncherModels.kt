package com.example.model

import android.graphics.Bitmap
import androidx.compose.runtime.Immutable

enum class LauncherScreen { DASHBOARD, APP_GRID, SETTINGS }
enum class DockSide { LEFT, RIGHT }
enum class DockStyle { FLOATING, FLUSH, TRANSPARENT }
enum class DayNightMode { AUTO_SUN, AUTO_SYSTEM, SCHEDULE, FORCE_DAY, FORCE_NIGHT }
enum class WallpaperPreset { IOS_18_DYNAMIC, IOS_17_DYNAMIC, GRADIENT, SOLID, BLACK, CUSTOM_IMAGE }
enum class CardStyle { GLASS, SOLID, OUTLINE }
enum class IconShape { IOS, CIRCLE, ROUNDED, SQUARE }
enum class IconBackdrop { AUTO, WHITE, DARK }
enum class SpeedUnit { KMH, MPH }

enum class NavigationProvider(val label: String, val packageName: String) {
    GOOGLE_MAPS("Google Maps", "com.google.android.apps.maps"),
    WAZE("Waze", "com.waze")
}

enum class PrayerMethod(val label: String, val fajrAngle: Double, val ishaAngle: Double, val ishaMinutes: Int) {
    UMM_AL_QURA("Umm al-Qura (Makkah)", 18.5, 0.0, 90),
    MWL("Muslim World League", 18.0, 17.0, 0),
    EGYPT("Egyptian Authority", 19.5, 17.5, 0),
    GULF("Gulf Region", 19.5, 0.0, 90),
    ISNA("ISNA (North America)", 15.0, 15.0, 0),
    KARACHI("Karachi", 18.0, 18.0, 0)
}

/** Preset cities for manual location (name, lat, lon). */
object Cities {
    val list: List<Triple<String, Double, Double>> = listOf(
        Triple("Jeddah", 21.4858, 39.1925),
        Triple("Makkah", 21.3891, 39.8579),
        Triple("Madinah", 24.4686, 39.6142),
        Triple("Taif", 21.2703, 40.4158),
        Triple("Riyadh", 24.7136, 46.6753),
        Triple("Dammam", 26.4207, 50.0888),
        Triple("Abha", 18.2164, 42.5053),
        Triple("Tabuk", 28.3835, 36.5662),
        Triple("Dubai", 25.2048, 55.2708),
        Triple("Kuwait City", 29.3759, 47.9774),
        Triple("Doha", 25.2854, 51.5310),
        Triple("Cairo", 30.0444, 31.2357)
    )
}

sealed class WidgetOption(val key: String, val label: String) {
    class Toggle(key: String, label: String, val default: Boolean) : WidgetOption(key, label)
    class Choice(key: String, label: String, val choices: List<Pair<String, String>>, val default: String) :
        WidgetOption(key, label)
}

private fun tg(key: String, label: String, d: Boolean) = WidgetOption.Toggle(key, label, d)
private fun ch(key: String, label: String, d: String, vararg c: Pair<String, String>) =
    WidgetOption.Choice(key, label, c.toList(), d)

enum class WidgetType(
    val title: String,
    val desc: String,
    val defW: Int,
    val defH: Int,
    val minW: Int,
    val minH: Int,
    val options: List<WidgetOption>
) {
    MAP(
        "Maps", "Search and one-tap destinations", 2, 2, 1, 1, listOf(
            ch("provider", "Navigation app", "global", "global" to "Default", "gmaps" to "Google Maps", "waze" to "Waze"),
            tg("search", "Search bar", true),
            tg("shortcuts", "Home / Work / Gas chips", true),
            tg("artwork", "Map artwork", true)
        )
    ),
    NOW_PLAYING(
        "Now Playing", "Controls for any music or video app", 2, 1, 1, 1, listOf(
            tg("art", "Blurred artwork background", true),
            tg("progress", "Progress bar", true),
            tg("source", "App name", true)
        )
    ),
    SPEED(
        "Speedometer", "Live GPS speed with limit alert", 1, 1, 1, 1, listOf(
            ch("style", "Style", "digital", "digital" to "Digital", "ring" to "Ring gauge"),
            ch("unit", "Unit", "global", "global" to "Default", "kmh" to "km/h", "mph" to "mph"),
            tg("limit", "Show speed limit", true),
            tg("heading", "Show heading", false)
        )
    ),
    CLOCK(
        "Clock", "Analog or digital clock", 1, 1, 1, 1, listOf(
            ch("style", "Style", "digital", "digital" to "Digital", "analog" to "Analog", "both" to "Analog + digital"),
            tg("seconds", "Show seconds", false),
            tg("date", "Show date", true),
            ch("format", "Time format", "global", "global" to "Default", "12" to "12-hour", "24" to "24-hour")
        )
    ),
    DATE(
        "Calendar", "Today and your next event", 1, 1, 1, 1, listOf(
            tg("hijri", "Show Hijri date", true),
            tg("event", "Next event", true)
        )
    ),
    TRIP(
        "Trip Computer", "Distance, time, average and top speed", 2, 1, 1, 1, listOf(
            tg("distance", "Distance", true),
            tg("time", "Driving time", true),
            tg("avg", "Average speed", true),
            tg("max", "Top speed", true)
        )
    ),
    QUICK_CONTROLS(
        "Quick Controls", "Bluetooth, Wi-Fi, hotspot and more", 2, 1, 1, 1, listOf(
            tg("bluetooth", "Bluetooth", true),
            tg("wifi", "Wi-Fi", true),
            tg("hotspot", "Hotspot", true),
            tg("split", "Split view", true),
            tg("dimmer", "Screen dimmer", true),
            tg("boost", "Memory boost", true)
        )
    ),
    SHORTCUTS(
        "App Shortcuts", "Your favourite apps in a widget", 2, 1, 1, 1, listOf(
            tg("labels", "Show names", true)
        )
    ),
    PRAYER(
        "Prayer Times", "Next prayer with countdown (works offline)", 2, 1, 1, 1, listOf(
            ch("lang", "Names", "ar", "ar" to "Arabic", "en" to "English"),
            tg("all", "Show all five times", true),
            tg("sunrise", "Include sunrise", false)
        )
    ),
    WEATHER(
        "Weather", "Current temperature and wind", 1, 1, 1, 1, listOf(
            tg("wind", "Show wind", true),
            tg("feels", "Show high / low", true)
        )
    ),
    SYSTEM(
        "Unit Health", "Free memory, temperature and storage", 1, 1, 1, 1, listOf(
            tg("ram", "Memory", true),
            tg("temp", "CPU temperature", true),
            tg("storage", "Storage", true)
        )
    ),
    PARKING(
        "Parked Car", "Save where you parked and navigate back", 1, 1, 1, 1, listOf(
            tg("time", "Show time since parked", true)
        )
    ),
    COMPASS(
        "Compass", "Heading and altitude", 1, 1, 1, 1, listOf(
            tg("altitude", "Show altitude", true)
        )
    );

    fun option(key: String): WidgetOption? = options.firstOrNull { it.key == key }
}

@Immutable
data class WidgetInstance(
    val id: String,
    val type: WidgetType,
    val col: Int,
    val row: Int,
    val w: Int,
    val h: Int,
    val options: Map<String, String> = emptyMap()
) {
    fun str(key: String): String {
        options[key]?.let { return it }
        return when (val o = type.option(key)) {
            is WidgetOption.Toggle -> if (o.default) "1" else "0"
            is WidgetOption.Choice -> o.default
            null -> when (key) {
                "card" -> "default"
                "tint" -> "0"
                else -> ""
            }
        }
    }

    fun on(key: String): Boolean = str(key) == "1"
    fun long(key: String): Long = str(key).toLongOrNull() ?: 0L
    val tint: Int get() = str("tint").toLongOrNull()?.toInt() ?: 0
    val list: List<String> get() = options["apps"]?.split("|")?.filter { it.isNotBlank() } ?: emptyList()
}

@Immutable
data class WidgetPage(val id: String, val widgets: List<WidgetInstance>)

@Immutable
data class AppEntry(
    val packageName: String,
    val activityName: String,
    val label: String,
    val customLabel: String? = null,
    val isHidden: Boolean = false,
    val sortOrder: Int = 0,
    val virtualAction: String? = null
) {
    val displayName: String
        get() = customLabel?.takeIf { it.isNotBlank() } ?: label
}

@Immutable
data class IconPackInfo(val packageName: String, val label: String)

@Immutable
data class LauncherPreferences(
    // appearance
    val dayNightMode: DayNightMode = DayNightMode.AUTO_SUN,
    val nightStartMin: Int = 18 * 60,
    val nightEndMin: Int = 6 * 60,
    val accent: Int = 0xFF0A84FF.toInt(),
    val wallpaperPreset: WallpaperPreset = WallpaperPreset.IOS_18_DYNAMIC,
    val customWallpaperUri: String? = null,
    val wallpaperGradient: Int = 0,
    val wallpaperSolid: Int = 0xFF1C1C1E.toInt(),
    val wallpaperDim: Float = 0.0f,
    val cardStyle: CardStyle = CardStyle.GLASS,
    val cardAlpha: Float = 0.78f,
    val cornerRadiusDp: Float = 22f,
    val cardGapDp: Float = 12f,
    val reduceMotion: Boolean = false,
    val autoFit: Boolean = true,
    val uiScale: Float = 1.0f,
    val fontScale: Float = 1.0f,
    val boldText: Boolean = false,
    val use24h: Boolean = false,
    val arabicDigits: Boolean = false,
    // dock
    val dockSide: DockSide = DockSide.LEFT,
    val dockStyle: DockStyle = DockStyle.FLOATING,
    val dockWidthLevel: Int = 1,
    val dockIconSizeDp: Float = 52f,
    val dockApps: List<String> = listOf("carplay://maps", "carplay://music", "carplay://nowplaying"),
    val dockRecents: Int = 0,
    val dockShowLabels: Boolean = false,
    val dockShowClock: Boolean = true,
    val dockShowStatus: Boolean = true,
    val dockShowVoice: Boolean = true,
    val dockShowDimmer: Boolean = true,
    val dockShowSettings: Boolean = true,
    // apps & icons
    val iconSizeDp: Float = 68f,
    val iconShape: IconShape = IconShape.IOS,
    val iconBackdrop: IconBackdrop = IconBackdrop.AUTO,
    val useAppleGlyphs: Boolean = true,
    val iconZoom: Float = 1.0f,
    val iconShadow: Boolean = false,
    val iconBorder: Boolean = true,
    val showLabels: Boolean = true,
    val labelSizeSp: Float = 13f,
    val appGridCols: Int = 0,
    val appGridRows: Int = 2,
    val activeIconPackPackage: String? = null,
    val recentPackages: List<String> = emptyList(),
    val hiddenPackages: Set<String> = emptySet(),
    val customLabels: Map<String, String> = emptyMap(),
    val appOrder: List<String> = emptyList(),
    // dashboard
    val gridCols: Int = 4,
    val gridRows: Int = 2,
    val showPageDots: Boolean = true,
    val pages: List<WidgetPage> = emptyList(),
    // driving & location
    val navProvider: NavigationProvider = NavigationProvider.GOOGLE_MAPS,
    val homeAddress: String = "Home",
    val workAddress: String = "Work",
    val speedLimitKmh: Int = 120,
    val speedGuardEnabled: Boolean = true,
    val speedChime: Boolean = true,
    val speedUnit: SpeedUnit = SpeedUnit.KMH,
    val manualLocation: Boolean = false,
    val manualCityIdx: Int = 0,
    val lastLat: Double = 21.4858,
    val lastLon: Double = 39.1925,
    val prayerMethod: PrayerMethod = PrayerMethod.UMM_AL_QURA,
    val asrHanafi: Boolean = false,
    val prayerOffsetMin: Int = 0,
    val weatherFahrenheit: Boolean = false,
    val timeGuard: Boolean = true,
    val hasParking: Boolean = false,
    val parkLat: Double = 0.0,
    val parkLon: Double = 0.0,
    val parkTimeMs: Long = 0L,
    // security / misc
    val valetModeEnabled: Boolean = false,
    val valetPin: String = "1234",
    val onboardingCompleted: Boolean = false
)

@Immutable
data class MediaPlaybackState(
    val hasNotificationPermission: Boolean = false,
    val hasActiveSession: Boolean = false,
    val isPlaying: Boolean = false,
    val title: String = "",
    val artist: String = "",
    val album: String = "",
    val sourcePackage: String? = null,
    val sourceAppName: String = "",
    val albumArt: Bitmap? = null,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L
)

@Immutable
data class SystemStatusState(
    val isWifiConnected: Boolean = false,
    val isCellularConnected: Boolean = false,
    val isBluetoothEnabled: Boolean = false,
    val isGpsActive: Boolean = false,
    val clockWrong: Boolean = false
)

@Immutable
data class TelemetryState(
    val speedKmh: Float = 0f,
    val bearingDegrees: Float = 0f,
    val altitudeM: Double = 0.0,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val hasLocationPermission: Boolean = false,
    val hasGpsFix: Boolean = false,
    val hasCalendarPermission: Boolean = false,
    val nextEventTitle: String? = null,
    val nextEventTimeMs: Long = 0L,
    val tripDistanceM: Double = 0.0,
    val tripMovingSec: Long = 0L,
    val tripMaxKmh: Float = 0f,
    val tripStartMs: Long = System.currentTimeMillis()
)

@Immutable
data class WeatherState(
    val ok: Boolean = false,
    val tempC: Float = 0f,
    val highC: Float = 0f,
    val lowC: Float = 0f,
    val windKmh: Float = 0f,
    val code: Int = 0,
    val isDay: Boolean = true,
    val updatedMs: Long = 0L
)

@Immutable
data class HealthState(
    val ramTotalMb: Int = 0,
    val ramFreeMb: Int = 0,
    val cpuTempC: Float = -1f,
    val storageTotalGb: Float = 0f,
    val storageFreeGb: Float = 0f,
    val lastBoostMb: Int = -1
)
