package com.example.engine

import com.example.model.WeatherState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Current weather from Open-Meteo (free, no API key). Returns null when offline. */
object WeatherRepository {
    suspend fun fetch(lat: Double, lon: Double): WeatherState? = withContext(Dispatchers.IO) {
        runCatching {
            val url = URL(
                "https://api.open-meteo.com/v1/forecast?latitude=" + String.format(java.util.Locale.US, "%.4f", lat) +
                    "&longitude=" + String.format(java.util.Locale.US, "%.4f", lon) +
                    "&current=temperature_2m,weather_code,wind_speed_10m,is_day" +
                    "&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1"
            )
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 6000
            conn.readTimeout = 8000
            try {
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                val j = JSONObject(text)
                val cur = j.getJSONObject("current")
                val daily = j.optJSONObject("daily")
                WeatherState(
                    ok = true,
                    tempC = cur.getDouble("temperature_2m").toFloat(),
                    windKmh = cur.optDouble("wind_speed_10m", 0.0).toFloat(),
                    code = cur.optInt("weather_code", 0),
                    isDay = cur.optInt("is_day", 1) == 1,
                    highC = daily?.optJSONArray("temperature_2m_max")?.optDouble(0, 0.0)?.toFloat() ?: 0f,
                    lowC = daily?.optJSONArray("temperature_2m_min")?.optDouble(0, 0.0)?.toFloat() ?: 0f,
                    updatedMs = System.currentTimeMillis()
                )
            } finally {
                conn.disconnect()
            }
        }.getOrNull()
    }
}
