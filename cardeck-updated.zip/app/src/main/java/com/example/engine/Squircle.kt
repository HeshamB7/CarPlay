package com.example.engine

import android.graphics.Path
import kotlin.math.*

/** Apple's continuous-corner "squircle" (same construction as iOS app icons, corner smoothing 0.6). */
object Squircle {
    fun path(size: Float, radiusRatio: Float = 0.2237f, smoothing: Float = 0.6f): Path {
        val r = size * radiusRatio
        val p = min((1f + smoothing) * r, size / 2f)
        val arcMeasure = 90f * (1f - smoothing)
        val arcLen = (sin(Math.toRadians(arcMeasure / 2.0)) * r * sqrt(2.0)).toFloat()
        val alpha = (90f - arcMeasure) / 2f
        val p3p4 = (r * tan(Math.toRadians(alpha / 2.0))).toFloat()
        val beta = 45f * smoothing
        val c = (p3p4 * cos(Math.toRadians(beta.toDouble()))).toFloat()
        val d = (c * tan(Math.toRadians(beta.toDouble()))).toFloat()
        val b = (p - arcLen - c - d) / 3f
        val a = 2f * b
        val th = Math.toRadians(arcMeasure.toDouble())
        val be = Math.toRadians(beta.toDouble())
        val k = (4.0 / 3.0 * tan(th / 4.0) * r).toFloat()
        val t0x = cos(be).toFloat(); val t0y = sin(be).toFloat()
        val t1x = cos(be + th).toFloat(); val t1y = sin(be + th).toFloat()
        // canonical top-right corner segments relative to the corner start point
        val e1x = a + b + c; val e1y = d
        val e2x = e1x + arcLen; val e2y = e1y + arcLen
        val segs = arrayOf(
            floatArrayOf(a, 0f, a + b, 0f, e1x, e1y),
            floatArrayOf(e1x + k * t0x, e1y + k * t0y, e2x - k * t1x, e2y - k * t1y, e2x, e2y),
            floatArrayOf(e2x + d, e2y + c, e2x + d, e2y + b + c, e2x + d, e2y + a + b + c)
        )
        val starts = arrayOf(
            floatArrayOf(size - p, 0f), floatArrayOf(size, size - p),
            floatArrayOf(p, size), floatArrayOf(0f, p)
        )
        val path = Path()
        path.moveTo(starts[0][0], starts[0][1])
        for (k4 in 0 until 4) {
            val sx = starts[k4][0]; val sy = starts[k4][1]
            if (k4 > 0) path.lineTo(sx, sy)
            for (s in segs) {
                val pts = FloatArray(6)
                for (i in 0 until 3) {
                    var x = s[i * 2]; var y = s[i * 2 + 1]
                    for (n in 0 until k4) { val nx = -y; val ny = x; x = nx; y = ny }
                    pts[i * 2] = sx + x; pts[i * 2 + 1] = sy + y
                }
                path.cubicTo(pts[0], pts[1], pts[2], pts[3], pts[4], pts[5])
            }
        }
        path.close()
        return path
    }
}
