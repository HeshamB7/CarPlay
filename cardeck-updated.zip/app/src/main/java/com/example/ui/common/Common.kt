package com.example.ui.common

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.CardStyle
import com.example.ui.theme.LocalCarTokens

/** Press feedback (spring scale) + tap / long-press, used by every tappable thing in the launcher. */
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.pressable(
    enabled: Boolean = true,
    pressedScale: Float = 0.93f,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit
): Modifier = composed {
    val reduce = LocalCarTokens.current.reduceMotion
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && enabled) pressedScale else 1f,
        animationSpec = if (reduce) snap() else spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .combinedClickable(
            interactionSource = src, indication = null, enabled = enabled,
            onLongClick = onLongClick, onClick = onClick
        )
}

/** A dashboard / settings surface: glass, solid or outline, optionally tinted by a widget colour. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    style: CardStyle? = null,
    tint: Int = 0,
    cornerDp: Float? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val t = LocalCarTokens.current
    val st = style ?: t.cardStyle
    val shape = RoundedCornerShape((cornerDp ?: t.cornerDp).dp)
    var m = modifier.clip(shape).background(t.cardFill(st))
    if (tint != 0) m = m.background(Color(tint).copy(alpha = if (st == CardStyle.OUTLINE) 0.16f else 0.34f))
    if (st == CardStyle.GLASS) {
        m = m.background(Brush.verticalGradient(listOf(Color.White.copy(alpha = if (t.isNight) 0.05f else 0.35f), Color.Transparent)))
    }
    m = m.border(if (st == CardStyle.OUTLINE) 1.25.dp else 0.75.dp, if (st == CardStyle.OUTLINE) t.secondaryLabel.copy(alpha = 0.55f) else t.cardBorder, shape)
    Box(modifier = m, content = content)
}

@Composable
fun IosSwitch(checked: Boolean, onChange: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    val t = LocalCarTokens.current
    val track by animateColorAsState(if (checked) t.green else t.fill, tween(180), label = "sw_track")
    val x by animateDpAsState(if (checked) 20.dp else 0.dp, spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMedium), label = "sw_thumb")
    Box(
        modifier = modifier
            .size(width = 51.dp, height = 31.dp)
            .clip(CircleShape)
            .background(track)
            .pointerInput(checked) { detectTapGestures { onChange(!checked) } }
            .padding(2.dp)
    ) {
        Box(
            Modifier
                .offset(x = x)
                .size(27.dp)
                .shadow(2.dp, CircleShape)
                .background(Color.White, CircleShape)
        )
    }
}

@Composable
fun IosSlider(value: Float, onChange: (Float) -> Unit, range: ClosedFloatingPointRange<Float>, modifier: Modifier = Modifier, steps: Int = 0) {
    val t = LocalCarTokens.current
    Slider(
        value = value.coerceIn(range.start, range.endInclusive),
        onValueChange = onChange,
        valueRange = range,
        steps = steps,
        modifier = modifier,
        colors = SliderDefaults.colors(
            thumbColor = Color.White, activeTrackColor = t.accent, inactiveTrackColor = t.fill,
            activeTickColor = Color.Transparent, inactiveTickColor = Color.Transparent
        )
    )
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val t = LocalCarTokens.current
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(t.fill)
            .padding(2.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        options.forEachIndexed { i, label ->
            val sel = i == selected
            val bg by animateColorAsState(if (sel) (if (t.isNight) Color(0xFF636366) else Color.White) else Color.Transparent, tween(160), label = "seg")
            Box(
                Modifier
                    .weight(1f)
                    .heightIn(min = 36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(bg)
                    .pointerInput(i) { detectTapGestures { onSelect(i) } }
                    .padding(horizontal = 10.dp, vertical = 7.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(label, style = MaterialTheme.typography.labelMedium, color = t.label, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
            }
        }
    }
}

/** Plain pill button. */
@Composable
fun PillButton(label: String, modifier: Modifier = Modifier, filled: Boolean = true, color: Color? = null, onClick: () -> Unit) {
    val t = LocalCarTokens.current
    val c = color ?: t.accent
    Box(
        modifier = modifier
            .heightIn(min = 40.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (filled) c else c.copy(alpha = 0.16f))
            .pressable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, style = MaterialTheme.typography.labelLarge, color = if (filled) Color.White else c, maxLines = 1)
    }
}

/** Modal sheet drawn inside the root (so it scales with the UI and never opens a system dialog). */
@Composable
fun Modal(onDismiss: () -> Unit, maxWidth: Int = 560, content: @Composable ColumnScope.() -> Unit) {
    val t = LocalCarTokens.current
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.5f))
            .pointerInput(Unit) { detectTapGestures { onDismiss() } },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .padding(20.dp)
                .widthIn(max = maxWidth.dp)
                .fillMaxWidth()
                .heightIn(max = 480.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(if (t.isNight) Color(0xFF1C1C1E) else Color(0xFFF2F2F7))
                .border(0.75.dp, t.cardBorder, RoundedCornerShape(24.dp))
                .pointerInput(Unit) { detectTapGestures { } }
                .padding(18.dp),
            content = content
        )
    }
}

@Composable
fun ChipRow(items: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val t = LocalCarTokens.current
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEachIndexed { i, s ->
            val sel = i == selected
            Box(
                Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (sel) t.accent else t.fill)
                    .pressable(onClick = { onSelect(i) })
                    .padding(horizontal = 14.dp, vertical = 9.dp)
            ) {
                Text(s, style = MaterialTheme.typography.labelMedium, color = if (sel) Color.White else t.label, maxLines = 1)
            }
        }
    }
}
