import sys, os; HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import icons
def col(h):
    h=h.lstrip('#'); return '0xFF'+h.upper()+'.toInt()'
def f(x):
    s=('%.4f'%x).rstrip('0').rstrip('.')
    return s+'f'
def style(s):
    parts=[]
    if s.get('fill'): parts.append('fill=%s'%col(s['fill']))
    if s.get('stroke'): parts.append('stroke=%s'%col(s['stroke']))
    if s.get('sw'): parts.append('sw=%s'%f(s['sw']))
    if s.get('op',1)!=1: parts.append('op=%s'%f(s['op']))
    if s.get('cap')=='round': parts.append('round=true')
    if 'rot' in s: d,cx,cy=s['rot']; parts.append('rd=%s,rx=%s,ry=%s'%(f(d),f(cx),f(cy)))
    if 't' in s: sc,tx,ty=s['t']; parts.append('ts=%s,tx=%s,ty=%s'%(f(sc),f(tx),f(ty)))
    return 'GS('+', '.join(parts)+')'
out=['package com.example.engine','','// GENERATED from tools/icons.py - Apple-style glyph icon specs (100x100 grid).','',
'internal class GS(val fill: Int = 0, val stroke: Int = 0, val sw: Float = 0f, val op: Float = 1f, val round: Boolean = false,',
'                  val rd: Float = 0f, val rx: Float = 50f, val ry: Float = 50f, val ts: Float = 1f, val tx: Float = 0f, val ty: Float = 0f)',
'internal sealed class GL(val s: GS)',
'internal class GCircle(val cx: Float, val cy: Float, val r: Float, s: GS) : GL(s)',
'internal class GRect(val x: Float, val y: Float, val w: Float, val h: Float, val rr: Float, s: GS) : GL(s)',
'internal class GPath(val d: String, s: GS) : GL(s)',
'internal class GlyphSpec(val top: Int, val bottom: Int, val layers: List<GL>)','',
'internal object AppleGlyphs {','    val all: Map<String, GlyphSpec> by lazy { build() }','','    private fun build(): Map<String, GlyphSpec> = mapOf(']
items=[]
for name,spec in icons.ICONS.items():
    t,b=spec['bg']
    ls=[]
    for kind,args,s in spec['layers']:
        if kind=='circle': ls.append('GCircle(%s, %s, %s, %s)'%(f(args[0]),f(args[1]),f(args[2]),style(s)))
        elif kind=='rrect': ls.append('GRect(%s, %s, %s, %s, %s, %s)'%(f(args[0]),f(args[1]),f(args[2]),f(args[3]),f(args[4]),style(s)))
        else: ls.append('GPath("%s", %s)'%(args[0],style(s)))
    items.append('        "%s" to GlyphSpec(%s, %s, listOf(\n            %s\n        ))'%(name,col(t),col(b),',\n            '.join(ls)))
out.append(',\n'.join(items))
out.append('    )')
out.append('}')
open(os.path.join(HERE,'AppleGlyphs.kt'),'w').write('\n'.join(out)+'\n')
print(len('\n'.join(out)))
