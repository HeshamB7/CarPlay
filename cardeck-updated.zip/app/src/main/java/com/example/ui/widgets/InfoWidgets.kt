package com.example.ui.widgets

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.engine.AppLauncherHelper
import com.example.engine.SolarCalc
import com.example.model.WidgetInstance
import com.example.ui.common.Fmt
import com.example.ui.common.pressable
import com.example.ui.theme.LocalCarTokens
import com.example.viewmodel.LauncherViewModel
import com.example.viewmodel.PickerTarget
import kotlin.math.roundToInt

@Composable
fun DateWidget(w: WidgetInstance, vm: LauncherViewModel) {
    val t = LocalCarTokens.current
    val prefs by vm.preferences.collectAsStateWithLifecycle()
    val tel by vm.telemetryState.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val ar = prefs.arabicDigits
    BoxWithConstraints(Modifier.fillMaxSize().padding(14.dp)) {
        val small = maxHeight < 110.dp
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            Text(Fmt.date(now, "EEEE", ar, ar).uppercase(), style = MaterialTheme.typography.labelMedium, color = t.red, maxLines = 1)
            Column {
                Text(Fmt.date(now, "d", ar, ar), style = if (small) MaterialTheme.typography.headlineLarge else MaterialTheme.typography.displayMedium, color = t.label, maxLines = 1)
                Text(Fmt.date(now, "MMMM yyyy", ar, ar), style = MaterialTheme.typography.labelMedium, color = t.secondaryLabel, maxLines = 1)
                if (w.on("hijri") && !small) {
                    val h = SolarCalc.hijri(now)
                    if (h != null) Text("${Fmt.num(h.third, ar)} ${SolarCalc.hijriMonthsAr[h.second.coerceIn(0, 11)]} ${Fmt.num(h.first, ar)}", style = MaterialTheme.typography.labelMedium, color = t.green, maxLines = 1)
                }
            }
            if (w.on("event") && !small) {
                if (!tel.hasCalendarPermission) {
                    Text("Show events", style = MaterialTheme.typography.labelMedium, color = t.accent, modifier = Modifier.pressable { vm.onRequestCalendar() })
                } else Text(
                    tel.nextEventTitle?.let { "$it · " + Fmt.time(tel.nextEventTimeMs, prefs.use24h, false, ar) } ?: "No upcoming events",
                    style = MaterialTheme.typography.labelMedium, color = t.secondaryLabel, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

private val prayerAr = listOf("الفجر", "الشروق", "الظهر", "العصر", "المغرب", "العشاء")
private val prayerEn = listOf("Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha")

@Composable
fun PrayerWidget(w: WidgetInstance, vm: LauncherViewModel) {
    val t = LocalCarTokens.current
    val prefs by vm.preferences.collectAsStateWithLifecycle()
    val tel by vm.telemetryState.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val ar = w.str("lang") == "ar"
    val names = if (ar) prayerAr else prayerEn
    val (lat, lon) = remember(prefs.manualLocation, prefs.manualCityIdx, prefs.lastLat, prefs.lastLon, tel.hasGpsFix, (tel.latitude * 20).toInt(), (tel.longitude * 20).toInt()) { vm.effectiveLatLon(prefs) }
    val day = SolarCalc.localEpochDay(now)
    val ramadan = remember(day) { SolarCalc.isRamadan(now) }
    val today = remember(day, lat, lon, prefs.prayerMethod, prefs.asrHanafi, prefs.prayerOffsetMin, ramadan) {
        SolarCalc.prayers(day, lat, lon, prefs.prayerMethod, prefs.asrHanafi, ramadan, prefs.prayerOffsetMin)
    }
    val tomorrow = remember(day, lat, lon, prefs.prayerMethod, prefs.asrHanafi, prefs.prayerOffsetMin, ramadan) {
        SolarCalc.prayers(day + 1, lat, lon, prefs.prayerMethod, prefs.asrHanafi, ramadan, prefs.prayerOffsetMin)
    }
    if (today == null || tomorrow == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Prayer times unavailable here", style = MaterialTheme.typography.labelMedium, color = t.secondaryLabel) }
        return
    }
    val list = today.asList()
    val order = if (w.on("sunrise")) listOf(0, 1, 2, 3, 4, 5) else listOf(0, 2, 3, 4, 5)
    var nextIdx = order.firstOrNull { list[it] > now } ?: -1
    val nextTime = if (nextIdx >= 0) list[nextIdx] else tomorrow.fajr
    if (nextIdx < 0) nextIdx = 0

    BoxWithConstraints(Modifier.fillMaxSize().padding(14.dp)) {
        val small = maxHeight < 120.dp || maxWidth < 200.dp
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            WidgetTitle(Icons.Rounded.NightsStay, if (ar) "الصلاة القادمة" else "Next prayer", t.green, trailing = Fmt.countdown(nextTime - now))
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(names[nextIdx], style = if (small) MaterialTheme.typography.titleLarge else MaterialTheme.typography.headlineLarge, color = t.label, maxLines = 1)
                Text(Fmt.time(nextTime, prefs.use24h, false, prefs.arabicDigits) + if (!prefs.use24h) " " + Fmt.ampm(nextTime, ar) else "", style = MaterialTheme.typography.titleSmall, color = t.secondaryLabel, modifier = Modifier.padding(bottom = 3.dp), maxLines = 1)
            }
            if (w.on("all") && !small) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    order.forEach { i ->
                        val isNext = i == nextIdx
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(names[i], style = MaterialTheme.typography.labelSmall, color = if (isNext) t.green else t.secondaryLabel, maxLines = 1)
                            Text(Fmt.time(list[i], prefs.use24h, false, prefs.arabicDigits), style = MaterialTheme.typography.labelMedium, color = if (isNext) t.label else t.secondaryLabel, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WeatherWidget(w: WidgetInstance, vm: LauncherViewModel) {
    val t = LocalCarTokens.current
    val prefs by vm.preferences.collectAsStateWithLifecycle()
    val wx by vm.weather.collectAsStateWithLifecycle()
    fun conv(c: Float) = if (prefs.weatherFahrenheit) c * 9f / 5f + 32f else c
    val unit = if (prefs.weatherFahrenheit) "°F" else "°C"
    val icon = when {
        wx.code == 0 -> if (wx.isDay) Icons.Rounded.WbSunny else Icons.Rounded.NightsStay
        wx.code in 1..3 || wx.code in 45..48 -> Icons.Rounded.Cloud
        wx.code in 51..67 || wx.code in 80..82 -> Icons.Rounded.Grain
        wx.code in 71..77 || wx.code in 85..86 -> Icons.Rounded.AcUnit
        wx.code >= 95 -> Icons.Rounded.FlashOn
        else -> Icons.Rounded.Cloud
    }
    val iconTint = if (wx.code == 0 && wx.isDay) t.yellow else if (wx.code >= 95) t.orange else t.accent
    BoxWithConstraints(Modifier.fillMaxSize().padding(14.dp).pressable(pressedScale = 0.97f) { vm.refreshWeatherNow() }) {
        val small = maxHeight < 110.dp
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            WidgetTitle(icon, "Weather", iconTint)
            if (!wx.ok) {
                Text("Needs internet", style = MaterialTheme.typography.labelMedium, color = t.secondaryLabel)
            } else {
                Text("${conv(wx.tempC).roundToInt()}$unit", style = if (small) MaterialTheme.typography.headlineLarge else MaterialTheme.typography.displayMedium, color = t.label, maxLines = 1)
                if (!small) Column {
                    if (w.on("feels")) Text("H ${conv(wx.highC).roundToInt()}°  L ${conv(wx.lowC).roundToInt()}°", style = MaterialTheme.typography.labelMedium, color = t.secondaryLabel, maxLines = 1)
                    if (w.on("wind")) Text("Wind ${wx.windKmh.roundToInt()} km/h", style = MaterialTheme.typography.labelSmall, color = t.secondaryLabel, maxLines = 1)
                }
            }
        }
    }
}

@Composable
fun QuickControlsWidget(w: WidgetInstance, vm: LauncherViewModel) {
    val t = LocalCarTokens.current
    val ctx = LocalContext.current
    val st by vm.systemStatus.collectAsStateWithLifecycle()
    class Tile(val icon: androidx.compose.ui.graphics.vector.ImageVector, val label: String, val active: Boolean, val color: Color, val onClick: () -> Unit)
    val tiles = buildList {
        if (w.on("bluetooth")) add(Tile(Icons.Rounded.Bluetooth, "Bluetooth", st.isBluetoothEnabled, t.accent) { AppLauncherHelper.openBluetoothSettings(ctx) })
        if (w.on("wifi")) add(Tile(Icons.Rounded.Wifi, "Wi-Fi", st.isWifiConnected, t.accent) { AppLauncherHelper.openWifiPanel(ctx) })
        if (w.on("hotspot")) add(Tile(Icons.Rounded.WifiTethering, "Hotspot", false, t.orange) { AppLauncherHelper.openHotspotSettings(ctx) })
        if (w.on("split")) add(Tile(Icons.Rounded.Splitscreen, "Split", false, t.accent) { vm.openSplitAppDialog() })
        if (w.on("dimmer")) add(Tile(Icons.Rounded.Bedtime, "Dim", false, t.indigo) { vm.setOledDimmer(true) })
        if (w.on("boost")) add(Tile(Icons.Rounded.FlashOn, "Boost", false, t.green) { vm.boostMemory() })
    }
    BoxWithConstraints(Modifier.fillMaxSize().padding(10.dp)) {
        val cols = (maxWidth / 88.dp).toInt().coerceIn(1, 6)
        val rows = tiles.chunked(cols)
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            rows.forEach { row ->
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { tile -> ActionTile(tile.icon, tile.label, tile.active, tile.color, Modifier.weight(1f).fillMaxHeight(), tile.onClick) }
                    repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
fun ShortcutsWidget(w: WidgetInstance, vm: LauncherViewModel) {
    val t = LocalCarTokens.current
    val icons by vm.processedIcons.collectAsStateWithLifecycle()
    val apps by vm.allApps.collectAsStateWithLifecycle()
    val chosen = remember(w.options["apps"], apps) { w.list.mapNotNull { p -> apps.firstOrNull { it.packageName == p } } }
    if (chosen.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("Favourite apps", style = MaterialTheme.typography.labelMedium, color = t.secondaryLabel)
            Spacer(Modifier.height(8.dp))
            Text("Choose apps", style = MaterialTheme.typography.labelLarge, color = Color.White,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(t.accent).pressable { vm.openPicker(PickerTarget.Shortcuts(w.id)) }.padding(horizontal = 16.dp, vertical = 9.dp))
        }
        return
    }
    BoxWithConstraints(Modifier.fillMaxSize().padding(10.dp)) {
        val showLabels = w.on("labels") && maxHeight > 90.dp
        val cell = 78.dp
        val cols = (maxWidth / cell).toInt().coerceAtLeast(1)
        val rowsFit = (maxHeight / (if (showLabels) 92.dp else 70.dp)).toInt().coerceAtLeast(1)
        val shown = chosen.take(cols * rowsFit)
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
            shown.chunked(cols).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    row.forEach { app ->
                        Column(Modifier.width(cell - 6.dp).pressable { vm.launchApp(app) }, horizontalAlignment = Alignment.CenterHorizontally) {
                            val ic = icons[app.packageName]
                            if (ic != null) Image(ic, app.displayName, Modifier.size(54.dp))
                            else Box(Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)).background(t.fill))
                            if (showLabels) Text(app.displayName, style = MaterialTheme.typography.labelSmall, color = t.label, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WidgetContent(w: WidgetInstance, vm: LauncherViewModel) {
    when (w.type) {
        com.example.model.WidgetType.MAP -> MapWidget(w, vm)
        com.example.model.WidgetType.NOW_PLAYING -> NowPlayingWidget(w, vm)
        com.example.model.WidgetType.SPEED -> SpeedWidget(w, vm)
        com.example.model.WidgetType.CLOCK -> ClockWidget(w, vm)
        com.example.model.WidgetType.DATE -> DateWidget(w, vm)
        com.example.model.WidgetType.TRIP -> TripWidget(w, vm)
        com.example.model.WidgetType.QUICK_CONTROLS -> QuickControlsWidget(w, vm)
        com.example.model.WidgetType.SHORTCUTS -> ShortcutsWidget(w, vm)
        com.example.model.WidgetType.PRAYER -> PrayerWidget(w, vm)
        com.example.model.WidgetType.WEATHER -> WeatherWidget(w, vm)
        com.example.model.WidgetType.SYSTEM -> SystemWidget(w, vm)
        com.example.model.WidgetType.PARKING -> ParkingWidget(w, vm)
        com.example.model.WidgetType.COMPASS -> CompassWidget(w, vm)
    }
}
