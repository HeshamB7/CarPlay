package com.example.ui.common

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.AccentChoices
import com.example.ui.theme.LocalCarTokens
import com.example.viewmodel.LauncherViewModel
import com.example.viewmodel.PickerTarget
import kotlin.math.roundToInt

fun widgetIcon(type: WidgetType): ImageVector = when (type) {
    WidgetType.MAP -> Icons.Rounded.Map
    WidgetType.NOW_PLAYING -> Icons.Rounded.MusicNote
    WidgetType.SPEED -> Icons.Rounded.Speed
    WidgetType.CLOCK -> Icons.Rounded.Schedule
    WidgetType.DATE -> Icons.Rounded.CalendarToday
    WidgetType.TRIP -> Icons.Rounded.Timeline
    WidgetType.QUICK_CONTROLS -> Icons.Rounded.ToggleOn
    WidgetType.SHORTCUTS -> Icons.Rounded.Apps
    WidgetType.PRAYER -> Icons.Rounded.NightsStay
    WidgetType.WEATHER -> Icons.Rounded.WbSunny
    WidgetType.SYSTEM -> Icons.Rounded.Memory
    WidgetType.PARKING -> Icons.Rounded.LocalParking
    WidgetType.COMPASS -> Icons.Rounded.Explore
}

@Composable
fun SheetTitle(text: String, trailing: @Composable (() -> Unit)? = null) {
    val t = LocalCarTokens.current
    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, style = MaterialTheme.typography.headlineMedium, color = t.label, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        trailing?.invoke()
    }
}

@Composable
private fun Stepper(label: String, value: Int, min: Int, max: Int, onChange: (Int) -> Unit) {
    val t = LocalCarTokens.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyLarge, color = t.label, modifier = Modifier.weight(1f))
        Box(Modifier.size(40.dp).clip(CircleShape).background(t.fill).pressable(enabled = value > min) { onChange(value - 1) }, contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Remove, "less", tint = if (value > min) t.label else t.tertiaryLabel)
        }
        Text(value.toString(), style = MaterialTheme.typography.titleMedium, color = t.label, modifier = Modifier.width(44.dp), textAlign = TextAlign.Center)
        Box(Modifier.size(40.dp).clip(CircleShape).background(t.fill).pressable(enabled = value < max) { onChange(value + 1) }, contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Add, "more", tint = if (value < max) t.label else t.tertiaryLabel)
        }
    }
}

@Composable
fun WidgetOptionsSheet(vm: LauncherViewModel, prefs: LauncherPreferences, widgetId: String) {
    val t = LocalCarTokens.current
    val pageIdx = prefs.pages.indexOfFirst { p -> p.widgets.any { it.id == widgetId } }
    val w = prefs.pages.getOrNull(pageIdx)?.widgets?.firstOrNull { it.id == widgetId }
    if (w == null) { vm.openWidgetOptions(null); return }
    Modal(onDismiss = { vm.openWidgetOptions(null) }) {
        SheetTitle(w.type.title) {
            PillButton("Done") { vm.openWidgetOptions(null) }
        }
        Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(w.type.desc, style = MaterialTheme.typography.bodySmall, color = t.secondaryLabel)
            Stepper("Width (columns)", w.w, w.type.minW, prefs.gridCols) { vm.resizeWidget(w.id, it, w.h) }
            Stepper("Height (rows)", w.h, w.type.minH, prefs.gridRows) { vm.resizeWidget(w.id, w.w, it) }
            if (prefs.pages.size > 1) {
                Text("Move to page", style = MaterialTheme.typography.labelMedium, color = t.secondaryLabel)
                ChipRow(prefs.pages.indices.map { "Page ${it + 1}" }, pageIdx) { vm.moveWidgetToPage(w.id, it) }
            }
            if (w.type == WidgetType.SHORTCUTS) {
                PillButton("Choose apps (${w.list.size})", modifier = Modifier.fillMaxWidth(), filled = false) { vm.openPicker(PickerTarget.Shortcuts(w.id)) }
            }
            Text("Card style", style = MaterialTheme.typography.labelMedium, color = t.secondaryLabel)
            val styles = listOf("default" to "Default", "glass" to "Glass", "solid" to "Solid", "outline" to "Outline", "none" to "None")
            ChipRow(styles.map { it.second }, styles.indexOfFirst { it.first == w.str("card") }.coerceAtLeast(0)) { vm.setWidgetOption(w.id, "card", styles[it].first) }
            Text("Tint", style = MaterialTheme.typography.labelMedium, color = t.secondaryLabel)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val none = w.tint == 0
                Box(Modifier.size(34.dp).clip(CircleShape).background(t.fill).border(if (none) 3.dp else 0.dp, t.label, CircleShape).pressable { vm.setWidgetOption(w.id, "tint", "0") }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Close, "No tint", tint = t.secondaryLabel, modifier = Modifier.size(16.dp))
                }
                AccentChoices.take(9).forEach { (_, c) ->
                    val sel = w.tint == c
                    Box(Modifier.size(34.dp).clip(CircleShape).background(Color(c)).border(if (sel) 3.dp else 0.dp, t.label, CircleShape).pressable { vm.setWidgetOption(w.id, "tint", (c.toLong() and 0xFFFFFFFFL).toString()) })
                }
            }
            w.type.options.forEach { opt ->
                when (opt) {
                    is WidgetOption.Toggle -> Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(opt.label, style = MaterialTheme.typography.bodyLarge, color = t.label, modifier = Modifier.weight(1f))
                        IosSwitch(w.on(opt.key), { vm.setWidgetOption(w.id, opt.key, if (it) "1" else "0") })
                    }
                    is WidgetOption.Choice -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(opt.label, style = MaterialTheme.typography.labelMedium, color = t.secondaryLabel)
                        Segmented(opt.choices.map { it.second }, opt.choices.indexOfFirst { it.first == w.str(opt.key) }.coerceAtLeast(0), { vm.setWidgetOption(w.id, opt.key, opt.choices[it].first) }, Modifier.fillMaxWidth())
                    }
                }
            }
            PillButton("Remove widget", modifier = Modifier.fillMaxWidth(), filled = false, color = t.red) { vm.removeWidget(w.id) }
        }
    }
}

@Composable
fun AddWidgetSheet(vm: LauncherViewModel) {
    val t = LocalCarTokens.current
    Modal(onDismiss = { vm.openAddWidget(false) }, maxWidth = 760) {
        SheetTitle("Add Widget") { PillButton("Close", filled = false) { vm.openAddWidget(false) } }
        LazyVerticalGrid(GridCells.Adaptive(210.dp), Modifier.weight(1f, fill = false), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(WidgetType.entries.toList()) { type ->
                Row(
                    Modifier.clip(RoundedCornerShape(16.dp)).background(t.fill).pressable { vm.addWidget(type); vm.openAddWidget(false) }.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(11.dp)).background(t.accent), contentAlignment = Alignment.Center) {
                        Icon(widgetIcon(type), null, tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                    Column {
                        Text(type.title, style = MaterialTheme.typography.titleSmall, color = t.label, maxLines = 1)
                        Text(type.desc, style = MaterialTheme.typography.labelSmall, color = t.secondaryLabel, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

/** Full-screen multi-select of apps (sidebar or a shortcuts widget). */
@Composable
fun AppPickerSheet(vm: LauncherViewModel, target: PickerTarget, prefs: LauncherPreferences, apps: List<AppEntry>, icons: Map<String, ImageBitmap>) {
    val t = LocalCarTokens.current
    val selected: List<String> = when (target) {
        is PickerTarget.Dock -> prefs.dockApps
        is PickerTarget.Shortcuts -> prefs.pages.flatMap { it.widgets }.firstOrNull { it.id == target.widgetId }?.list ?: emptyList()
    }
    fun toggle(pkg: String) {
        when (target) {
            is PickerTarget.Dock -> vm.toggleDock(pkg)
            is PickerTarget.Shortcuts -> vm.setShortcutApps(target.widgetId, if (pkg in selected) selected - pkg else selected + pkg)
        }
    }
    Modal(onDismiss = { vm.openPicker(null) }, maxWidth = 820) {
        SheetTitle(if (target is PickerTarget.Dock) "Sidebar apps" else "Shortcut apps") {
            Text("${selected.size} selected", style = MaterialTheme.typography.labelMedium, color = t.secondaryLabel, modifier = Modifier.padding(end = 10.dp))
            PillButton("Done") { vm.openPicker(null) }
        }
        LazyVerticalGrid(GridCells.Adaptive(92.dp), Modifier.weight(1f, fill = false), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(apps, key = { it.packageName }) { app ->
                val idx = selected.indexOf(app.packageName)
                Column(
                    Modifier.clip(RoundedCornerShape(14.dp)).background(if (idx >= 0) t.accent.copy(alpha = 0.18f) else Color.Transparent).pressable { toggle(app.packageName) }.padding(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box {
                        val ic = icons[app.packageName]
                        if (ic != null) Image(ic, app.displayName, Modifier.size(52.dp)) else Box(Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)).background(t.fill))
                        if (idx >= 0) Box(Modifier.align(Alignment.TopEnd).size(20.dp).clip(CircleShape).background(t.accent), contentAlignment = Alignment.Center) {
                            Text("${idx + 1}", style = MaterialTheme.typography.labelSmall, color = Color.White)
                        }
                    }
                    Text(app.displayName, style = MaterialTheme.typography.labelSmall, color = t.label, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                }
            }
        }
    }
}

@Composable
fun AppActionsSheet(vm: LauncherViewModel, app: AppEntry, icon: ImageBitmap?, prefs: LauncherPreferences) {
    val t = LocalCarTokens.current
    var renaming by remember(app.packageName) { mutableStateOf(false) }
    var text by remember(app.packageName) { mutableStateOf(app.displayName) }
    val inDock = app.packageName in prefs.dockApps
    Modal(onDismiss = { vm.dismissAppEdit() }, maxWidth = 460) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(bottom = 12.dp)) {
            if (icon != null) Image(icon, null, Modifier.size(52.dp))
            Text(app.displayName, style = MaterialTheme.typography.headlineMedium, color = t.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (renaming) {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(t.fill).padding(14.dp)) {
                BasicTextField(text, { text = it }, singleLine = true, textStyle = MaterialTheme.typography.bodyLarge.copy(color = t.label), cursorBrush = SolidColor(t.accent), modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillButton("Cancel", Modifier.weight(1f), filled = false) { renaming = false }
                PillButton("Save", Modifier.weight(1f)) { vm.renameApp(app.packageName, text); vm.dismissAppEdit() }
            }
        } else {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionRow(Icons.Rounded.OpenInNew, "Open") { vm.dismissAppEdit(); vm.launchApp(app) }
                ActionRow(if (inDock) Icons.Rounded.RemoveCircleOutline else Icons.Rounded.AddCircleOutline, if (inDock) "Remove from sidebar" else "Add to sidebar") { vm.toggleDock(app.packageName) }
                if (inDock) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f)) { ActionRow(Icons.Rounded.KeyboardArrowUp, "Sidebar up") { vm.moveDock(app.packageName, -1) } }
                    Box(Modifier.weight(1f)) { ActionRow(Icons.Rounded.KeyboardArrowDown, "Sidebar down") { vm.moveDock(app.packageName, 1) } }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f)) { ActionRow(Icons.Rounded.ChevronLeft, "Move earlier") { vm.moveAppInOrder(app.packageName, -1) } }
                    Box(Modifier.weight(1f)) { ActionRow(Icons.Rounded.ChevronRight, "Move later") { vm.moveAppInOrder(app.packageName, 1) } }
                }
                if (app.virtualAction == null) ActionRow(Icons.Rounded.Splitscreen, "Split screen") { vm.dismissAppEdit(); vm.openSplitAppDialog(app.packageName) }
                ActionRow(Icons.Rounded.Edit, "Rename") { renaming = true }
                ActionRow(Icons.Rounded.VisibilityOff, "Hide app", t.red) { vm.setAppHidden(app.packageName, true); vm.dismissAppEdit() }
            }
        }
    }
}

@Composable
private fun ActionRow(icon: ImageVector, label: String, tint: Color? = null, onClick: () -> Unit) {
    val t = LocalCarTokens.current
    Row(
        Modifier.fillMaxWidth().heightIn(min = 48.dp).clip(RoundedCornerShape(13.dp)).background(t.fill).pressable(pressedScale = 0.97f, onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(icon, null, tint = tint ?: t.label, modifier = Modifier.size(20.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = tint ?: t.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun SplitPickerSheet(vm: LauncherViewModel, apps: List<AppEntry>, icons: Map<String, ImageBitmap>, pre: String?) {
    val t = LocalCarTokens.current
    val list = remember(apps) { apps.filter { it.virtualAction == null } }
    var a by remember(pre, list) { mutableStateOf(pre ?: list.firstOrNull()?.packageName) }
    var b by remember(list) { mutableStateOf(list.getOrNull(1)?.packageName ?: list.firstOrNull()?.packageName) }
    @Composable fun row(label: String, sel: String?, onPick: (String) -> Unit) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = t.secondaryLabel)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { label + it.packageName }) { app ->
                Column(
                    Modifier.width(74.dp).clip(RoundedCornerShape(14.dp)).background(if (sel == app.packageName) t.accent.copy(alpha = 0.25f) else t.fill).pressable { onPick(app.packageName) }.padding(6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    icons[app.packageName]?.let { Image(it, null, Modifier.size(40.dp)) }
                    Text(app.displayName, style = MaterialTheme.typography.labelSmall, color = t.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
    Modal(onDismiss = { vm.dismissSplitAppDialog() }, maxWidth = 640) {
        SheetTitle("Split Screen") { PillButton("Cancel", filled = false) { vm.dismissSplitAppDialog() } }
        Text("Two apps side by side (needs multi-window support in the head unit's Android build).", style = MaterialTheme.typography.bodySmall, color = t.secondaryLabel, modifier = Modifier.padding(bottom = 8.dp))
        row("Left", a) { a = it }
        Spacer(Modifier.height(8.dp))
        row("Right", b) { b = it }
        Spacer(Modifier.height(12.dp))
        PillButton("Launch", Modifier.fillMaxWidth()) { val x = a; val y = b; if (x != null && y != null) vm.launchSplitScreen(x, y) }
    }
}

@Composable
fun ValetPinSheet(onVerify: (String) -> Boolean, onDismiss: () -> Unit) {
    val t = LocalCarTokens.current
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    Modal(onDismiss = onDismiss, maxWidth = 360) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(Icons.Rounded.Lock, null, tint = t.orange, modifier = Modifier.size(30.dp))
            Text("Enter Passcode", style = MaterialTheme.typography.headlineMedium, color = t.label)
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                repeat(4) { i -> Box(Modifier.size(16.dp).clip(CircleShape).background(if (error) t.red else if (i < pin.length) t.accent else t.fill)) }
            }
            if (error) Text("Incorrect passcode", style = MaterialTheme.typography.labelMedium, color = t.red)
            listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("C", "0", "<")).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { key ->
                        Box(
                            Modifier.size(width = 80.dp, height = 52.dp).clip(RoundedCornerShape(14.dp)).background(t.fill).pressable {
                                error = false
                                when (key) {
                                    "C" -> pin = ""
                                    "<" -> pin = pin.dropLast(1)
                                    else -> if (pin.length < 4) {
                                        pin += key
                                        if (pin.length == 4) { if (!onVerify(pin)) { error = true; pin = "" } }
                                    }
                                }
                            },
                            contentAlignment = Alignment.Center
                        ) {
                            if (key == "<") Icon(Icons.AutoMirrored.Rounded.Backspace, null, tint = t.label, modifier = Modifier.size(20.dp))
                            else Text(key, style = MaterialTheme.typography.titleLarge, color = t.label)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OnboardingSheet(hasLocation: Boolean, hasMedia: Boolean, onLocation: () -> Unit, onMedia: () -> Unit, onHome: () -> Unit, onFinish: () -> Unit) {
    val t = LocalCarTokens.current
    Modal(onDismiss = {}, maxWidth = 620) {
        Text("Welcome to CarDeck", style = MaterialTheme.typography.headlineLarge, color = t.label)
        Text("Three quick steps. You can skip any of them and change everything later in Settings.", style = MaterialTheme.typography.bodyMedium, color = t.secondaryLabel, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
        Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            PermRow(Icons.Rounded.LocationOn, "Location", "Live speed, trip computer, prayer times, auto day/night", hasLocation, onLocation)
            PermRow(Icons.Rounded.MusicNote, "Now Playing", "Show and control media from any app", hasMedia, onMedia)
            PermRow(Icons.Rounded.Home, "Default launcher", "Open CarDeck when the unit starts", false, onHome)
        }
        Spacer(Modifier.height(12.dp))
        PillButton("Continue", Modifier.fillMaxWidth(), onClick = onFinish)
    }
}

@Composable
private fun PermRow(icon: ImageVector, title: String, desc: String, granted: Boolean, onClick: () -> Unit) {
    val t = LocalCarTokens.current
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(t.fill).padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(icon, null, tint = if (granted) t.green else t.accent, modifier = Modifier.size(26.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = t.label)
            Text(desc, style = MaterialTheme.typography.labelSmall, color = t.secondaryLabel, maxLines = 2)
        }
        if (granted) Icon(Icons.Rounded.CheckCircle, null, tint = t.green) else PillButton("Allow", filled = false, onClick = onClick)
    }
}

@Composable
fun DimmerOverlay(vm: LauncherViewModel, prefs: LauncherPreferences) {
    val now by vm.now.collectAsState()
    val tel by vm.telemetryState.collectAsState()
    val red = Color(0xFF9E1F1F)
    Box(
        Modifier.fillMaxSize().background(Color.Black).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.setOledDimmer(false) },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(Fmt.time(now, prefs.use24h, false, prefs.arabicDigits), style = MaterialTheme.typography.displayLarge.copy(fontSize = 84.sp), color = red)
            if (tel.hasLocationPermission) {
                val mph = prefs.speedUnit == SpeedUnit.MPH
                Text("${(tel.speedKmh * (if (mph) 0.621371f else 1f)).roundToInt()} ${if (mph) "mph" else "km/h"}", style = MaterialTheme.typography.headlineLarge, color = red)
            }
            Text("Tap to wake", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF5C1212))
        }
    }
}
