# Single source of truth for Apple-style glyph icons (100x100 grid).
# Layer kinds: circle, rrect, path.  style keys: fill, stroke, sw, op, rot=(deg,cx,cy), t=(scale,tx,ty), cap
W='#FFFFFF'
def C(cx,cy,r,**s): return ('circle',(cx,cy,r),s)
def R(x,y,w,h,rx,**s): return ('rrect',(x,y,w,h,rx),s)
def P(d,**s): return ('path',(d,),s)

CALL="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"
FOLDER="M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"
NAVARROW="M12 2L4.5 20.29l.71.71L12 18l6.79 3 .71-.71z"
PERSON="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"

def gear_teeth(color, n=12, r0=33, r1=45, w=9):
    return [R(50-w/2,50-r1,w,r1-r0+4,2.5,fill=color,rot=(i*360/n,50,50)) for i in range(n)]

ICONS = {}
ICONS['phone'] = dict(bg=('#6BEE7B','#1CC03A'), layers=[P(CALL,fill=W,t=(2.9,15.2,15.4))])
ICONS['messages'] = dict(bg=('#6BEE7B','#1CC03A'), layers=[
    P("M50 20 C32 20 18 31.6 18 46 C18 54.2 22.6 61.4 29.8 66.2 C29 71.4 26.4 76.2 22 80 C30.6 79.4 37.4 76.2 41.8 72.4 C44.4 72.8 47.2 73 50 73 C68 73 82 61.4 82 46 C82 31.6 68 20 50 20 Z",fill=W)])
ICONS['music'] = dict(bg=('#FF6A86','#F92140'), layers=[
    P("M42 30 L80 22 L80 66 L72 66 L72 36 L50 41 L50 72 L42 72 Z",fill=W),
    C(38,73,10.5,fill=W), C(68,67,10.5,fill=W)])
ICONS['nowplaying'] = dict(bg=('#4A4A4D','#17171A'), layers=[
    R(22,44,9,24,4.5,fill='#FF375F'), R(35,30,9,52,4.5,fill='#FF375F'), R(48,22,9,64,4.5,fill='#FF375F'),
    R(61,34,9,44,4.5,fill='#FF375F'), R(74,46,9,20,4.5,fill='#FF375F')])
ICONS['podcasts'] = dict(bg=('#C468F5','#7B2AD6'), layers=[
    P("M30 58 A24 24 0 1 1 70 58",stroke=W,sw=6,cap='round'),
    P("M38.5 53 A14 14 0 1 1 61.5 53",stroke=W,sw=6,cap='round'),
    C(50,46,6.5,fill=W), R(44,56,12,26,6,fill=W)])
ICONS['books'] = dict(bg=('#FFB04F','#FF7A00'), layers=[
    P("M48 33 C40 27 28 26 18 29 L18 72 C28 69 40 70 48 76 Z",fill=W),
    P("M52 33 C60 27 72 26 82 29 L82 72 C72 69 60 70 52 76 Z",fill=W)])
ICONS['settings'] = dict(bg=('#A7A7AE','#6A6A72'), layers=gear_teeth('#E4E4E9')+[
    C(50,50,30,fill='#E4E4E9'), C(50,50,17,fill='#5E5E66'), C(50,50,9,fill='#C9C9CF')])
ICONS['camera'] = dict(bg=('#DADADF','#98989F'), layers=[
    R(32,24,22,12,5,fill='#2B2B2E'), R(14,30,72,50,11,fill='#2B2B2E'), C(50,56,19,fill='#555559'), C(50,56,14,fill='#161618'),
    C(50,56,6,fill='#2E3A63'), R(71,37,9,6,3,fill='#E8E8EC')])
ICONS['calculator'] = dict(bg=('#4B4B50','#1B1B1E'), layers=[
    R(16,16,68,20,6,fill='#2A2A2D'),
    *[R(16+i*18,42,14,14,5,fill=('#FF9F0A' if i==3 else '#A5A5AA')) for i in range(4)],
    *[R(16+i*18,60,14,14,5,fill=('#FF9F0A' if i==3 else '#5E5E63')) for i in range(4)],
    *[R(16+i*18,78,14,10,4,fill=('#FF9F0A' if i==3 else '#5E5E63')) for i in range(4)]])
ICONS['files'] = dict(bg=('#FFFFFF','#E9ECF4'), layers=[P(FOLDER,fill='#2D8CFF',t=(3.2,11.6,13.5))])
ICONS['weather'] = dict(bg=('#59B4FF','#2273E6'), layers=[
    C(38,40,15,fill='#FFD60A'),
    C(42,66,14,fill=W), C(58,60,18,fill=W), C(72,69,12,fill=W), R(32,66,48,15,7.5,fill=W)])
petal = lambda col,i: ('path',("M50 50 C40 38 40 20 50 14 C60 20 60 38 50 50 Z",),dict(fill=col,op=.9,rot=(i*45,50,50)))
ICONS['photos'] = dict(bg=('#FFFFFF','#F2F2F7'), layers=[petal(c,i) for i,c in enumerate(['#FF9F0A','#FFD60A','#A3E635','#30D158','#32ADE6','#5E5CE6','#BF5AF2','#FF375F'])])
ICONS['radio'] = dict(bg=('#FF6B6B','#E02447'), layers=[
    R(16,38,68,44,9,fill=W), P("M64 38 L80 18",stroke=W,sw=4.5,cap='round'),
    C(36,60,12,fill='#E02447'), C(36,60,5,fill=W), R(56,48,18,4.5,2.2,fill='#E02447'), R(56,58,18,4.5,2.2,fill='#E02447'), R(56,68,12,4.5,2.2,fill='#E02447')])
ICONS['bluetooth'] = dict(bg=('#46A8FF','#0A5FE0'), layers=[P("M34 36 L66 64 L50 78 L50 22 L66 36 L34 64",stroke=W,sw=7,cap='round',join='round')])
ICONS['btmusic'] = dict(bg=('#46A8FF','#0A5FE0'), layers=[
    P("M42 30 L74 22 L74 62 L67 62 L67 36 L49 40 L49 68 L42 68 Z",fill=W), C(38,69,9.5,fill=W), C(62,63,9.5,fill=W)])
ICONS['vehicle'] = dict(bg=('#5C6676','#242A36'), layers=[
    P("M9 62 L9 53 C9 48 12 45 17 44 L29 42 L39 30 C41 27 44 26 47 26 L66 26 C70 26 73 28 75 31 L80 41 L86 43 C90 44 92 47 92 51 L92 62 Z",fill=W),
    P("M41 41 L47 32 L58 32 L58 41 Z",fill='#4A5466'), P("M62 41 L62 32 L67 32 L73 41 Z",fill='#4A5466'),
    C(31,66,10,fill='#242A36'), C(31,66,6,fill=W), C(71,66,10,fill='#242A36'), C(71,66,6,fill=W)])
ICONS['backcam'] = dict(bg=('#3A3A3E','#0B0B0D'), layers=[
    P("M30 84 L41 28",stroke='#32D74B',sw=5,cap='round'), P("M70 84 L59 28",stroke='#32D74B',sw=5,cap='round'),
    P("M33 68 L67 68",stroke='#FFD60A',sw=5,cap='round'), P("M36 52 L64 52",stroke='#FF9F0A',sw=5,cap='round'), P("M39 38 L61 38",stroke='#FF453A',sw=5,cap='round')])
ICONS['contacts'] = dict(bg=('#C3C3C9','#8A8A92'), layers=[P(PERSON,fill=W,t=(3.4,9.2,10.5))])
ICONS['video'] = dict(bg=('#3A3A3E','#0B0B0D'), layers=[C(50,50,30,stroke=W,sw=5), P("M43 36 L66 50 L43 64 Z",fill=W)])
ICONS['navigation'] = dict(bg=('#3FA2FF','#0A60E0'), layers=[P(NAVARROW,fill=W,t=(3.6,6.8,8.5))])
ICONS['browser'] = dict(bg=('#FFFFFF','#E9ECF4'), layers=[C(50,50,34,fill='#1C8CFF'), C(50,50,28,fill='#FFFFFF'),
    P("M50 24 L58 50 L50 76 L42 50 Z",fill='#FF3B30',rot=(40,50,50)), P("M50 24 L58 50 L42 50 Z",fill='#1C8CFF',rot=(40,50,50))])
ICONS['maps'] = dict(bg=('#F4F1E9','#F4F1E9'), layers=[
    P("M0 0 L44 0 L36 40 L0 46 Z",fill='#A6DB9B'), P("M62 100 L100 56 L100 100 Z",fill='#9ED0F7'),
    P("M-10 72 L110 38",stroke=W,sw=17), P("M-10 72 L110 38",stroke='#FFD34E',sw=11),
    P("M44 112 L58 -12",stroke=W,sw=20), P("M44 112 L58 -12",stroke='#3B8DFF',sw=13),
    C(50,60,17,fill=W), C(50,60,13.5,fill='#0A84FF'), P(NAVARROW,fill=W,t=(1.05,37.4,47.9)),
    R(66,12,22,16,4,fill=W), R(68,14,18,5,2,fill='#FF3B30'), R(68,20,18,6,2,fill='#0A84FF')])
ICONS['clock'] = dict(bg=('#2A2A2D','#000000'), layers=[
    C(50,50,38,fill=W),
    *[R(48.8,15.5,2.4,(8 if i%3==0 else 4.5),1.2,fill='#1C1C1E',rot=(i*30,50,50)) for i in range(12)],
    R(48.2,28,3.6,24,1.8,fill='#1C1C1E',rot=(305,50,50)), R(48.6,22,2.8,32,1.4,fill='#1C1C1E',rot=(54,50,50)),
    R(49.4,20,1.2,36,.6,fill='#FF9F0A',rot=(180,50,50)), C(50,50,2.8,fill='#FF9F0A')])
# Calendar is drawn dynamically in code (date text); preview uses sample
ICONS['calendar'] = dict(bg=('#FFFFFF','#FFFFFF'), layers=[R(0,0,100,28,0,fill='#FF3B30')])

def svg_layer(l):
    kind,args,s=l
    fill=s.get('fill'); stroke=s.get('stroke'); sw=s.get('sw',0); op=s.get('op',1)
    attrs=f' fill="{fill}"' if fill else ' fill="none"'
    if stroke: attrs+=f' stroke="{stroke}" stroke-width="{sw}" stroke-linecap="{s.get("cap","butt")}" stroke-linejoin="{s.get("join","round")}"'
    if op!=1: attrs+=f' opacity="{op}"'
    tf=''
    if 't' in s: sc,tx,ty=s['t']; tf+=f'translate({tx} {ty}) scale({sc}) '
    if 'rot' in s: dg,cx,cy=s['rot']; tf=f'rotate({dg} {cx} {cy}) '+tf
    tfa=f' transform="{tf.strip()}"' if tf else ''
    if kind=='circle': cx,cy,r=args; return f'<circle cx="{cx}" cy="{cy}" r="{r}"{attrs}{tfa}/>'
    if kind=='rrect': x,y,w,h,rx=args; return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}"{attrs}{tfa}/>'
    return f'<path d="{args[0]}"{attrs}{tfa}/>'

def svg_icon(name, size=100):
    from squircle import squircle_svg_path
    spec=ICONS[name]; t,b=spec['bg']
    sq=squircle_svg_path(100)
    body=''.join(svg_layer(l) for l in spec['layers'])
    extra=''
    if name=='calendar':
        extra='<text x="50" y="22" font-family="DejaVu Sans" font-weight="bold" font-size="17" fill="#fff" text-anchor="middle">FRI</text><text x="50" y="78" font-family="DejaVu Sans" font-weight="bold" font-size="52" fill="#1C1C1E" text-anchor="middle">13</text>'
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 100 100"><defs>'
            f'<linearGradient id="g_{name}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{t}"/><stop offset="1" stop-color="{b}"/></linearGradient>'
            f'<clipPath id="c_{name}"><path d="{sq}"/></clipPath></defs>'
            f'<g clip-path="url(#c_{name})"><rect width="100" height="100" fill="url(#g_{name})"/>{body}{extra}</g></svg>')

if __name__=='__main__':
    import cairosvg, io
    from PIL import Image
    names=list(ICONS)
    cols=7; cell=150
    rows=(len(names)+cols-1)//cols
    sheet=Image.new('RGB',(cols*cell,rows*cell),(30,30,34))
    for i,n in enumerate(names):
        png=cairosvg.svg2png(bytestring=svg_icon(n,120).encode())
        im=Image.open(io.BytesIO(png)).convert('RGBA')
        sheet.paste(im,((i%cols)*cell+15,(i//cols)*cell+15),im)
    sheet.save('icon_preview.png'); print(names)
