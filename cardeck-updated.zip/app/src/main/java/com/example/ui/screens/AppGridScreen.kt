package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppEntry
import com.example.model.LauncherPreferences
import com.example.ui.common.pressable
import com.example.ui.theme.LocalCarTokens
import com.example.viewmodel.LauncherViewModel

@Composable
fun AppGridScreen(vm: LauncherViewModel, prefs: LauncherPreferences, apps: List<AppEntry>, icons: Map<String, ImageBitmap>, modifier: Modifier = Modifier) {
    val t = LocalCarTokens.current
    BoxWithConstraints(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        val dots = 36.dp
        val areaH = maxHeight - dots
        val cols = if (prefs.appGridCols > 0) prefs.appGridCols else (maxWidth / (prefs.iconSizeDp.dp * 1.55f)).toInt().coerceIn(3, 9)
        val rows = prefs.appGridRows.coerceIn(1, 5)
        val perPage = cols * rows
        val pageCount = ((apps.size + perPage - 1) / perPage).coerceAtLeast(1)
        val pager = rememberPagerState { pageCount }
        val cellW = maxWidth / cols
        val cellH = areaH / rows
        val iconSize = minOf(prefs.iconSizeDp.dp, cellW * 0.82f, cellH * (if (prefs.showLabels) 0.62f else 0.85f))

        Column(Modifier.fillMaxSize()) {
            HorizontalPager(pager, Modifier.weight(1f).fillMaxWidth()) { page ->
                val slice = apps.drop(page * perPage).take(perPage)
                Column(Modifier.fillMaxSize()) {
                    slice.chunked(cols).forEach { row ->
                        Row(Modifier.weight(1f).fillMaxWidth()) {
                            row.forEach { app ->
                                Column(
                                    Modifier.weight(1f).fillMaxHeight().pressable(onLongClick = { vm.requestAppEdit(app) }, onClick = { vm.launchApp(app) }),
                                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                                ) {
                                    val ic = icons[app.packageName]
                                    if (ic != null) Image(ic, app.displayName, Modifier.size(iconSize))
                                    else Box(Modifier.size(iconSize).clip(RoundedCornerShape(iconSize * 0.22f)).background(t.fill))
                                    if (prefs.showLabels) Text(
                                        app.displayName,
                                        style = MaterialTheme.typography.labelMedium.copy(fontSize = prefs.labelSizeSp.sp),
                                        color = t.label, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(top = 5.dp, start = 4.dp, end = 4.dp)
                                    )
                                }
                            }
                            repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                    repeat(rows - slice.chunked(cols).size) { Spacer(Modifier.weight(1f)) }
                }
            }
            Row(Modifier.fillMaxWidth().height(dots), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
                if (pageCount > 1) repeat(pageCount) { i ->
                    val c by animateColorAsState(if (i == pager.currentPage) t.label else t.label.copy(alpha = 0.3f), label = "gdot")
                    Box(Modifier.size(8.dp).clip(CircleShape).background(c))
                }
            }
        }
    }
}
