package com.example.engine

import com.example.model.PrayerMethod
import java.util.TimeZone
import kotlin.math.*

/** Offline sun and prayer time maths (NOAA / "sunrise equation"), accurate to about a minute. */
object SolarCalc {
    private const val D2R = PI / 180.0
    private const val DAY_MS = 86_400_000.0

    private class Day(val transitMs: Double, val dec: Double)

    private fun solarDay(epochDay: Long, lon: Double): Day {
        val n = (epochDay - 10957L).toDouble() + 0.0008
        val jstar = n - lon / 360.0
        val m = (357.5291 + 0.98560028 * jstar) % 360.0
        val mr = m * D2R
        val c = 1.9148 * sin(mr) + 0.02 * sin(2 * mr) + 0.0003 * sin(3 * mr)
        val lam = (m + c + 180.0 + 102.9372) % 360.0
        val lr = lam * D2R
        val jt = 2451545.0 + jstar + 0.0053 * sin(mr) - 0.0069 * sin(2 * lr)
        val dec = asin(sin(lr) * sin(23.4397 * D2R))
        return Day((jt - 2440587.5) * DAY_MS, dec)
    }

    private fun hourAngleDeg(altDeg: Double, lat: Double, dec: Double): Double? {
        val cosw = (sin(altDeg * D2R) - sin(lat * D2R) * sin(dec)) / (cos(lat * D2R) * cos(dec))
        if (cosw > 1.0 || cosw < -1.0) return null
        return Math.toDegrees(acos(cosw))
    }

    /** Local calendar day (days since 1970-01-01) of [nowMs] in the default time zone. */
    fun localEpochDay(nowMs: Long, tz: TimeZone = TimeZone.getDefault()): Long =
        Math.floorDiv(nowMs + tz.getOffset(nowMs), 86_400_000L)

    class SunTimes(val sunrise: Long, val sunset: Long, val noon: Long)

    fun sun(nowMs: Long, lat: Double, lon: Double): SunTimes? {
        val d = solarDay(localEpochDay(nowMs), lon)
        val w = hourAngleDeg(-0.833, lat, d.dec) ?: return null
        val rise = d.transitMs - w / 360.0 * DAY_MS
        val set = d.transitMs + w / 360.0 * DAY_MS
        return SunTimes(rise.toLong(), set.toLong(), d.transitMs.toLong())
    }

    /** True when the sun is below the horizon (with a small civil-twilight margin). */
    fun isNight(nowMs: Long, lat: Double, lon: Double): Boolean {
        val s = sun(nowMs, lat, lon) ?: return false
        val margin = 10 * 60_000L
        return nowMs < s.sunrise - margin || nowMs > s.sunset + margin
    }

    class Prayers(val fajr: Long, val sunrise: Long, val dhuhr: Long, val asr: Long, val maghrib: Long, val isha: Long) {
        fun asList(): List<Long> = listOf(fajr, sunrise, dhuhr, asr, maghrib, isha)
    }

    fun prayers(epochDay: Long, lat: Double, lon: Double, method: PrayerMethod, hanafi: Boolean, ramadan: Boolean, offsetMin: Int): Prayers? {
        val d = solarDay(epochDay, lon)
        fun at(alt: Double, sign: Int): Double? = hourAngleDeg(alt, lat, d.dec)?.let { d.transitMs + sign * it / 360.0 * DAY_MS }
        val sunrise = at(-0.833, -1) ?: return null
        val sunset = at(-0.833, 1) ?: return null
        val fajr = at(-method.fajrAngle, -1) ?: return null
        val factor = if (hanafi) 2.0 else 1.0
        val asrAlt = Math.toDegrees(atan(1.0 / (factor + tan(abs(lat * D2R - d.dec)))))
        val asr = at(asrAlt, 1) ?: return null
        val isha = if (method.ishaMinutes > 0) {
            sunset + (if (ramadan && method == PrayerMethod.UMM_AL_QURA) 120 else method.ishaMinutes) * 60_000.0
        } else at(-method.ishaAngle, 1) ?: return null
        val o = offsetMin * 60_000L
        return Prayers((fajr).toLong() + o, sunrise.toLong() + o, d.transitMs.toLong() + o, asr.toLong() + o, sunset.toLong() + o, isha.toLong() + o)
    }

    /** Whether the Hijri month at [nowMs] is Ramadan (Umm al-Qura calendar). */
    fun isRamadan(nowMs: Long): Boolean = hijri(nowMs)?.second == 8

    /** (year, monthIndex0, day) in the Umm al-Qura calendar, or null if unavailable. */
    fun hijri(nowMs: Long): Triple<Int, Int, Int>? = runCatching {
        val cal = android.icu.util.IslamicCalendar(android.icu.util.ULocale("ar_SA"))
        cal.calculationType = android.icu.util.IslamicCalendar.CalculationType.ISLAMIC_UMALQURA
        cal.timeInMillis = nowMs
        Triple(
            cal.get(android.icu.util.Calendar.YEAR),
            cal.get(android.icu.util.Calendar.MONTH),
            cal.get(android.icu.util.Calendar.DAY_OF_MONTH)
        )
    }.getOrNull()

    val hijriMonthsAr = listOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
        "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )
    val hijriMonthsEn = listOf(
        "Muharram", "Safar", "Rabi I", "Rabi II", "Jumada I", "Jumada II",
        "Rajab", "Sha'ban", "Ramadan", "Shawwal", "Dhu al-Qi'dah", "Dhu al-Hijjah"
    )
}
