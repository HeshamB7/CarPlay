package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.*
import com.example.ui.common.*
import com.example.ui.theme.AccentChoices
import com.example.ui.theme.LocalCarTokens
import com.example.viewmodel.LauncherViewModel
import com.example.viewmodel.PickerTarget
import kotlin.math.roundToInt

class SettingsActions(
    val onExport: () -> Unit,
    val onImport: () -> Unit,
    val onPickWallpaper: () -> Unit,
    val onDefaultLauncher: () -> Unit,
    val onNotificationAccess: () -> Unit,
    val onLocationPermission: () -> Unit,
    val onCalendarPermission: () -> Unit
)

private enum class Cat(val title: String, val icon: ImageVector) {
    APPEARANCE("Appearance", Icons.Rounded.Palette),
    SIDEBAR("Sidebar", Icons.Rounded.VerticalSplit),
    DASHBOARD("Dashboard", Icons.Rounded.Widgets),
    APPS("Apps & Icons", Icons.Rounded.Apps),
    DRIVING("Driving", Icons.Rounded.DirectionsCar),
    TIME("Time & Location", Icons.Rounded.Schedule),
    MORE("Backup & More", Icons.Rounded.Settings)
}

@Composable
fun SettingsScreen(vm: LauncherViewModel, prefs: LauncherPreferences, actions: SettingsActions, modifier: Modifier = Modifier) {
    val t = LocalCarTokens.current
    var cat by remember { mutableStateOf(Cat.APPEARANCE) }
    Row(modifier.fillMaxSize().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Column(Modifier.width(220.dp).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Settings", style = MaterialTheme.typography.headlineLarge, color = t.label, modifier = Modifier.padding(start = 8.dp, bottom = 10.dp, top = 4.dp))
            Cat.entries.forEach { c ->
                val sel = c == cat
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if (sel) t.accent else Color.Transparent).pressable(pressedScale = 0.97f) { cat = c }.padding(horizontal = 12.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(c.icon, null, tint = if (sel) Color.White else t.accent, modifier = Modifier.size(22.dp))
                    Text(c.title, style = MaterialTheme.typography.titleSmall, color = if (sel) Color.White else t.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Spacer(Modifier.height(10.dp))
            PillButton("Back to dashboard", Modifier.fillMaxWidth(), filled = false) { vm.navigateBackToDashboard() }
        }
        Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            when (cat) {
                Cat.APPEARANCE -> AppearancePane(vm, prefs, actions)
                Cat.SIDEBAR -> SidebarPane(vm, prefs)
                Cat.DASHBOARD -> DashboardPane(vm, prefs)
                Cat.APPS -> AppsPane(vm, prefs)
                Cat.DRIVING -> DrivingPane(vm, prefs)
                Cat.TIME -> TimePane(vm, prefs)
                Cat.MORE -> MorePane(vm, prefs, actions)
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}

// ------------------------------------------------------------------ building blocks

@Composable
private fun Group(title: String? = null, footer: String? = null, content: @Composable ColumnScope.() -> Unit) {
    val t = LocalCarTokens.current
    Column {
        if (title != null) Text(title.uppercase(), style = MaterialTheme.typography.labelSmall, color = t.secondaryLabel, modifier = Modifier.padding(start = 14.dp, bottom = 6.dp))
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(if (t.isNight) Color(0xFF1C1C1E).copy(alpha = 0.92f) else Color.White.copy(alpha = 0.94f))
                .border(0.75.dp, t.cardBorder, RoundedCornerShape(18.dp)).padding(horizontal = 16.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp), content = content
        )
        if (footer != null) Text(footer, style = MaterialTheme.typography.labelSmall, color = t.secondaryLabel, modifier = Modifier.padding(start = 14.dp, top = 6.dp, end = 14.dp))
    }
}

@Composable
private fun Line(content: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 52.dp).padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp), content = content)
}

@Composable
private fun Divider() {
    Box(Modifier.fillMaxWidth().height(0.5.dp).background(LocalCarTokens.current.separator))
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, sub: String? = null, onChange: (Boolean) -> Unit) {
    val t = LocalCarTokens.current
    Line {
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodyLarge, color = t.label)
            if (sub != null) Text(sub, style = MaterialTheme.typography.labelSmall, color = t.secondaryLabel)
        }
        IosSwitch(checked, onChange)
    }
}

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, display: String, steps: Int = 0, onChange: (Float) -> Unit) {
    val t = LocalCarTokens.current
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Text(label, style = MaterialTheme.typography.bodyLarge, color = t.label, modifier = Modifier.weight(1f))
            Text(display, style = MaterialTheme.typography.bodyMedium, color = t.secondaryLabel)
        }
        IosSlider(value, onChange, range, Modifier.fillMaxWidth(), steps)
    }
}

@Composable
private fun SegRow(label: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val t = LocalCarTokens.current
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, style = MaterialTheme.typography.bodyLarge, color = t.label)
        Segmented(options, selected, onSelect, Modifier.fillMaxWidth())
    }
}

@Composable
private fun ChipsRow(label: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val t = LocalCarTokens.current
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, style = MaterialTheme.typography.bodyLarge, color = t.label)
        ChipRow(options, selected, onSelect)
    }
}

@Composable
private fun ButtonRow(label: String, sub: String? = null, color: Color? = null, action: String, onClick: () -> Unit) {
    val t = LocalCarTokens.current
    Line {
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodyLarge, color = t.label)
            if (sub != null) Text(sub, style = MaterialTheme.typography.labelSmall, color = t.secondaryLabel, maxLines = 2)
        }
        PillButton(action, filled = false, color = color, onClick = onClick)
    }
}

@Composable
private fun TextRow(label: String, value: String, onChange: (String) -> Unit) {
    val t = LocalCarTokens.current
    Line {
        Text(label, style = MaterialTheme.typography.bodyLarge, color = t.label, modifier = Modifier.width(110.dp))
        Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(t.fill).padding(horizontal = 12.dp, vertical = 10.dp)) {
            BasicTextField(value, onChange, singleLine = true, textStyle = MaterialTheme.typography.bodyLarge.copy(color = t.label), cursorBrush = SolidColor(t.accent), modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun ColorRow(label: String, selected: Int, colors: List<Int>, onPick: (Int) -> Unit) {
    val t = LocalCarTokens.current
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, style = MaterialTheme.typography.bodyLarge, color = t.label)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            colors.forEach { c ->
                Box(Modifier.size(34.dp).clip(CircleShape).background(Color(c)).border(if (c == selected) 3.dp else 0.5.dp, if (c == selected) t.label else t.separator, CircleShape).pressable { onPick(c) })
            }
        }
    }
}

// ------------------------------------------------------------------ panes

@Composable
private fun AppearancePane(vm: LauncherViewModel, p: LauncherPreferences, actions: SettingsActions) {
    Group("Day & night", "Sunset mode works offline: it calculates sunrise and sunset from your position, so the screen switches by itself even if the unit never reports day/night.") {
        SegRow("Mode", listOf("Sunset", "System", "Schedule", "Day", "Night"), p.dayNightMode.ordinal) { vm.update { s -> s.copy(dayNightMode = DayNightMode.entries[it]) } }
        if (p.dayNightMode == DayNightMode.SCHEDULE) {
            SliderRow("Night starts", p.nightStartMin.toFloat(), 0f..1425f, hm(p.nightStartMin), 94) { v -> vm.update { it.copy(nightStartMin = (v / 15f).roundToInt() * 15) } }
            SliderRow("Night ends", p.nightEndMin.toFloat(), 0f..1425f, hm(p.nightEndMin), 94) { v -> vm.update { it.copy(nightEndMin = (v / 15f).roundToInt() * 15) } }
        }
    }
    Group("Colour") {
        ColorRow("Accent", p.accent, AccentChoices.map { it.second }) { c -> vm.update { it.copy(accent = c) } }
    }
    Group("Wallpaper") {
        val names = listOf("iOS 18", "iOS 17", "Gradient", "Colour", "Black", "Photo")
        ChipsRow("Style", names, p.wallpaperPreset.ordinal) { i ->
            val preset = WallpaperPreset.entries[i]
            vm.update { it.copy(wallpaperPreset = preset) }
            if (preset == WallpaperPreset.CUSTOM_IMAGE && p.customWallpaperUri == null) actions.onPickWallpaper()
        }
        when (p.wallpaperPreset) {
            WallpaperPreset.GRADIENT -> {
                Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Wallpapers.gradients.forEachIndexed { i, g ->
                        Box(Modifier.size(40.dp).clip(CircleShape).background(Brush.linearGradient(g.second)).border(if (i == p.wallpaperGradient) 3.dp else 0.dp, LocalCarTokens.current.label, CircleShape).pressable { vm.update { s -> s.copy(wallpaperGradient = i) } })
                    }
                }
            }
            WallpaperPreset.SOLID -> ColorRow("Colour", p.wallpaperSolid, Wallpapers.solids) { c -> vm.update { it.copy(wallpaperSolid = c) } }
            WallpaperPreset.CUSTOM_IMAGE -> ButtonRow("Photo", "Pick any image from the unit or a USB drive", action = "Choose") { actions.onPickWallpaper() }
            else -> {}
        }
        SliderRow("Dim wallpaper", p.wallpaperDim, 0f..0.7f, "${(p.wallpaperDim * 100).roundToInt()}%") { v -> vm.update { it.copy(wallpaperDim = v) } }
    }
    Group("Cards & widgets") {
        SegRow("Card style", listOf("Glass", "Solid", "Outline"), p.cardStyle.ordinal) { vm.update { s -> s.copy(cardStyle = CardStyle.entries[it]) } }
        if (p.cardStyle == CardStyle.GLASS) SliderRow("Glass opacity", p.cardAlpha, 0.2f..1f, "${(p.cardAlpha * 100).roundToInt()}%") { v -> vm.update { it.copy(cardAlpha = v) } }
        SliderRow("Corner radius", p.cornerRadiusDp, 0f..40f, "${p.cornerRadiusDp.roundToInt()}") { v -> vm.update { it.copy(cornerRadiusDp = v) } }
        SliderRow("Spacing", p.cardGapDp, 4f..28f, "${p.cardGapDp.roundToInt()}") { v -> vm.update { it.copy(cardGapDp = v) } }
    }
    Group("Text & size", "Fit to screen scales the whole interface to this display, so it looks the same on any screen size. UI size is applied on top.") {
        SwitchRow("Fit to screen", p.autoFit, "Adapts layout to any display size") { c -> vm.update { it.copy(autoFit = c) } }
        SliderRow("UI size", p.uiScale, 0.6f..1.6f, "${(p.uiScale * 100).roundToInt()}%") { v -> vm.update { it.copy(uiScale = (v * 20).roundToInt() / 20f) } }
        SliderRow("Text size", p.fontScale, 0.8f..1.5f, "${(p.fontScale * 100).roundToInt()}%") { v -> vm.update { it.copy(fontScale = (v * 20).roundToInt() / 20f) } }
        SwitchRow("Bold text", p.boldText) { c -> vm.update { it.copy(boldText = c) } }
    }
    Group("Motion & format") {
        SwitchRow("Reduce motion", p.reduceMotion, "Turns off spring and slide animations") { c -> vm.update { it.copy(reduceMotion = c) } }
        SwitchRow("24-hour time", p.use24h) { c -> vm.update { it.copy(use24h = c) } }
        SwitchRow("Arabic digits (٠١٢٣)", p.arabicDigits) { c -> vm.update { it.copy(arabicDigits = c) } }
    }
}

private fun hm(min: Int) = "%02d:%02d".format(min / 60, min % 60)

@Composable
private fun SidebarPane(vm: LauncherViewModel, p: LauncherPreferences) {
    val t = LocalCarTokens.current
    val apps by vm.allApps.collectAsStateWithLifecycle()
    val icons by vm.processedIcons.collectAsStateWithLifecycle()
    Group("Your sidebar apps", "Tap an app in the app grid and long-press it for Add to sidebar as well. Long-press a sidebar app to reorder it.") {
        val map = apps.associateBy { it.packageName }
        p.dockApps.forEachIndexed { i, pkg ->
            val app = map[pkg] ?: return@forEachIndexed
            Line {
                icons[pkg]?.let { Image(it, null, Modifier.size(40.dp)) }
                Text(app.displayName, style = MaterialTheme.typography.bodyLarge, color = t.label, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                RoundMini(Icons.Rounded.KeyboardArrowUp, i > 0) { vm.moveDock(pkg, -1) }
                RoundMini(Icons.Rounded.KeyboardArrowDown, i < p.dockApps.lastIndex) { vm.moveDock(pkg, 1) }
                RoundMini(Icons.Rounded.Close, true, t.red) { vm.toggleDock(pkg) }
            }
            if (i < p.dockApps.lastIndex) Divider()
        }
        PillButton("Choose apps…", Modifier.fillMaxWidth().padding(vertical = 8.dp)) { vm.openPicker(PickerTarget.Dock) }
    }
    Group("Layout") {
        SegRow("Side", listOf("Left", "Right"), p.dockSide.ordinal) { vm.update { s -> s.copy(dockSide = DockSide.entries[it]) } }
        SegRow("Style", listOf("Floating", "Flush", "Transparent"), p.dockStyle.ordinal) { vm.update { s -> s.copy(dockStyle = DockStyle.entries[it]) } }
        SegRow("Width", listOf("Slim", "Regular", "Wide"), p.dockWidthLevel) { vm.update { s -> s.copy(dockWidthLevel = it) } }
        SliderRow("Icon size", p.dockIconSizeDp, 36f..72f, "${p.dockIconSizeDp.roundToInt()}") { v -> vm.update { it.copy(dockIconSizeDp = v) } }
        SegRow("Recent apps below yours", listOf("None", "1", "2", "3", "4"), p.dockRecents) { vm.update { s -> s.copy(dockRecents = it) } }
    }
    Group("Show") {
        SwitchRow("App names", p.dockShowLabels) { c -> vm.update { it.copy(dockShowLabels = c) } }
        SwitchRow("Clock", p.dockShowClock) { c -> vm.update { it.copy(dockShowClock = c) } }
        SwitchRow("Status icons", p.dockShowStatus) { c -> vm.update { it.copy(dockShowStatus = c) } }
        SwitchRow("Screen dimmer button", p.dockShowDimmer) { c -> vm.update { it.copy(dockShowDimmer = c) } }
        SwitchRow("Settings button", p.dockShowSettings) { c -> vm.update { it.copy(dockShowSettings = c) } }
        SwitchRow("Voice button", p.dockShowVoice) { c -> vm.update { it.copy(dockShowVoice = c) } }
    }
}

@Composable
private fun RoundMini(icon: ImageVector, enabled: Boolean, tint: Color? = null, onClick: () -> Unit) {
    val t = LocalCarTokens.current
    Box(Modifier.size(38.dp).clip(CircleShape).background(t.fill).pressable(enabled = enabled, onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = if (enabled) (tint ?: t.label) else t.tertiaryLabel, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun DashboardPane(vm: LauncherViewModel, p: LauncherPreferences) {
    Group("Widgets", "Long-press an empty spot on the dashboard, or tap Edit, to add, remove, resize, move or restyle widgets. Drag a widget by long-pressing it in edit mode.") {
        ButtonRow("Edit dashboard", "${p.pages.size} pages · ${p.pages.sumOf { it.widgets.size }} widgets", action = "Edit") { vm.enterEditMode(); vm.navigateBackToDashboard() }
        Divider()
        ButtonRow("Reset to default layout", color = LocalCarTokens.current.red, action = "Reset") { vm.resetLayout() }
    }
    Group("Grid") {
        SegRow("Columns", listOf("2", "3", "4", "5", "6", "7", "8"), p.gridCols - 2) { vm.setGrid(it + 2, p.gridRows) }
        SegRow("Rows", listOf("1", "2", "3", "4"), p.gridRows - 1) { vm.setGrid(p.gridCols, it + 1) }
        SwitchRow("Page dots", p.showPageDots) { c -> vm.update { it.copy(showPageDots = c) } }
    }
}

@Composable
private fun AppsPane(vm: LauncherViewModel, p: LauncherPreferences) {
    val t = LocalCarTokens.current
    val packs by vm.iconPacks.collectAsStateWithLifecycle()
    val apps by vm.allApps.collectAsStateWithLifecycle()
    val icons by vm.processedIcons.collectAsStateWithLifecycle()
    Group("Icons", "Apple look: real iOS continuous-corner shape, flat artwork, and hand-built Apple-style icons for system apps (Phone, Settings, Camera, Radio, Files…).") {
        SegRow("Shape", listOf("iOS", "Circle", "Rounded", "Square"), p.iconShape.ordinal) { vm.update { s -> s.copy(iconShape = IconShape.entries[it]) } }
        SwitchRow("Apple-style icons for system apps", p.useAppleGlyphs) { c -> vm.update { it.copy(useAppleGlyphs = c) } }
        SegRow("Background for transparent icons", listOf("Auto", "White", "Dark"), p.iconBackdrop.ordinal) { vm.update { s -> s.copy(iconBackdrop = IconBackdrop.entries[it]) } }
        SliderRow("Artwork zoom", p.iconZoom, 0.8f..1.3f, "${(p.iconZoom * 100).roundToInt()}%") { v -> vm.update { it.copy(iconZoom = (v * 20).roundToInt() / 20f) } }
        SwitchRow("Subtle edge line", p.iconBorder) { c -> vm.update { it.copy(iconBorder = c) } }
        if (packs.isNotEmpty()) ChipsRow("Icon pack", listOf("None") + packs.map { it.label }, packs.indexOfFirst { it.packageName == p.activeIconPackPackage } + 1) { i ->
            vm.update { it.copy(activeIconPackPackage = if (i == 0) null else packs[i - 1].packageName) }
        }
    }
    Group("App grid") {
        SliderRow("Icon size", p.iconSizeDp, 44f..110f, "${p.iconSizeDp.roundToInt()}") { v -> vm.update { it.copy(iconSizeDp = v) } }
        SwitchRow("App names", p.showLabels) { c -> vm.update { it.copy(showLabels = c) } }
        if (p.showLabels) SliderRow("Name size", p.labelSizeSp, 9f..20f, "${p.labelSizeSp.roundToInt()}") { v -> vm.update { it.copy(labelSizeSp = v) } }
        SegRow("Columns", listOf("Auto", "4", "5", "6", "7", "8"), if (p.appGridCols == 0) 0 else (p.appGridCols - 3).coerceIn(1, 5)) { vm.update { s -> s.copy(appGridCols = if (it == 0) 0 else it + 3) } }
        SegRow("Rows", listOf("1", "2", "3", "4"), (p.appGridRows - 1).coerceIn(0, 3)) { vm.update { s -> s.copy(appGridRows = it + 1) } }
    }
    val hidden = apps.filter { it.isHidden }
    if (hidden.isNotEmpty()) Group("Hidden apps") {
        hidden.forEach { app ->
            Line {
                icons[app.packageName]?.let { Image(it, null, Modifier.size(36.dp)) }
                Text(app.displayName, style = MaterialTheme.typography.bodyLarge, color = t.label, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                PillButton("Show", filled = false) { vm.setAppHidden(app.packageName, false) }
            }
        }
    }
}

@Composable
private fun DrivingPane(vm: LauncherViewModel, p: LauncherPreferences) {
    Group("Navigation") {
        SegRow("Navigation app", NavigationProvider.entries.map { it.label }, p.navProvider.ordinal) { vm.update { s -> s.copy(navProvider = NavigationProvider.entries[it]) } }
        TextRow("Home", p.homeAddress) { v -> vm.update { it.copy(homeAddress = v) } }
        TextRow("Work", p.workAddress) { v -> vm.update { it.copy(workAddress = v) } }
    }
    Group("Speed") {
        SegRow("Unit", listOf("km/h", "mph"), p.speedUnit.ordinal) { vm.update { s -> s.copy(speedUnit = SpeedUnit.entries[it]) } }
        SwitchRow("Speed limit alert", p.speedGuardEnabled) { c -> vm.update { it.copy(speedGuardEnabled = c) } }
        if (p.speedGuardEnabled) {
            SliderRow("Limit", p.speedLimitKmh.toFloat(), 30f..240f, "${p.speedLimitKmh} km/h", 41) { v -> vm.update { it.copy(speedLimitKmh = (v / 5f).roundToInt() * 5) } }
            SwitchRow("Warning chime", p.speedChime) { c -> vm.update { it.copy(speedChime = c) } }
        }
    }
}

@Composable
private fun TimePane(vm: LauncherViewModel, p: LauncherPreferences) {
    Group("Location", "Used for prayer times, sunset day/night and weather. GPS is used when available; the last known position is remembered.") {
        SegRow("Source", listOf("GPS (automatic)", "Choose city"), if (p.manualLocation) 1 else 0) { vm.update { s -> s.copy(manualLocation = it == 1) } }
        if (p.manualLocation) ChipsRow("City", Cities.list.map { it.first }, p.manualCityIdx) { i -> vm.update { it.copy(manualCityIdx = i) } }
    }
    Group("Prayer times") {
        ChipsRow("Method", PrayerMethod.entries.map { it.label }, p.prayerMethod.ordinal) { i -> vm.update { it.copy(prayerMethod = PrayerMethod.entries[i]) } }
        SwitchRow("Hanafi Asr", p.asrHanafi) { c -> vm.update { it.copy(asrHanafi = c) } }
        SliderRow("Adjust all times", p.prayerOffsetMin.toFloat(), -15f..15f, "${p.prayerOffsetMin} min", 29) { v -> vm.update { it.copy(prayerOffsetMin = v.roundToInt()) } }
    }
    Group("Weather & clock") {
        SwitchRow("Fahrenheit", p.weatherFahrenheit) { c -> vm.update { it.copy(weatherFahrenheit = c) } }
        SwitchRow("Correct wrong system time", p.timeGuard, "Uses internet time for every clock in CarDeck and warns in the sidebar when the unit's clock is off") { c -> vm.update { it.copy(timeGuard = c) } }
    }
}

@Composable
private fun MorePane(vm: LauncherViewModel, p: LauncherPreferences, actions: SettingsActions) {
    val t = LocalCarTokens.current
    Group("Backup") {
        ButtonRow("Export settings", "Saves layout, sidebar and every option to a file", action = "Export") { actions.onExport() }
        Divider()
        ButtonRow("Restore settings", "Load a file exported earlier", action = "Import") { actions.onImport() }
    }
    Group("Permissions") {
        ButtonRow("Default launcher", "Make CarDeck the home screen", action = "Open") { actions.onDefaultLauncher() }
        Divider()
        ButtonRow("Notification access", "Needed for Now Playing", action = "Open") { actions.onNotificationAccess() }
        Divider()
        ButtonRow("Location", "Speed, trip, prayer times, sunset mode", action = "Allow") { actions.onLocationPermission() }
        Divider()
        ButtonRow("Calendar", "Next event in the calendar widget", action = "Allow") { actions.onCalendarPermission() }
    }
    Group("Valet mode", "When on, settings and app editing ask for a 4-digit passcode.") {
        SwitchRow("Lock settings", p.valetModeEnabled) { c -> vm.update { it.copy(valetModeEnabled = c) } }
        TextRow("Passcode", p.valetPin) { v -> vm.update { it.copy(valetPin = v.filter { ch -> ch.isDigit() }.take(4)) } }
    }
    Group("About") {
        Text("CarDeck · Apple-style launcher for Android head units. Typeface: Inter (OFL).", style = MaterialTheme.typography.labelMedium, color = t.secondaryLabel, modifier = Modifier.padding(vertical = 10.dp))
    }
}
