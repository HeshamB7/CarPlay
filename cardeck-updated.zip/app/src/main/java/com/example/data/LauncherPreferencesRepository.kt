package com.example.data

import android.content.Context
import android.net.Uri
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

private val Context.carDeckDataStore: DataStore<Preferences> by preferencesDataStore(name = "cardeck_prefs_v2")

/** All launcher settings live in one JSON document: easy to extend, back up and restore. */
class LauncherPreferencesRepository(private val context: Context) {

    private val key = stringPreferencesKey("settings_json")

    suspend fun load(): LauncherPreferences = withContext(Dispatchers.IO) {
        runCatching {
            val raw = context.carDeckDataStore.data.first()[key]
            if (raw.isNullOrBlank()) null else PrefsJson.fromJson(JSONObject(raw))
        }.getOrNull() ?: LauncherPreferences()
    }

    suspend fun save(prefs: LauncherPreferences) {
        runCatching {
            val text = PrefsJson.toJson(prefs).toString()
            context.carDeckDataStore.edit { it[key] = text }
        }
    }

    suspend fun exportToUri(uri: Uri, prefs: LauncherPreferences): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val json = PrefsJson.toJson(prefs).toString(2)
            context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                ?: return@runCatching false
            true
        }.getOrDefault(false)
    }

    suspend fun importFromUri(uri: Uri): LauncherPreferences? = withContext(Dispatchers.IO) {
        runCatching {
            val raw = context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
                ?: return@runCatching null
            PrefsJson.fromJson(JSONObject(raw))
        }.getOrNull()
    }
}

object PrefsJson {

    private inline fun <reified T : Enum<T>> JSONObject.enum(name: String, fallback: T): T {
        val v = optString(name, "")
        if (v.isBlank()) return fallback
        return runCatching { enumValueOf<T>(v) }.getOrDefault(fallback)
    }

    private fun JSONObject.f(name: String, d: Float, lo: Float, hi: Float): Float =
        optDouble(name, d.toDouble()).toFloat().coerceIn(lo, hi)

    private fun JSONObject.i(name: String, d: Int, lo: Int, hi: Int): Int = optInt(name, d).coerceIn(lo, hi)

    private fun JSONObject.strList(name: String, d: List<String>): List<String> {
        val arr = optJSONArray(name) ?: return d
        return List(arr.length()) { arr.optString(it) }.filter { it.isNotBlank() }
    }

    fun fromJson(j: JSONObject): LauncherPreferences {
        val d = LauncherPreferences()
        val labels = buildMap {
            j.optJSONObject("customLabels")?.let { o -> o.keys().forEach { k -> put(k, o.optString(k)) } }
        }
        val pages = buildList {
            val arr = j.optJSONArray("pages")
            if (arr != null) for (pi in 0 until arr.length()) {
                val po = arr.optJSONObject(pi) ?: continue
                val wa = po.optJSONArray("widgets")
                val widgets = buildList {
                    if (wa != null) for (wi in 0 until wa.length()) {
                        val wo = wa.optJSONObject(wi) ?: continue
                        val type = runCatching { WidgetType.valueOf(wo.optString("type")) }.getOrNull() ?: continue
                        val opts = buildMap {
                            wo.optJSONObject("options")?.let { oo -> oo.keys().forEach { k -> put(k, oo.optString(k)) } }
                        }
                        add(
                            WidgetInstance(
                                id = wo.optString("id").ifBlank { "w${pi}_$wi" },
                                type = type,
                                col = wo.optInt("col", 0), row = wo.optInt("row", 0),
                                w = wo.optInt("w", type.defW).coerceAtLeast(1),
                                h = wo.optInt("h", type.defH).coerceAtLeast(1),
                                options = opts
                            )
                        )
                    }
                }
                add(WidgetPage(po.optString("id").ifBlank { "p$pi" }, widgets))
            }
        }
        val hasPagesKey = j.has("pages")
        return LauncherPreferences(
            dayNightMode = j.enum("dayNightMode", d.dayNightMode),
            nightStartMin = j.i("nightStartMin", d.nightStartMin, 0, 1439),
            nightEndMin = j.i("nightEndMin", d.nightEndMin, 0, 1439),
            accent = j.optLong("accent", d.accent.toLong()).toInt(),
            wallpaperPreset = j.enum("wallpaperPreset", d.wallpaperPreset),
            customWallpaperUri = j.optString("customWallpaperUri", "").takeIf { it.isNotBlank() },
            wallpaperGradient = j.i("wallpaperGradient", d.wallpaperGradient, 0, 20),
            wallpaperSolid = j.optLong("wallpaperSolid", d.wallpaperSolid.toLong()).toInt(),
            wallpaperDim = j.f("wallpaperDim", d.wallpaperDim, 0f, 0.7f),
            cardStyle = j.enum("cardStyle", d.cardStyle),
            cardAlpha = j.f("cardAlpha", d.cardAlpha, 0.2f, 1f),
            cornerRadiusDp = j.f("cornerRadiusDp", d.cornerRadiusDp, 0f, 40f),
            cardGapDp = j.f("cardGapDp", d.cardGapDp, 4f, 28f),
            reduceMotion = j.optBoolean("reduceMotion", d.reduceMotion),
            autoFit = j.optBoolean("autoFit", d.autoFit),
            uiScale = j.f("uiScale", d.uiScale, 0.6f, 1.6f),
            fontScale = j.f("fontScale", d.fontScale, 0.8f, 1.5f),
            boldText = j.optBoolean("boldText", d.boldText),
            use24h = j.optBoolean("use24h", d.use24h),
            arabicDigits = j.optBoolean("arabicDigits", d.arabicDigits),
            dockSide = j.enum("dockSide", d.dockSide),
            dockStyle = j.enum("dockStyle", d.dockStyle),
            dockWidthLevel = j.i("dockWidthLevel", d.dockWidthLevel, 0, 2),
            dockIconSizeDp = j.f("dockIconSizeDp", d.dockIconSizeDp, 36f, 72f),
            dockApps = j.strList("dockApps", d.dockApps),
            dockRecents = j.i("dockRecents", d.dockRecents, 0, 4),
            dockShowLabels = j.optBoolean("dockShowLabels", d.dockShowLabels),
            dockShowClock = j.optBoolean("dockShowClock", d.dockShowClock),
            dockShowStatus = j.optBoolean("dockShowStatus", d.dockShowStatus),
            dockShowVoice = j.optBoolean("dockShowVoice", d.dockShowVoice),
            dockShowDimmer = j.optBoolean("dockShowDimmer", d.dockShowDimmer),
            dockShowSettings = j.optBoolean("dockShowSettings", d.dockShowSettings),
            iconSizeDp = j.f("iconSizeDp", d.iconSizeDp, 44f, 110f),
            iconShape = j.enum("iconShape", d.iconShape),
            iconBackdrop = j.enum("iconBackdrop", d.iconBackdrop),
            useAppleGlyphs = j.optBoolean("useAppleGlyphs", d.useAppleGlyphs),
            iconZoom = j.f("iconZoom", d.iconZoom, 0.8f, 1.3f),
            iconShadow = j.optBoolean("iconShadow", d.iconShadow),
            iconBorder = j.optBoolean("iconBorder", d.iconBorder),
            showLabels = j.optBoolean("showLabels", d.showLabels),
            labelSizeSp = j.f("labelSizeSp", d.labelSizeSp, 9f, 20f),
            appGridCols = j.i("appGridCols", d.appGridCols, 0, 9),
            appGridRows = j.i("appGridRows", d.appGridRows, 1, 5),
            activeIconPackPackage = j.optString("activeIconPackPackage", "").takeIf { it.isNotBlank() },
            recentPackages = j.strList("recentPackages", emptyList()),
            hiddenPackages = j.strList("hiddenPackages", emptyList()).toSet(),
            customLabels = labels,
            appOrder = j.strList("appOrder", emptyList()),
            gridCols = j.i("gridCols", d.gridCols, 2, 8),
            gridRows = j.i("gridRows", d.gridRows, 1, 4),
            showPageDots = j.optBoolean("showPageDots", d.showPageDots),
            pages = if (hasPagesKey) pages else emptyList(),
            navProvider = j.enum("navProvider", d.navProvider),
            homeAddress = j.optString("homeAddress", d.homeAddress),
            workAddress = j.optString("workAddress", d.workAddress),
            speedLimitKmh = j.i("speedLimitKmh", d.speedLimitKmh, 30, 240),
            speedGuardEnabled = j.optBoolean("speedGuardEnabled", d.speedGuardEnabled),
            speedChime = j.optBoolean("speedChime", d.speedChime),
            speedUnit = j.enum("speedUnit", d.speedUnit),
            manualLocation = j.optBoolean("manualLocation", d.manualLocation),
            manualCityIdx = j.i("manualCityIdx", d.manualCityIdx, 0, Cities.list.lastIndex),
            lastLat = j.optDouble("lastLat", d.lastLat),
            lastLon = j.optDouble("lastLon", d.lastLon),
            prayerMethod = j.enum("prayerMethod", d.prayerMethod),
            asrHanafi = j.optBoolean("asrHanafi", d.asrHanafi),
            prayerOffsetMin = j.i("prayerOffsetMin", d.prayerOffsetMin, -30, 30),
            weatherFahrenheit = j.optBoolean("weatherFahrenheit", d.weatherFahrenheit),
            timeGuard = j.optBoolean("timeGuard", d.timeGuard),
            hasParking = j.optBoolean("hasParking", d.hasParking),
            parkLat = j.optDouble("parkLat", d.parkLat),
            parkLon = j.optDouble("parkLon", d.parkLon),
            parkTimeMs = j.optLong("parkTimeMs", d.parkTimeMs),
            valetModeEnabled = j.optBoolean("valetModeEnabled", d.valetModeEnabled),
            valetPin = j.optString("valetPin", d.valetPin).take(4).ifBlank { "1234" },
            onboardingCompleted = j.optBoolean("onboardingCompleted", d.onboardingCompleted)
        )
    }

    fun toJson(p: LauncherPreferences): JSONObject = JSONObject().apply {
        put("dayNightMode", p.dayNightMode.name)
        put("nightStartMin", p.nightStartMin)
        put("nightEndMin", p.nightEndMin)
        put("accent", p.accent.toLong() and 0xFFFFFFFFL)
        put("wallpaperPreset", p.wallpaperPreset.name)
        put("customWallpaperUri", p.customWallpaperUri ?: "")
        put("wallpaperGradient", p.wallpaperGradient)
        put("wallpaperSolid", p.wallpaperSolid.toLong() and 0xFFFFFFFFL)
        put("wallpaperDim", p.wallpaperDim.toDouble())
        put("cardStyle", p.cardStyle.name)
        put("cardAlpha", p.cardAlpha.toDouble())
        put("cornerRadiusDp", p.cornerRadiusDp.toDouble())
        put("cardGapDp", p.cardGapDp.toDouble())
        put("reduceMotion", p.reduceMotion)
        put("autoFit", p.autoFit)
        put("uiScale", p.uiScale.toDouble())
        put("fontScale", p.fontScale.toDouble())
        put("boldText", p.boldText)
        put("use24h", p.use24h)
        put("arabicDigits", p.arabicDigits)
        put("dockSide", p.dockSide.name)
        put("dockStyle", p.dockStyle.name)
        put("dockWidthLevel", p.dockWidthLevel)
        put("dockIconSizeDp", p.dockIconSizeDp.toDouble())
        put("dockApps", JSONArray(p.dockApps))
        put("dockRecents", p.dockRecents)
        put("dockShowLabels", p.dockShowLabels)
        put("dockShowClock", p.dockShowClock)
        put("dockShowStatus", p.dockShowStatus)
        put("dockShowVoice", p.dockShowVoice)
        put("dockShowDimmer", p.dockShowDimmer)
        put("dockShowSettings", p.dockShowSettings)
        put("iconSizeDp", p.iconSizeDp.toDouble())
        put("iconShape", p.iconShape.name)
        put("iconBackdrop", p.iconBackdrop.name)
        put("useAppleGlyphs", p.useAppleGlyphs)
        put("iconZoom", p.iconZoom.toDouble())
        put("iconShadow", p.iconShadow)
        put("iconBorder", p.iconBorder)
        put("showLabels", p.showLabels)
        put("labelSizeSp", p.labelSizeSp.toDouble())
        put("appGridCols", p.appGridCols)
        put("appGridRows", p.appGridRows)
        put("activeIconPackPackage", p.activeIconPackPackage ?: "")
        put("recentPackages", JSONArray(p.recentPackages))
        put("hiddenPackages", JSONArray(p.hiddenPackages.toList()))
        put("customLabels", JSONObject(p.customLabels))
        put("appOrder", JSONArray(p.appOrder))
        put("gridCols", p.gridCols)
        put("gridRows", p.gridRows)
        put("showPageDots", p.showPageDots)
        put("pages", JSONArray().apply {
            p.pages.forEach { page ->
                put(JSONObject().apply {
                    put("id", page.id)
                    put("widgets", JSONArray().apply {
                        page.widgets.forEach { w ->
                            put(JSONObject().apply {
                                put("id", w.id)
                                put("type", w.type.name)
                                put("col", w.col)
                                put("row", w.row)
                                put("w", w.w)
                                put("h", w.h)
                                put("options", JSONObject(w.options))
                            })
                        }
                    })
                })
            }
        })
        put("navProvider", p.navProvider.name)
        put("homeAddress", p.homeAddress)
        put("workAddress", p.workAddress)
        put("speedLimitKmh", p.speedLimitKmh)
        put("speedGuardEnabled", p.speedGuardEnabled)
        put("speedChime", p.speedChime)
        put("speedUnit", p.speedUnit.name)
        put("manualLocation", p.manualLocation)
        put("manualCityIdx", p.manualCityIdx)
        put("lastLat", p.lastLat)
        put("lastLon", p.lastLon)
        put("prayerMethod", p.prayerMethod.name)
        put("asrHanafi", p.asrHanafi)
        put("prayerOffsetMin", p.prayerOffsetMin)
        put("weatherFahrenheit", p.weatherFahrenheit)
        put("timeGuard", p.timeGuard)
        put("hasParking", p.hasParking)
        put("parkLat", p.parkLat)
        put("parkLon", p.parkLon)
        put("parkTimeMs", p.parkTimeMs)
        put("valetModeEnabled", p.valetModeEnabled)
        put("valetPin", p.valetPin)
        put("onboardingCompleted", p.onboardingCompleted)
    }
}
