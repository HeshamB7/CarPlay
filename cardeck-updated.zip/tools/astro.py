import math, datetime
D2R=math.pi/180
def solar(E_days, lat, lon):
    """E_days: days since epoch of local date. returns transit_utc_ms, declination(rad)"""
    n = (E_days - 10957) + 0.0008
    jstar = n - lon/360.0
    M = (357.5291 + 0.98560028*jstar) % 360
    Mr = M*D2R
    Cc = 1.9148*math.sin(Mr)+0.02*math.sin(2*Mr)+0.0003*math.sin(3*Mr)
    lam = (M + Cc + 180 + 102.9372) % 360
    lr = lam*D2R
    jt = 2451545.0 + jstar + 0.0053*math.sin(Mr) - 0.0069*math.sin(2*lr)
    sind = math.sin(lr)*math.sin(23.4397*D2R)
    dec = math.asin(sind)
    transit_ms = (jt - 2440587.5)*86400000.0
    return transit_ms, dec
def hour_angle(alt_deg, lat, dec):
    cosw = (math.sin(alt_deg*D2R) - math.sin(lat*D2R)*math.sin(dec))/(math.cos(lat*D2R)*math.cos(dec))
    if cosw>1 or cosw<-1: return None
    return math.degrees(math.acos(cosw))
def times(E_days, lat, lon, fajr=18.5, isha_angle=None, isha_min=90, asr_factor=1):
    tr, dec = solar(E_days, lat, lon)
    day_ms=86400000.0
    def at(alt, sign):
        w=hour_angle(alt,lat,dec)
        if w is None: return None
        return tr + sign*w/360.0*day_ms
    sunrise=at(-0.833,-1); sunset=at(-0.833,1)
    fj=at(-fajr,-1)
    asr_alt = math.degrees(math.atan(1.0/(asr_factor+math.tan(abs(lat*D2R-dec)))))
    asr=at(asr_alt,1)
    isha = sunset+isha_min*60000 if isha_angle is None else at(-isha_angle,1)
    return dict(fajr=fj,sunrise=sunrise,dhuhr=tr,asr=asr,maghrib=sunset,isha=isha)
def fmt(ms,tz=3):
    return (datetime.datetime(1970,1,1)+datetime.timedelta(milliseconds=ms+tz*3600000)).strftime('%H:%M')
if __name__=='__main__':
    for (y,m,d) in [(2026,11,13),(2026,6,21),(2026,3,1)]:
        E=(datetime.date(y,m,d)-datetime.date(1970,1,1)).days
        t=times(E,21.4858,39.1925)
        print(y,m,d,{k:fmt(v) for k,v in t.items()})
    # Riyadh MWL check, London sanity
    E=(datetime.date(2026,11,13)-datetime.date(1970,1,1)).days
    t=times(E,24.7136,46.6753,fajr=18.5); print('Riyadh',{k:fmt(v) for k,v in t.items()})
